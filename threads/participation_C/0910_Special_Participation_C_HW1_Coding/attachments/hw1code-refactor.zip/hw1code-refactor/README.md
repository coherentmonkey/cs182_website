# SGD Momentum Analysis (Refactor)

This repository refactors the original `q_sgd_momentum_analysis_sol.ipynb` into a small, testable Python package while preserving the teaching-focused workflow for comparing plain SGD to SGD with momentum on a synthetic regression/classification task.

## Layout
- `sgd_momentum/`: reusable code for data generation, optimization, and plotting.
- `scripts/reproduce_figures.py`: end-to-end script that recreates the notebook figures.
- `solution/q_sgd_momentum_analysis_sol.ipynb`: refreshed notebook that now calls into the package.
- `requirements.txt`: runtime dependencies.

## Quickstart
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python scripts/reproduce_figures.py
```

## Development Notes
- Deterministic dataset generation uses a local random generator (`numpy.random.default_rng`) with a fixed seed to keep figures reproducible.
- Functions are organized by concern (data, optimization, visualization) to keep notebooks focused on pedagogy while leaving the reusable pieces testable and documented.

