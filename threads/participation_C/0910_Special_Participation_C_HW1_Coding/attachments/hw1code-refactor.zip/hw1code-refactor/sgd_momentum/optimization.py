"""Optimization routines for gradient descent and momentum."""

 from dataclasses import dataclass

import numpy as np

from sgd_momentum.data import Dataset


@dataclass
class OptimizationResult:
    """Stores optimization history for analysis and plotting."""

    gradients: np.ndarray
    weights: np.ndarray
    losses: list[float]
    weight_history: np.ndarray


def compute_gradient(dataset: Dataset, weights: np.ndarray) -> np.ndarray:
    """Compute the gradient of the squared error loss."""
    return 2 * (dataset.features.T @ dataset.features @ weights) - 2 * dataset.features.T @ dataset.labels


def run_gradient_descent(
    dataset: Dataset, *, max_iter: int = 100, step_size: float = 1e-4
) -> OptimizationResult:
    """Run vanilla gradient descent on the dataset."""
    weights = np.zeros((2, 1))
    gradients: list[np.ndarray] = []
    weight_history: list[np.ndarray] = []
    losses: list[float] = []

    for _ in range(max_iter):
        grad = compute_gradient(dataset, weights)
        weights = weights - step_size * grad
        gradients.append(grad)
        weight_history.append(weights.copy())
        losses.append(np.linalg.norm(dataset.labels - dataset.features @ weights) ** 2)

    return OptimizationResult(
        gradients=np.array(gradients).squeeze(),
        weights=weights,
        losses=losses,
        weight_history=np.array(weight_history).squeeze(),
    )


def run_gradient_descent_momentum(
    dataset: Dataset, *, max_iter: int = 100, step_size: float = 1e-4, beta: float = 0.6
) -> OptimizationResult:
    """Run gradient descent with momentum on the dataset."""
    weights = np.zeros((2, 1))
    gradients: list[np.ndarray] = []
    weight_history: list[np.ndarray] = []
    losses: list[float] = []
    smoothed_grad = np.zeros_like(weights)

    for iteration in range(max_iter):
        grad = compute_gradient(dataset, weights)
        if iteration == 0:
            smoothed_grad = grad
        smoothed_grad = (1 - beta) * smoothed_grad + beta * grad
        weights = weights - step_size * smoothed_grad
        gradients.append(grad)
        weight_history.append(weights.copy())
        losses.append(np.linalg.norm(dataset.labels - dataset.features @ weights) ** 2)

    return OptimizationResult(
        gradients=np.array(gradients).squeeze(),
        weights=weights,
        losses=losses,
        weight_history=np.array(weight_history).squeeze(),
    )

