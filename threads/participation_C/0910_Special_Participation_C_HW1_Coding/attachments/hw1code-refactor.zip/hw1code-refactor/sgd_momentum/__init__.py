"""Core utilities for analyzing SGD with and without momentum."""

from sgd_momentum.analysis import run_default_experiment
from sgd_momentum.data import Dataset, create_linear_classification_dataset
from sgd_momentum.optimization import (
    OptimizationResult,
    run_gradient_descent,
    run_gradient_descent_momentum,
)

__all__ = [
    "Dataset",
    "OptimizationResult",
    "create_linear_classification_dataset",
    "run_default_experiment",
    "run_gradient_descent",
    "run_gradient_descent_momentum",
]

