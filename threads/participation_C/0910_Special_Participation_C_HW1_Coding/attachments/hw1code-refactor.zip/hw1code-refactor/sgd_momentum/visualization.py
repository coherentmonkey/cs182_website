"""Plotting helpers for the SGD momentum analysis."""

from typing import Iterable, Tuple

import matplotlib.pyplot as plt
import numpy as np
from matplotlib import cm
from matplotlib.axes import Axes

from sgd_momentum.data import Dataset
from sgd_momentum.optimization import OptimizationResult


def plot_data_scatter(dataset: Dataset, ax: Axes | None = None) -> Axes:
    """Scatter plot of the dataset."""
    axis = ax or plt.gca()
    positive = dataset.labels.squeeze() == 1
    axis.scatter(*dataset.features[~positive].T, label="Negative")
    axis.scatter(*dataset.features[positive].T, label="Positive")
    axis.set_title("Visualization of Data")
    axis.legend()
    return axis


def plot_loss_contour(
    dataset: Dataset,
    grid_limits: Tuple[float, float] = (-0.5, 0.5),
    grid_size: int = 100,
    ax: Axes | None = None,
) -> Axes:
    """Contour plot of the squared error loss landscape."""
    axis = ax or plt.gca()
    w0_s, w1_s = np.meshgrid(
        np.linspace(grid_limits[0], grid_limits[1], grid_size),
        np.linspace(grid_limits[0], grid_limits[1], grid_size),
    )
    weight_grid = np.stack([w0_s.reshape(-1), w1_s.reshape(-1)], axis=1)
    loss_surface = ((dataset.features @ weight_grid.T - dataset.labels) ** 2).sum(axis=0).reshape(
        grid_size, grid_size
    )
    contour = axis.contourf(w0_s, w1_s, loss_surface, cmap=cm.PuBu_r, levels=40)
    plt.colorbar(contour, ax=axis)
    axis.set_xlabel("w0")
    axis.set_ylabel("w1")
    return axis


def plot_gradients(result: OptimizationResult, *, title: str, ax: Axes | None = None) -> Axes:
    """Plot gradient magnitude over iterations for each dimension."""
    axis = ax or plt.gca()
    axis.plot(range(len(result.gradients)), np.abs(result.gradients)[:, 0], "r", label="Dimension 0")
    axis.plot(range(len(result.gradients)), np.abs(result.gradients)[:, 1], "b", label="Dimension 1")
    axis.set_title(title)
    axis.set_xlabel("Iterations")
    axis.legend()
    return axis


def plot_weights(result: OptimizationResult, *, title: str, ax: Axes | None = None) -> Axes:
    """Plot parameter magnitude over iterations for each dimension."""
    axis = ax or plt.gca()
    axis.plot(range(len(result.weight_history)), np.abs(result.weight_history)[:, 0], "r", label="Dimension 0")
    axis.plot(range(len(result.weight_history)), np.abs(result.weight_history)[:, 1], "b", label="Dimension 1")
    axis.set_title(title)
    axis.set_xlabel("Iterations")
    axis.legend()
    return axis


def plot_loss_log_gap(
    baseline: Iterable[float],
    comparison: Iterable[float],
    *,
    title: str,
    ax: Axes | None = None,
) -> Axes:
    """Plot log loss gap relative to final loss for two methods."""
    axis = ax or plt.gca()
    baseline_loss = np.asarray(baseline)
    comparison_loss = np.asarray(comparison)
    eps = np.finfo(float).eps
    axis.plot(range(len(baseline_loss)), np.log(np.abs(baseline_loss) - baseline_loss[-1] + eps), "r", label="GD")
    axis.plot(
        range(len(comparison_loss)),
        np.log(np.abs(comparison_loss) - comparison_loss[-1] + eps),
        "b",
        label="momentum",
    )
    axis.set_title(title)
    axis.set_ylabel("Log(loss(at iteration i) - optimal loss)")
    axis.set_xlabel("Iterations")
    axis.legend()
    return axis

