"""Convenience helpers to reproduce the SGD momentum study."""

from dataclasses import dataclass

from sgd_momentum.data import Dataset, create_linear_classification_dataset
from sgd_momentum.optimization import OptimizationResult, run_gradient_descent, run_gradient_descent_momentum


@dataclass
class ExperimentBundle:
    """Collects dataset and optimization results for downstream visualization."""

    dataset: Dataset
    gd: OptimizationResult
    gdm: OptimizationResult


def run_default_experiment(
    *,
    n_samples: int = 500,
    max_iter: int = 100,
    step_size: float = 1e-4,
    beta: float = 0.6,
    seed: int = 0,
) -> ExperimentBundle:
    """Generate the dataset and run both optimization methods."""
    dataset = create_linear_classification_dataset(
        n_samples=n_samples,
        mean=(-3.0, 0.0),
        std=(3.0, 1.0),
        seed=seed,
    )
    gd = run_gradient_descent(dataset, max_iter=max_iter, step_size=step_size)
    gdm = run_gradient_descent_momentum(dataset, max_iter=max_iter, step_size=step_size, beta=beta)
    return ExperimentBundle(dataset=dataset, gd=gd, gdm=gdm)

