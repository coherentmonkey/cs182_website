"""Data generation utilities for the SGD momentum example."""

from dataclasses import dataclass
from typing import Tuple

import numpy as np


@dataclass
class Dataset:
    """Container for features and labels."""

    features: np.ndarray
    labels: np.ndarray


def generate_gaussian_points(
    n_samples: int,
    mean: Tuple[float, float],
    std: Tuple[float, float],
    rng: np.random.Generator | None = None,
) -> np.ndarray:
    """Draw 2D points from a Gaussian distribution."""
    generator = rng or np.random.default_rng()
    return generator.normal(loc=mean, scale=std, size=(n_samples, 2))


def create_linear_classification_dataset(
    n_samples: int = 500,
    mean: Tuple[float, float] = (-3.0, 0.0),
    std: Tuple[float, float] = (3.0, 1.0),
    seed: int = 0,
) -> Dataset:
    """Create a synthetic 2D dataset and binary labels based on the second axis."""
    rng = np.random.default_rng(seed)
    features = generate_gaussian_points(n_samples, mean, std, rng)
    labels = (features[:, 1] > 0).astype(float).reshape(-1, 1)
    return Dataset(features=features, labels=labels)

