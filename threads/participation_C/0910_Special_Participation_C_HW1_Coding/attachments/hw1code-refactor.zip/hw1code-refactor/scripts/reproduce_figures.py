"""Recreate the figures from the SGD momentum notebook."""

import matplotlib.pyplot as plt

from sgd_momentum.analysis import run_default_experiment
from sgd_momentum.visualization import (
    plot_data_scatter,
    plot_gradients,
    plot_loss_contour,
    plot_loss_log_gap,
    plot_weights,
)


def main() -> None:
    experiment = run_default_experiment()

    _, axes = plt.subplots(1, 2, figsize=(12, 5))
    plot_data_scatter(experiment.dataset, ax=axes[0])
    plot_loss_contour(experiment.dataset, ax=axes[1])
    plt.tight_layout()

    _, axes = plt.subplots(2, 1, figsize=(12, 8))
    plot_gradients(experiment.gd, title="Gradients (GD)", ax=axes[0])
    plot_weights(experiment.gd, title="Parameters (GD)", ax=axes[1])
    plt.tight_layout()

    _, axes = plt.subplots(2, 1, figsize=(12, 8))
    plot_gradients(experiment.gdm, title="Gradients (Momentum)", ax=axes[0])
    plot_weights(experiment.gdm, title="Parameters (Momentum)", ax=axes[1])
    plt.tight_layout()

    _, axes = plt.subplots(2, 1, figsize=(12, 8))
    plot_gradients(
        experiment.gd,
        title="Gradients Comparison (GD vs Momentum)",
        ax=axes[0],
    )
    plot_gradients(
        experiment.gdm,
        title="Gradients Comparison (GD vs Momentum)",
        ax=axes[0],
    )
    plot_weights(
        experiment.gd,
        title="Parameters Comparison (GD vs Momentum)",
        ax=axes[1],
    )
    plot_weights(
        experiment.gdm,
        title="Parameters Comparison (GD vs Momentum)",
        ax=axes[1],
    )
    plt.tight_layout()

    plt.figure(figsize=(12, 4))
    plot_loss_log_gap(
        experiment.gd.losses,
        experiment.gdm.losses,
        title="Loss changes as iterations increase",
    )
    plt.tight_layout()
    plt.show()


if __name__ == "__main__":
    main()

