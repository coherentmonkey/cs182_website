"""
Tensor and Array Manipulation Utilities

This module provides helper functions for:
- Converting between NumPy arrays and PyTorch tensors
- Sign functions that handle zero values consistently
- Debugging utilities for parameter dictionaries

Author: CS 282A Course Staff
"""

import numpy as np
import torch


def to_numpy(x):
    # Convert a PyTorch tensor to a NumPy array.
    # Automatically detaches from computation graph before conversion.
    return x.detach().numpy()


def to_tensor(x):
    # Convert a NumPy array to a PyTorch tensor.
    return torch.tensor(x)


def my_sign_tensor(x):
    # Sign function for PyTorch tensors that maps 0 to 1.
    y = torch.sign(x)
    y[y == 0] = 1
    return y.int()


def my_sign_numpy(x):
    # Sign function for NumPy arrays that maps 0 to 1.
    y = np.sign(x)
    y[y == 0] = 1
    return y.astype("int")


def my_sign(x):
    # Universal sign function that works with both tensors and arrays.
    if torch.is_tensor(x):
        return my_sign_tensor(x)
    return my_sign_numpy(x)


def print_dict_initialization(params_dict, dict_name):
    # Debug utility to print code for extracting values from a dictionary.
    for key in params_dict:
        print(f"{key}={dict_name}['{key}']")
