"""
PyTorch Models for MAML Meta-Learning

This module provides neural network models used in MAML:
- DummyModel: A simple weighted feature model for meta-learning

Author: CS 282A Course Staff
"""

import torch
import torch.nn as nn


class DummyModel(nn.Module):
    # A simple linear model with learnable feature weights.

    def __init__(self, d):
        # Initialize the DummyModel.
        super(DummyModel, self).__init__()
        self.feature_weights = nn.Parameter(torch.ones(d).double())
        self.coeffs = nn.Parameter(torch.zeros(d).double())

    def forward(self, F):
        # Weight the features and compute linear combination
        return (F * self.feature_weights) @ self.coeffs

    def reset_task_params(self):
        # Reset task-specific parameters (coeffs) to zero.
        self.coeffs = nn.Parameter(torch.zeros_like(self.coeffs))
