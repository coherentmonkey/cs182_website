"""
MAML Implementation Package

This package provides a modular implementation of Model-Agnostic Meta-Learning
(MAML) for regression and classification tasks.

Usage:
    from maml import *

    # Or import specific modules
    from maml.data_utils import generate_x, featurize
    from maml.maml_regression import meta_learning_reg_closed_form

Author: CS 282A Course Staff
"""

__version__ = "1.0.0"

# Import all public APIs
from .data_utils import (
    generate_x,
    featurize,
    featurize_fourier,
    generate_y,
    add_label_noise
)

from .tensor_utils import (
    to_numpy,
    to_tensor,
    my_sign,
    my_sign_tensor,
    my_sign_numpy,
    print_dict_initialization
)

from .solvers import (
    solve_ls,
    solve_ridge,
    solve_logistic,
    closed_form_ls
)

from .models import (
    DummyModel
)

from .visualization import (
    visualize_test_loss_reg,
    visualize_prediction_reg,
    visualize_test_loss_classification,
    visualize_prediction_classification
)

from .maml_regression import (
    meta_learning_reg_closed_form,
    meta_learning_reg_sgd,
    get_params_dict_reg,
    get_params_dict_reg_sgd,
    get_post_data_reg,
    test_reg,
    test_oracle_reg,
    test_zero_reg,
    meta_update_reg
)

from .maml_classification import (
    meta_learning_classification,
    get_params_dict_classification,
    get_post_data_classification,
    test_classification,
    test_classification_zero,
    test_classification_oracle,
    meta_update_classification
)

from .widget_utils import (
    generate_int_widget,
    generate_float_widget,
    generate_floatlog_widget
)

__all__ = [
    # Data utilities
    'generate_x',
    'featurize',
    'featurize_fourier',
    'generate_y',
    'add_label_noise',

    # Tensor utilities
    'to_numpy',
    'to_tensor',
    'my_sign',
    'my_sign_tensor',
    'my_sign_numpy',
    'print_dict_initialization',

    # Solvers
    'solve_ls',
    'solve_ridge',
    'solve_logistic',
    'closed_form_ls',

    # Models
    'DummyModel',

    # Visualization
    'visualize_test_loss_reg',
    'visualize_prediction_reg',
    'visualize_test_loss_classification',
    'visualize_prediction_classification',

    # Regression MAML
    'meta_learning_reg_closed_form',
    'meta_learning_reg_sgd',
    'get_params_dict_reg',
    'get_params_dict_reg_sgd',
    'get_post_data_reg',
    'test_reg',
    'test_oracle_reg',
    'test_zero_reg',
    'meta_update_reg',

    # Classification MAML
    'meta_learning_classification',
    'get_params_dict_classification',
    'get_post_data_classification',
    'test_classification',
    'test_classification_zero',
    'test_classification_oracle',
    'meta_update_classification',

    # Widget utilities
    'generate_int_widget',
    'generate_float_widget',
    'generate_floatlog_widget',
]
