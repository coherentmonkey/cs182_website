"""
Data Generation and Featurization Utilities for MAML

This module provides functions for:
- Generating input data (x) with different sampling strategies
- Creating Fourier features for function approximation
- Generating target values (y) as linear combinations of features
- Adding noise to labels for robustness testing

Author: CS 282A Course Staff
"""

import numpy as np


def generate_x(n, x_type, x_low=-1, x_high=1):
    """
    Generate n sample points in the range [x_low, x_high].

    Args:
        n (int): Number of samples to generate
        x_type (str): Type of sampling strategy
            - 'grid': Evenly spaced points (useful for theory analysis)
            - 'uniform_random': Randomly sampled from uniform distribution
        x_low (float): Lower bound of the sampling range
        x_high (float): Upper bound of the sampling range

    Returns:
        np.ndarray: Array of shape (n,) containing the generated samples
    """
    if x_type == "grid":
        x = np.linspace(x_low, x_high, n, endpoint=False).astype(np.float64)
    elif x_type == "uniform_random":
        # Sort random samples for easier plotting
        x = np.sort(np.random.uniform(x_low, x_high, n).astype(np.float64))
    else:
        raise ValueError(
            f"Unknown x_type: {x_type}. Must be 'grid' or 'uniform_random'"
        )

    return x


def featurize_fourier(x, d, normalize=False):
    """
    Create Fourier features for input x.

    Constructs a feature matrix with:
    - First column: constant term (1)
    - Remaining columns: sin and cos terms of increasing frequencies

    The Fourier basis is: [1, sin(πx), cos(πx), sin(2πx), cos(2πx), ...]

    Args:
        x (np.ndarray): Input data of shape (n,)
        d (int): Number of features (must be odd)
        normalize (bool): Whether to normalize features to have unit norm

    Returns:
        np.ndarray: Feature matrix of shape (n, d)
    """
    assert (d - 1) % 2 == 0, "d must be odd for Fourier featurization"

    max_r = int((d - 1) / 2)
    n = len(x)
    A = np.zeros((n, d))

    # Constant term
    A[:, 0] = 1

    # Sin and cos terms for each frequency
    for d_ in range(1, max_r + 1):
        A[:, 2 * (d_ - 1) + 1] = np.sin(d_ * x * np.pi)
        A[:, 2 * (d_ - 1) + 2] = np.cos(d_ * x * np.pi)

    # Normalize if requested
    if normalize:
        A[:, 0] *= 1 / np.sqrt(2)
        A *= np.sqrt(2)

    return A


def featurize(x, d, phi_type, normalize=True):
    # Create features from input x using specified featurization type.
    function_map = {"fourier": featurize_fourier}

    if phi_type not in function_map:
        raise KeyError(
            f"Unknown phi_type: {phi_type}. Available: {list(function_map.keys())}"
        )

    return function_map[phi_type](x, d, normalize)


def generate_y(features, k_idx, k_val):
    # y as linear combination of features
    return np.sum(features[:, k_idx] * k_val, axis=1)


def add_label_noise(y, noise_prob):
    # Add label noise by randomly flipping signs with given probability.
    flip_mask = np.random.choice([-1, 1], p=[noise_prob, 1 - noise_prob], size=y.shape)
    return y * flip_mask
