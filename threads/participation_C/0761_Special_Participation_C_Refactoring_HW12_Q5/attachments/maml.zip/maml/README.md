# MAML Implementation - Modular Structure

This directory contains a refactored implementation of Model-Agnostic Meta-Learning (MAML) for regression and classification tasks. The code has been organized into well-documented utility modules for better maintainability and reusability. 

The Black formatter has been used to break down very long lines into idented sections for easier reliability. The code now follows the [Pep 8 Style Guide for Python Code](https://peps.python.org/pep-0008/).  Some documentation has been added in terms of captions manually as well as using AI to make some long functions easier to understand. The principle of one Python file being responsible for code related to a single task has been used.  

## Directory Structure

```
maml/
├── README.md                   # This file
├── q_maml.ipynb                # Main notebook (refactored to use modules)
├── data_utils.py               # Data generation and featurization
├── tensor_utils.py             # Tensor/array manipulation utilities
├── solvers.py                  # Closed-form solvers (LS, Ridge, Logistic)
├── models.py                   # PyTorch model definitions
├── visualization.py            # Plotting and visualization functions
├── test_functions.py           # MAML test functions for regression and classification
└── widget_utils.py             # IPyWidget utilities for notebooks
```

## Module Overview

### `data_utils.py`
Functions for generating training data and creating features:
- `generate_x()`: Sample input points (grid or random)
- `featurize()`: Create Fourier features from inputs
- `generate_y()`: Generate target values from features
- `add_label_noise()`: Add label noise for robustness testing

### `tensor_utils.py`
Utilities for working with tensors and arrays:
- `to_numpy()`, `to_tensor()`: Convert between NumPy and PyTorch
- `my_sign()`: Sign function that maps 0 to 1 (for classification)
- `print_dict_initialization()`: Debug utility for parameter dicts

### `solvers.py`
Closed-form solutions for various problems:
- `solve_ls()`: Least squares regression (min-norm solution)
- `solve_ridge()`: Ridge regression with L2 regularization
- `solve_logistic()`: Logistic regression for classification
- `closed_form_ls()`: Differentiable LS solution for PyTorch

### `models.py`
PyTorch models for meta-learning:
- `DummyModel`: Simple weighted feature model
  - `feature_weights`: Meta-parameters (learned across tasks)
  - `coeffs`: Task-specific parameters

### `visualization.py`
Visualization functions for experiments:
- `visualize_test_loss_reg()`: Plot regression test loss vs. n_train
- `visualize_prediction_reg()`: Show predictions on specific tasks
- `visualize_test_loss_classification()`: Plot classification error
- `visualize_prediction_classification()`: Show classification results

### `test_functions.py`
MAML test functions for regression and classification:
- `test_reg()`, `test_oracle_reg()`, `test_zero_reg()`: Regression evaluation functions
- `test_classification()`, `test_classification_oracle()`: Classification evaluation functions

### `widget_utils.py`
Helper functions for creating Jupyter widgets:
- `generate_int_widget()`: Integer slider
- `generate_float_widget()`: Float slider
- `generate_floatlog_widget()`: Logarithmic slider

## Usage

### In the Notebook

The refactored notebook imports from these modules:

```python
# Import all utilities
from data_utils import *
from tensor_utils import *
from solvers import *
from models import *
from visualization import *
from widget_utils import *
from test_functions import *
```

## Customization

### Adding New Features
To add polynomial features:
1. Add `featurize_polynomial()` to `data_utils.py`
2. Update the `function_map` in `featurize()`

### Adding New Solvers
To add SVM solver:
1. Add `solve_svm()` to `solvers.py`
2. Use it in classification instead of logistic regression

### Modifying Visualizations
All plotting code is in `visualization.py`. You can:
- Change color schemes
- Add new comparison baselines
- Modify plot layouts

## Dependencies

- `numpy`: Numerical operations
- `torch`: PyTorch for meta-learning
- `higher`: Higher-order gradients for MAML
- `matplotlib`: Visualization
- `sklearn`: Closed-form solvers (LinearRegression, Ridge, LogisticRegression)
- `ipywidgets`: Interactive widgets for notebooks

## Tips for Students

1. **Start with the notebook**: The refactored notebook shows how all modules work together
2. **Read comments**: Each function has comments explaining what it does
3. **Experiment with parameters**: Use the `get_params_dict_*()` functions as starting points
4. **Visualize results**: The visualization functions help understand meta-learning behavior
5. **Compare baselines**: Always compare meta-learned vs. oracle vs. baseline

## Common Issues

### Import Errors
Make sure you're running the notebook from the correct directory:
```bash
cd hw12/code/maml/
jupyter notebook q_maml.ipynb
```