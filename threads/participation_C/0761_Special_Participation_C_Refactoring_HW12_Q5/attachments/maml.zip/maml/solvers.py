"""
Closed-Form Solvers for Regression and Classification

This module provides closed-form solutions for:
- Least squares regression (min-norm solution)
- Ridge regression with L2 regularization
- Logistic regression for binary classification
- PyTorch-based closed-form least squares (for differentiable meta-learning)

Author: CS 282A Course Staff
"""

import numpy as np
import torch
from sklearn.linear_model import LinearRegression, Ridge, LogisticRegression

from tensor_utils import my_sign


def solve_ls(phi, y, weights=None):
    # Solve weighted least squares regression using closed-form solution.
    # Finds coefficients alpha that minimize: ||y - (phi * weights) @ alpha||^2

    d = phi.shape[1]
    if weights is None:
        weights = np.ones(d)

    # Apply feature weights
    phi_weighted = weights * phi

    # Fit linear regression (min-norm solution via pseudo-inverse)
    LR = LinearRegression(fit_intercept=False)
    LR.fit(phi_weighted, y)

    # Extract coefficients and reverse the weighting
    coeffs_weighted = LR.coef_
    alpha = coeffs_weighted * weights

    # Compute training loss
    loss = np.mean((y - phi @ alpha.T) ** 2)

    return alpha.T, loss


def solve_ridge(phi, y, lambda_ridge, weights=None):
    # Solve weighted ridge regression with L2 regularization.
    # Finds coefficients alpha that minimize: ||y - (phi * weights) @ alpha||^2 + lambda_ridge * ||alpha||^2

    d = phi.shape[1]
    if weights is None:
        weights = np.ones(d)

    # Apply feature weights
    phi_weighted = weights * phi

    # Fit ridge regression
    Rdg = Ridge(fit_intercept=False, alpha=lambda_ridge)
    Rdg.fit(phi_weighted, y)

    # Extract coefficients and reverse the weighting
    coeffs_weighted = Rdg.coef_
    alpha = coeffs_weighted * weights

    # Compute loss including regularization term
    loss = np.mean((y - phi @ alpha.T) ** 2) + lambda_ridge * np.sum(coeffs_weighted**2)

    return alpha, loss


def solve_logistic(phi, z, weights=None):
    # Solve weighted logistic regression for binary classification.
    # Finds coefficients alpha that minimize the logistic loss: -sum_i log(1 / (1 + exp(-z_i * <alpha, phi_weighted[i]>)))

    d = phi.shape[1]
    if weights is None:
        weights = np.ones(d)

    # Apply feature weights
    phi_weighted = weights * phi

    # Fit logistic regression with high C (low regularization) for near-closed-form
    clf = LogisticRegression(
        tol=1e-4,
        verbose=False,
        solver="lbfgs",
        random_state=0,
        fit_intercept=False,
        C=1e6,  # Very low regularization
    ).fit(phi_weighted, z)

    # Extract coefficients and reverse the weighting
    coeffs_weighted = clf.coef_
    alpha = coeffs_weighted * weights

    # Compute classification error
    z_pred = my_sign(phi @ alpha.T)[:, 0]
    loss = np.mean(z != z_pred)

    return alpha.T, loss


def closed_form_ls(F_t, y_t):
    # Compute min-norm solution: w = F^T @ (F @ F^T)^{-1} @ y
    w_t = F_t.T @ torch.inverse(F_t @ F_t.T) @ y_t
    return w_t
