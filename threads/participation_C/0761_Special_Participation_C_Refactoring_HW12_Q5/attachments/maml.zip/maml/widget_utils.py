"""
IPyWidget Utilities

This module provides helper functions for creating interactive widgets
in Jupyter notebooks for parameter tuning and experimentation.

Author: CS 282A Course Staff
"""

import ipywidgets as widgets


def generate_int_widget(desc, min_, val, max_, step=1):
    return widgets.IntSlider(
        value=val,
        min=min_,
        max=max_,
        step=step,
        description=desc,
        disabled=False,
        continuous_update=False,
        orientation="horizontal",
        readout=True,
        readout_format="d",
    )


def generate_float_widget(desc, min_, val, max_, step):
    return widgets.FloatSlider(
        value=val,
        min=min_,
        max=max_,
        step=step,
        description=desc,
        disabled=False,
        continuous_update=False,
        orientation="horizontal",
        readout=True,
        readout_format=".1f",
    )


def generate_floatlog_widget(desc, min_, step, val, max_, base=10):
    return widgets.FloatLogSlider(
        value=val,
        base=base,
        min=min_,  # max exponent of base
        max=max_,  # min exponent of base
        step=step,  # exponent step
        description=desc,
    )
