"""
Test Functions for MAML Regression and Classification

This module contains all testing and evaluation functions for MAML:
- Regression test functions
- Classification test functions
- Oracle and baseline test functions

Author: CS 282A Course Staff
"""

import numpy as np
from tensor_utils import my_sign
from solvers import solve_ls, solve_ridge, solve_logistic


# ============================================================================
# Regression Test Functions
# ============================================================================


def test_reg(data_dict, feature_weights, min_n_train_post=0):
    """
    Test feature weights on multiple tasks and training set sizes.

    Args:
        data_dict (dict): Dictionary with train and test data
        feature_weights (np.ndarray): Feature weights to evaluate
        min_n_train_post (int): Minimum training set size to test

    Returns:
        tuple: (n_train_post_range, avg_test_loss, top_10_loss, bot_10_loss)
            - n_train_post_range: Array of training set sizes tested
            - avg_test_loss: Average MSE across tasks
            - top_10_loss: 90th percentile MSE
            - bot_10_loss: 10th percentile MSE
    """
    test_loss_matrix = []

    n_train_post_range = np.sort(np.array(list(data_dict["train"].keys())))
    n_train_post_range = n_train_post_range[n_train_post_range >= min_n_train_post]

    test_data_dict = data_dict["test"]
    features_test_post = test_data_dict["features"]

    for n_train_post in n_train_post_range:
        train_data_dict = data_dict["train"][n_train_post]
        features_post = train_data_dict["features"]

        test_loss_array = []
        for i in range(len(train_data_dict["y"])):
            y_post = train_data_dict["y"][i]

            # Solve weighted least squares
            w_post, loss = solve_ls(features_post, y_post, feature_weights)
            y_post_pred = features_post @ w_post

            # Evaluate on test set
            y_test_post = test_data_dict["y"][i]
            y_test_post_pred = features_test_post @ w_post

            test_loss = np.mean((y_test_post - y_test_post_pred) ** 2)
            test_loss_array.append(test_loss)

        test_loss_matrix.append(test_loss_array)

    test_loss_matrix = np.array(test_loss_matrix).T
    avg_test_loss = np.mean(test_loss_matrix, axis=0)
    top_10_loss = np.percentile(test_loss_matrix, 90, axis=0)
    bot_10_loss = np.percentile(test_loss_matrix, 10, axis=0)

    return n_train_post_range, avg_test_loss, top_10_loss, bot_10_loss


def test_oracle_reg(data_dict, x_type, feature_weights, min_n_train_post=0):
    """
    Test oracle performance using only true features.

    Args:
        data_dict (dict): Dictionary with train and test data
        x_type (str): Sampling strategy ('grid' or 'uniform_random')
        feature_weights (np.ndarray): Binary weights indicating true features
        min_n_train_post (int): Minimum training set size to test

    Returns:
        tuple: (n_train_post_range, avg_test_loss, top_10_loss, bot_10_loss)
    """
    # Extract indices of non-zero features
    k_idx = np.where(feature_weights != 0)[0]
    feature_weights = None  # Use only selected features

    test_loss_matrix = []

    n_train_post_range = np.sort(np.array(list(data_dict["train"].keys())))
    n_train_post_range = n_train_post_range[n_train_post_range >= min_n_train_post]

    test_data_dict = data_dict["test"]
    features_test_post = test_data_dict["features"]

    for n_train_post in n_train_post_range:
        train_data_dict = data_dict["train"][n_train_post]

        # Use only true features
        features_post = train_data_dict["features"][:, k_idx]
        cfeatures_test_post = features_test_post[:, k_idx]

        # Remove zero-norm features (can happen with grid sampling)
        feature_norms = np.linalg.norm(features_post, axis=0)
        r_idx = np.where(feature_norms > 1e-6)[0]

        features_post = features_post[:, r_idx]
        cfeatures_test_post = cfeatures_test_post[:, r_idx]

        test_loss_array = []

        for i in range(len(train_data_dict["y"])):
            y_post = train_data_dict["y"][i]

            # Use ridge with small regularizer for grid to avoid ill-conditioning
            if x_type == "grid":
                w_post, loss = solve_ridge(
                    features_post, y_post, lambda_ridge=1e-12, weights=feature_weights
                )
            else:
                w_post, loss = solve_ls(features_post, y_post, weights=feature_weights)

            y_post_pred = features_post @ w_post
            y_test_post = test_data_dict["y"][i]
            y_test_post_pred = cfeatures_test_post @ w_post

            test_loss = np.mean((y_test_post - y_test_post_pred) ** 2)
            test_loss_array.append(test_loss)

        test_loss_matrix.append(test_loss_array)

    test_loss_matrix = np.array(test_loss_matrix).T
    avg_test_loss = np.mean(test_loss_matrix, axis=0)
    top_10_loss = np.percentile(test_loss_matrix, 90, axis=0)
    bot_10_loss = np.percentile(test_loss_matrix, 10, axis=0)

    return n_train_post_range, avg_test_loss, top_10_loss, bot_10_loss


def test_zero_reg(data_dict):
    """
    Test baseline performance of always predicting zero.

    Args:
        data_dict (dict): Dictionary with test data

    Returns:
        tuple: (avg_test_loss, top_10_loss, bot_10_loss)
    """
    test_data_dict = data_dict["test"]
    ys = test_data_dict["y"]

    test_loss_array = []
    for i in range(len(ys)):
        y = ys[i]
        # Loss when predicting zero everywhere
        test_loss = np.mean(y**2)
        test_loss_array.append(test_loss)

    avg_test_loss = np.mean(test_loss_array)
    top_10_loss = np.percentile(test_loss_array, 90)
    bot_10_loss = np.percentile(test_loss_array, 10)

    return avg_test_loss, top_10_loss, bot_10_loss


# ============================================================================
# Classification Test Functions
# ============================================================================


def test_classification(data_dict, feature_weights, min_n_train_post=0):
    """
    Test feature weights on multiple classification tasks.

    Args:
        data_dict (dict): Dictionary with train and test data
        feature_weights (np.ndarray): Feature weights to evaluate
        min_n_train_post (int): Minimum training set size to test

    Returns:
        tuple: (n_train_post_range, avg_test_loss, top_10_loss, bot_10_loss)
            - n_train_post_range: Array of training set sizes tested
            - avg_test_loss: Average classification error across tasks
            - top_10_loss: 90th percentile classification error
            - bot_10_loss: 10th percentile classification error
    """
    test_loss_matrix = []

    n_train_post_range = np.sort(np.array(list(data_dict["train"].keys())))
    n_train_post_range = n_train_post_range[n_train_post_range >= min_n_train_post]

    test_data_dict = data_dict["test"]
    features_test_post = test_data_dict["features"]

    for n_train_post in n_train_post_range:
        train_data_dict = data_dict["train"][n_train_post]
        features_post = train_data_dict["features"]

        test_loss_array = []
        for i in range(len(train_data_dict["y"])):
            y_post = train_data_dict["y"][i]
            z_post = np.squeeze(my_sign(y_post))

            # Solve weighted logistic regression
            w_post, loss = solve_logistic(features_post, z_post, feature_weights)
            y_post_pred = features_post @ w_post

            # Evaluate on test set
            y_test_post = test_data_dict["y"][i]
            y_test_post_pred = features_test_post @ w_post

            z_post_pred = np.squeeze(my_sign(y_post_pred))
            z_test_post = np.squeeze(my_sign(y_test_post))
            z_test_post_pred = np.squeeze(my_sign(y_test_post_pred))

            # Compute classification error
            test_loss = np.mean(z_test_post != z_test_post_pred)
            test_loss_array.append(test_loss)

        test_loss_matrix.append(test_loss_array)

    test_loss_matrix = np.array(test_loss_matrix).T
    avg_test_loss = np.mean(test_loss_matrix, axis=0)
    top_10_loss = np.percentile(test_loss_matrix, 90, axis=0)
    bot_10_loss = np.percentile(test_loss_matrix, 10, axis=0)

    return n_train_post_range, avg_test_loss, top_10_loss, bot_10_loss


def test_classification_zero(data_dict):
    """
    Test baseline performance of random label guessing.

    Args:
        data_dict (dict): Dictionary with test data

    Returns:
        tuple: (avg_test_loss, top_10_loss, bot_10_loss)
    """
    test_data_dict = data_dict["test"]
    ys = test_data_dict["y"]

    test_loss_array = []
    for i in range(len(ys)):
        y = ys[i]
        z = my_sign(y)
        # Random guessing
        z_guess = np.random.randint(low=-1, high=1, size=z.shape)
        z_guess = my_sign(z_guess)
        test_loss = np.mean(z != z_guess)
        test_loss_array.append(test_loss)

    avg_test_loss = np.mean(test_loss_array)
    top_10_loss = np.percentile(test_loss_array, 90)
    bot_10_loss = np.percentile(test_loss_array, 10)

    return avg_test_loss, top_10_loss, bot_10_loss


def test_classification_oracle(data_dict, x_type, feature_weights, min_n_train_post=0):
    """
    Test oracle performance using only true features for classification.

    Args:
        data_dict (dict): Dictionary with train and test data
        x_type (str): Sampling strategy ('grid' or 'uniform_random')
        feature_weights (np.ndarray): Binary weights indicating true features
        min_n_train_post (int): Minimum training set size to test

    Returns:
        tuple: (n_train_post_range, avg_test_loss, top_10_loss, bot_10_loss)
    """
    # Extract indices of non-zero features
    k_idx = np.where(feature_weights != 0)[0]
    feature_weights = None  # Use only selected features

    test_loss_matrix = []

    n_train_post_range = np.sort(np.array(list(data_dict["train"].keys())))
    n_train_post_range = n_train_post_range[n_train_post_range >= min_n_train_post]

    test_data_dict = data_dict["test"]
    features_test_post = test_data_dict["features"]

    for n_train_post in n_train_post_range:
        train_data_dict = data_dict["train"][n_train_post]

        # Use only true features
        features_post = train_data_dict["features"][:, k_idx]
        cfeatures_test_post = features_test_post[:, k_idx]

        # Remove zero-norm features (can happen with grid sampling)
        feature_norms = np.linalg.norm(features_post, axis=0)
        r_idx = np.where(feature_norms > 1e-6)[0]

        features_post = features_post[:, r_idx]
        cfeatures_test_post = cfeatures_test_post[:, r_idx]

        test_loss_array = []

        for i in range(len(train_data_dict["y"])):
            y_post = train_data_dict["y"][i]
            z_post = np.squeeze(my_sign(y_post))

            w_post, loss = solve_logistic(features_post, z_post, feature_weights)

            y_post_pred = features_post @ w_post
            y_test_post = test_data_dict["y"][i]
            y_test_post_pred = cfeatures_test_post @ w_post

            z_test_post = np.squeeze(my_sign(y_test_post))
            z_test_post_pred = np.squeeze(my_sign(y_test_post_pred))
            test_loss = np.mean(z_test_post != z_test_post_pred)

            test_loss_array.append(test_loss)

        test_loss_matrix.append(test_loss_array)

    test_loss_matrix = np.array(test_loss_matrix).T
    avg_test_loss = np.mean(test_loss_matrix, axis=0)
    top_10_loss = np.percentile(test_loss_matrix, 90, axis=0)
    bot_10_loss = np.percentile(test_loss_matrix, 10, axis=0)

    return n_train_post_range, avg_test_loss, top_10_loss, bot_10_loss
