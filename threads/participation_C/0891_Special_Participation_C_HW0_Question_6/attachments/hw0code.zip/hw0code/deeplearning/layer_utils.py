"""Convenience layer combinations for neural networks.

This module provides convenience functions that combine multiple layers into
single forward/backward operations. This simplifies the construction of
neural networks by reducing boilerplate code.
"""

from typing import Tuple, Dict
import numpy as np

from deeplearning.layers import *


def affine_relu_forward(x: np.ndarray, w: np.ndarray, b: np.ndarray) -> Tuple[np.ndarray, Tuple]:
    """Convenience layer that performs an affine transform followed by a ReLU.

    This is a common pattern in neural networks: a fully-connected layer
    followed by a ReLU activation. Combining them into a single function
    simplifies the forward pass code.

    Args:
        x: Input to the affine layer
        w: Weight matrix for the affine layer
        b: Bias vector for the affine layer

    Returns:
        A tuple of:
        - out: Output from the ReLU activation
        - cache: Tuple containing cache objects from both affine and ReLU
            forward passes, to be used in the backward pass
    """
    a, fc_cache = affine_forward(x, w, b)
    out, relu_cache = relu_forward(a)
    cache = (fc_cache, relu_cache)
    return out, cache


def affine_relu_backward(dout: np.ndarray, cache: Tuple) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Backward pass for the affine-relu convenience layer.

    This function computes gradients by chaining the backward passes of
    ReLU and affine layers in reverse order.

    Args:
        dout: Upstream derivative of shape matching the output of the
            forward pass
        cache: Tuple containing cache objects from the forward pass:
            - fc_cache: Cache from affine_forward
            - relu_cache: Cache from relu_forward

    Returns:
        A tuple of:
        - dx: Gradient with respect to x
        - dw: Gradient with respect to w
        - db: Gradient with respect to b
    """
    fc_cache, relu_cache = cache
    da = relu_backward(dout, relu_cache)
    dx, dw, db = affine_backward(da, fc_cache)
    return dx, dw, db


def conv_relu_forward(x: np.ndarray, w: np.ndarray, b: np.ndarray,
                      conv_param: Dict) -> Tuple[np.ndarray, Tuple]:
    """A convenience layer that performs a convolution followed by a ReLU.

    This is a common pattern in convolutional neural networks: a convolution
    layer followed by a ReLU activation.

    Args:
        x: Input to the convolutional layer
        w: Weight tensor for the convolutional layer
        b: Bias vector for the convolutional layer
        conv_param: Dictionary with convolution parameters (stride, pad, etc.)

    Returns:
        A tuple of:
        - out: Output from the ReLU activation
        - cache: Tuple containing cache objects from both convolution and ReLU
            forward passes, to be used in the backward pass
    """
    a, conv_cache = conv_forward_fast(x, w, b, conv_param)
    out, relu_cache = relu_forward(a)
    cache = (conv_cache, relu_cache)
    return out, cache


def conv_relu_backward(dout: np.ndarray, cache: Tuple) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Backward pass for the conv-relu convenience layer.

    This function computes gradients by chaining the backward passes of
    ReLU and convolution layers in reverse order.

    Args:
        dout: Upstream derivative of shape matching the output of the
            forward pass
        cache: Tuple containing cache objects from the forward pass:
            - conv_cache: Cache from conv_forward
            - relu_cache: Cache from relu_forward

    Returns:
        A tuple of:
        - dx: Gradient with respect to x
        - dw: Gradient with respect to w
        - db: Gradient with respect to b
    """
    conv_cache, relu_cache = cache
    da = relu_backward(dout, relu_cache)
    dx, dw, db = conv_backward_fast(da, conv_cache)
    return dx, dw, db


def conv_relu_pool_forward(x: np.ndarray, w: np.ndarray, b: np.ndarray,
                           conv_param: Dict, pool_param: Dict) -> Tuple[np.ndarray, Tuple]:
    """Convenience layer that performs a convolution, a ReLU, and a pool.

    This is a very common pattern in convolutional neural networks: a
    convolution layer, followed by ReLU activation, followed by pooling.
    Combining them simplifies the forward pass code.

    Args:
        x: Input to the convolutional layer
        w: Weight tensor for the convolutional layer
        b: Bias vector for the convolutional layer
        conv_param: Dictionary with convolution parameters (stride, pad, etc.)
        pool_param: Dictionary with pooling parameters (pool_height, pool_width,
            stride, etc.)

    Returns:
        A tuple of:
        - out: Output from the pooling layer
        - cache: Tuple containing cache objects from convolution, ReLU, and
            pooling forward passes, to be used in the backward pass
    """
    a, conv_cache = conv_forward_fast(x, w, b, conv_param)
    s, relu_cache = relu_forward(a)
    out, pool_cache = max_pool_forward_fast(s, pool_param)
    cache = (conv_cache, relu_cache, pool_cache)
    return out, cache


def conv_relu_pool_backward(dout: np.ndarray, cache: Tuple) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Backward pass for the conv-relu-pool convenience layer.

    This function computes gradients by chaining the backward passes of
    pooling, ReLU, and convolution layers in reverse order.

    Args:
        dout: Upstream derivative of shape matching the output of the
            forward pass
        cache: Tuple containing cache objects from the forward pass:
            - conv_cache: Cache from conv_forward
            - relu_cache: Cache from relu_forward
            - pool_cache: Cache from max_pool_forward

    Returns:
        A tuple of:
        - dx: Gradient with respect to x
        - dw: Gradient with respect to w
        - db: Gradient with respect to b
    """
    conv_cache, relu_cache, pool_cache = cache
    ds = max_pool_backward_fast(dout, pool_cache)
    da = relu_backward(ds, relu_cache)
    dx, dw, db = conv_backward_fast(da, conv_cache)
    return dx, dw, db
