"""First-order optimization update rules for training neural networks.

This module implements various first-order update rules that are commonly used
for training neural networks. Each update rule accepts current weights and the
gradient of the loss with respect to those weights and produces the next set of
weights. Each update rule has the same interface:

def update(w, dw, config=None):

Inputs:
  - w: A numpy array giving the current weights.
  - dw: A numpy array of the same shape as w giving the gradient of the
    loss with respect to w.
  - config: A dictionary containing hyperparameter values such as learning rate,
    momentum, etc. If the update rule requires caching values over many
    iterations, then config will also hold these cached values.

Returns:
  - next_w: The next point after the update.
  - config: The config dictionary to be passed to the next iteration of the
    update rule.

NOTE: For most update rules, the default learning rate will probably not perform
well; however the default values of the other hyperparameters should work well
for a variety of different problems.

For efficiency, update rules may perform in-place updates, mutating w and
setting next_w equal to w.
"""

from typing import Tuple, Dict, Optional
import numpy as np


def sgd(w: np.ndarray, dw: np.ndarray,
        config: Optional[Dict[str, float]] = None) -> Tuple[np.ndarray, Dict[str, float]]:
    """Performs vanilla stochastic gradient descent.

    The update rule is: w = w - learning_rate * dw

    This is the simplest optimization algorithm and serves as a baseline for
    more sophisticated methods.

    Args:
        w: A numpy array giving the current weights
        dw: A numpy array of the same shape as w giving the gradient of the
            loss with respect to w
        config: Optional dictionary containing hyperparameters:
            - learning_rate: Scalar learning rate (default: 1e-2)

    Returns:
        A tuple of:
        - next_w: The updated weights (same array as w, modified in-place)
        - config: The config dictionary (may be modified to store state)
    """
    if config is None: config = {}
    config.setdefault('learning_rate', 1e-2)

    w -= config['learning_rate'] * dw
    return w, config
