"""Numerical gradient checking utilities.

This module provides functions for computing numerical gradients, which are
useful for verifying the correctness of analytical gradient implementations
in neural networks. Numerical gradients are computed using finite differences.
"""

from typing import Callable, Tuple, List, Any
import numpy as np
from random import randrange


def eval_numerical_gradient(f: Callable[[np.ndarray], float], x: np.ndarray,
                            verbose: bool = True, h: float = 0.00001) -> np.ndarray:
    """A naive implementation of numerical gradient of f at x.

    This function computes the gradient numerically using the centered
    difference formula: f'(x) ≈ (f(x+h) - f(x-h)) / (2h)

    Args:
        f: A function that takes a single argument (numpy array) and returns
            a scalar value
        x: A numpy array representing the point at which to evaluate the
            gradient
        verbose: Boolean indicating whether to print gradient values as they
            are computed (default: True)
        h: Step size for finite differences (default: 0.00001)

    Returns:
        grad: A numpy array of the same shape as x containing the numerical
            gradient of f at x
    """

    fx = f(x)  # Evaluate function value at original point
    grad = np.zeros_like(x)
    # Iterate over all indexes in x using numpy's nditer for efficiency
    it = np.nditer(x, flags=['multi_index'], op_flags=['readwrite'])
    while not it.finished:
        # Evaluate function at x+h and x-h for centered difference
        ix = it.multi_index
        oldval = x[ix]
        x[ix] = oldval + h  # Increment by h
        fxph = f(x)  # Evaluate f(x + h)
        x[ix] = oldval - h  # Decrement by h
        fxmh = f(x)  # Evaluate f(x - h)
        x[ix] = oldval  # Restore original value

        # Compute the partial derivative with centered difference formula
        # This is more accurate than forward/backward differences
        grad[ix] = (fxph - fxmh) / (2 * h)
        if verbose:
            print(ix, grad[ix])
        it.iternext()  # Step to next dimension

    return grad


def eval_numerical_gradient_array(f: Callable[[np.ndarray], np.ndarray],
                                  x: np.ndarray, df: np.ndarray,
                                  h: float = 1e-5) -> np.ndarray:
    """Evaluate a numeric gradient for a function that accepts and returns arrays.

    This function is similar to eval_numerical_gradient but works with functions
    that return arrays rather than scalars. It computes the gradient by taking
    the dot product of the output difference with the upstream gradient df.

    Args:
        f: A function that takes a numpy array and returns a numpy array
        x: A numpy array representing the point at which to evaluate the gradient
        df: Upstream gradient of shape matching f(x), used to compute the
            gradient with respect to x via chain rule
        h: Step size for finite differences (default: 1e-5)

    Returns:
        grad: A numpy array of the same shape as x containing the numerical
            gradient
    """
    grad = np.zeros_like(x)
    it = np.nditer(x, flags=['multi_index'], op_flags=['readwrite'])
    while not it.finished:
        ix = it.multi_index

        # Compute f(x+h) and f(x-h)
        oldval = x[ix]
        x[ix] = oldval + h
        pos = f(x).copy()
        x[ix] = oldval - h
        neg = f(x).copy()
        x[ix] = oldval  # Restore original value

        # Gradient is computed via chain rule: dL/dx = dL/df * df/dx
        # We compute df/dx numerically and take dot product with upstream grad
        grad[ix] = np.sum((pos - neg) * df) / (2 * h)
        it.iternext()
    return grad


def eval_numerical_gradient_blobs(f: Callable, inputs: Tuple[Any, ...],
                                   output: Any, h: float = 1e-5) -> List[np.ndarray]:
    """Compute numeric gradients for a function that operates on input/output blobs.

    This function is designed for a blob-based API where functions write their
    outputs to a provided output blob rather than returning values.

    We assume that f accepts several input blobs as arguments, followed by a blob
    into which outputs will be written. For example, f might be called like this:

    f(x, w, out)

    where x and w are input Blobs, and the result of f will be written to out.

    Args:
        f: Function that operates on blobs
        inputs: Tuple of input blobs
        output: Output blob containing the result and gradient information
        h: Step size for finite differences (default: 1e-5)

    Returns:
        numeric_diffs: List of gradient arrays, one for each input blob
    """
    numeric_diffs = []
    for input_blob in inputs:
        diff = np.zeros_like(input_blob.diffs)
        it = np.nditer(input_blob.vals, flags=['multi_index'],
                       op_flags=['readwrite'])
        while not it.finished:
            idx = it.multi_index
            orig = input_blob.vals[idx]

            input_blob.vals[idx] = orig + h
            f(*(inputs + (output,)))
            pos = np.copy(output.vals)
            input_blob.vals[idx] = orig - h
            f(*(inputs + (output,)))
            neg = np.copy(output.vals)
            input_blob.vals[idx] = orig

            diff[idx] = np.sum((pos - neg) * output.diffs) / (2.0 * h)

            it.iternext()
        numeric_diffs.append(diff)
    return numeric_diffs


def eval_numerical_gradient_net(net: Any, inputs: Tuple[Any, ...],
                                 output: Any, h: float = 1e-5) -> List[np.ndarray]:
    """Compute numeric gradients for a network using blob-based API.

    This is a convenience wrapper around eval_numerical_gradient_blobs that
    works with network objects that have a forward() method.

    Args:
        net: Network object with a forward() method
        inputs: Tuple of input blobs
        output: Output blob
        h: Step size for finite differences (default: 1e-5)

    Returns:
        numeric_diffs: List of gradient arrays, one for each input blob
    """
    return eval_numerical_gradient_blobs(lambda *args: net.forward(),
                                         inputs, output, h=h)


def grad_check_sparse(f: Callable[[np.ndarray], float], x: np.ndarray,
                      analytic_grad: np.ndarray, num_checks: int = 10,
                      h: float = 1e-5) -> None:
    """Sample a few random elements and check numerical vs analytical gradients.

    This function is useful for large arrays where computing the full numerical
    gradient would be too slow. Instead, it randomly samples a few elements
    and compares the numerical and analytical gradients at those locations.

    Args:
        f: A function that takes a numpy array and returns a scalar
        x: A numpy array representing the point at which to evaluate gradients
        analytic_grad: The analytical gradient of f at x (computed via
            backpropagation), of the same shape as x
        num_checks: Number of random elements to check (default: 10)
        h: Step size for finite differences (default: 1e-5)
    """

    for i in range(num_checks):
        # Randomly sample an index from the array
        ix = tuple([randrange(m) for m in x.shape])

        # Compute numerical gradient at this index using centered difference
        oldval = x[ix]
        x[ix] = oldval + h  # Increment by h
        fxph = f(x)  # Evaluate f(x + h)
        x[ix] = oldval - h  # Decrement by h
        fxmh = f(x)  # Evaluate f(x - h)
        x[ix] = oldval  # Reset to original value

        # Compare numerical and analytical gradients
        grad_numerical = (fxph - fxmh) / (2 * h)
        grad_analytic = analytic_grad[ix]
        # Relative error: |num - ana| / (|num| + |ana|)
        # This is more robust than absolute error when gradients are small
        rel_error = abs(grad_numerical - grad_analytic) / (
            abs(grad_numerical) + abs(grad_analytic))
        print('numerical: %f analytic: %f, relative error: %e' % (
            grad_numerical, grad_analytic, rel_error))
