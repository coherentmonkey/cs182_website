"""Visualization utilities for image data.

This module provides functions for visualizing image data in grid formats,
which is useful for displaying batches of images or visualizing learned
features in neural networks.
"""

from typing import List
from math import sqrt, ceil
import numpy as np


def visualize_grid(Xs: np.ndarray, ubound: float = 255.0,
                    padding: int = 1) -> np.ndarray:
    """Reshape a 4D tensor of image data to a grid for easy visualization.

    This function arranges a batch of images into a square grid layout,
    scaling pixel values to the specified range and adding padding between
    images.

    Args:
        Xs: Data of shape (N, H, W, C) where N is the number of images,
            H and W are height and width, and C is the number of channels
        ubound: Output grid will have values scaled to the range [0, ubound]
            (default: 255.0)
        padding: The number of blank pixels between elements of the grid
            (default: 1)

    Returns:
        grid: A numpy array of shape (grid_height, grid_width, C) containing
            the arranged images
    """
    (N, H, W, C) = Xs.shape
    # Calculate grid size: arrange images in a roughly square grid
    grid_size = int(ceil(sqrt(N)))
    # Calculate total grid dimensions including padding
    grid_height = H * grid_size + padding * (grid_size - 1)
    grid_width = W * grid_size + padding * (grid_size - 1)
    grid = np.zeros((grid_height, grid_width, C))
    
    # Place each image in the grid
    next_idx = 0
    y0, y1 = 0, H
    for y in range(grid_size):
        x0, x1 = 0, W
        for x in range(grid_size):
            if next_idx < N:
                img = Xs[next_idx]
                # Normalize each image individually to [0, ubound]
                # This ensures each image uses the full dynamic range
                low, high = np.min(img), np.max(img)
                if high > low:  # Avoid division by zero
                    grid[y0:y1, x0:x1] = ubound * (img - low) / (high - low)
                else:
                    grid[y0:y1, x0:x1] = img
                next_idx += 1
            # Move to next column position
            x0 += W + padding
            x1 += W + padding
        # Move to next row position
        y0 += H + padding
        y1 += H + padding
    return grid


def vis_grid(Xs: np.ndarray) -> np.ndarray:
    """Visualize a grid of images with automatic normalization.

    This is a simpler version of visualize_grid that uses a different
    normalization strategy (normalizing the entire grid rather than each
    image individually).

    Args:
        Xs: Data of shape (N, H, W, C) where N is the number of images,
            H and W are height and width, and C is the number of channels

    Returns:
        G: A numpy array of shape (grid_height, grid_width, C) containing
            the arranged images, normalized to [0, 1]
    """
    (N, H, W, C) = Xs.shape
    # Calculate grid size
    A = int(ceil(sqrt(N)))
    # Initialize grid with minimum value (for padding)
    G = np.ones((A * H + A, A * W + A, C), Xs.dtype)
    G *= np.min(Xs)
    
    # Place each image in the grid with 1-pixel padding
    n = 0
    for y in range(A):
        for x in range(A):
            if n < N:
                # Place image at position (y, x) with padding
                G[y * H + y:(y + 1) * H + y,
                  x * W + x:(x + 1) * W + x, :] = Xs[n, :, :, :]
                n += 1
    
    # Normalize entire grid to [0, 1] range
    maxg = G.max()
    ming = G.min()
    if maxg > ming:  # Avoid division by zero
        G = (G - ming) / (maxg - ming)
    return G


def vis_nn(rows: List[List[np.ndarray]]) -> np.ndarray:
    """Visualize a nested array structure of images.

    This function is useful for visualizing multiple rows of images, where
    each row contains multiple images. For example, this could represent
    different layers of a neural network or different feature maps.

    Args:
        rows: A list of lists, where rows[i] is a list of images. All images
            should have the same shape (H, W, C)

    Returns:
        G: A numpy array containing all images arranged in a grid, normalized
            to [0, 1] range
    """
    N = len(rows)  # Number of rows
    D = len(rows[0])  # Number of images per row
    H, W, C = rows[0][0].shape  # Image dimensions
    Xs = rows[0][0]
    
    # Initialize grid with padding
    G = np.ones((N * H + N, D * W + D, C), Xs.dtype)
    
    # Place each image in the grid
    for y in range(N):
        for x in range(D):
            G[y * H + y:(y + 1) * H + y,
              x * W + x:(x + 1) * W + x, :] = rows[y][x]
    
    # Normalize entire grid to [0, 1] range
    maxg = G.max()
    ming = G.min()
    if maxg > ming:  # Avoid division by zero
        G = (G - ming) / (maxg - ming)
    return G
