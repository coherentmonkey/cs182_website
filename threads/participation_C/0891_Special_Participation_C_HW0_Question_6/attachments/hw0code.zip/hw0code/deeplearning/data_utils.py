"""Data loading and preprocessing utilities.

This module provides functions for loading and preprocessing common datasets
used in deep learning, including CIFAR-10 and TinyImageNet.
"""

from typing import Tuple, Dict, List, Optional, Any
import pickle
import numpy as np
import os
from imageio import imread


def load_CIFAR_batch(filename: str) -> Tuple[np.ndarray, np.ndarray]:
    """Load a single batch of CIFAR-10 data.

    CIFAR-10 batches contain 10,000 images of shape (32, 32, 3) along with
    their labels.

    Args:
        filename: String path to the CIFAR-10 batch file (pickle format)

    Returns:
        A tuple of:
        - X: Array of images of shape (10000, 32, 32, 3) with dtype float
        - Y: Array of labels of shape (10000,)
    """
    print(filename)
    with open(filename, 'rb') as f:
        datadict = pickle.load(f, encoding='bytes')
        X = datadict[b'data']
        Y = datadict[b'labels']
        X = X.reshape(10000, 3, 32, 32).transpose(0, 2, 3, 1).astype("float")
        Y = np.array(Y)
        return X, Y


def load_CIFAR10(ROOT: str) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Load all CIFAR-10 training and test data.

    CIFAR-10 consists of 5 training batches and 1 test batch, each containing
    10,000 images.

    Args:
        ROOT: String path to the directory containing CIFAR-10 batch files

    Returns:
        A tuple of:
        - Xtr: Training images of shape (50000, 32, 32, 3)
        - Ytr: Training labels of shape (50000,)
        - Xte: Test images of shape (10000, 32, 32, 3)
        - Yte: Test labels of shape (10000,)
    """
    xs = []
    ys = []
    for b in range(1, 6):
        f = os.path.join(ROOT, 'data_batch_%d' % (b,))
        X, Y = load_CIFAR_batch(f)
        xs.append(X)
        ys.append(Y)
    Xtr = np.concatenate(xs)
    Ytr = np.concatenate(ys)
    del X, Y
    Xte, Yte = load_CIFAR_batch(os.path.join(ROOT, 'test_batch'))
    return Xtr, Ytr, Xte, Yte


def get_CIFAR10_data(num_training: int = 49000, num_validation: int = 1000,
                     num_test: int = 1000) -> Dict[str, np.ndarray]:
    """Load and preprocess CIFAR-10 dataset for neural network training.

    This function loads the CIFAR-10 dataset, splits it into training,
    validation, and test sets, normalizes the data by subtracting the mean
    image, and transposes images to channel-first format (N, C, H, W).

    Args:
        num_training: Number of training examples to use (default: 49000)
        num_validation: Number of validation examples to use (default: 1000)
        num_test: Number of test examples to use (default: 1000)

    Returns:
        A dictionary with the following keys:
        - 'X_train': Training images of shape (num_training, 3, 32, 32)
        - 'y_train': Training labels of shape (num_training,)
        - 'X_val': Validation images of shape (num_validation, 3, 32, 32)
        - 'y_val': Validation labels of shape (num_validation,)
        - 'X_test': Test images of shape (num_test, 3, 32, 32)
        - 'y_test': Test labels of shape (num_test,)
    """
    # Load the raw CIFAR-10 data
    cifar10_dir = 'deeplearning/datasets/cifar-10-batches-py'
    X_train, y_train, X_test, y_test = load_CIFAR10(cifar10_dir)

    # Subsample the data: split training into train and validation sets
    mask = range(num_training, num_training + num_validation)
    X_val = X_train[mask]
    y_val = y_train[mask]
    mask = range(num_training)
    X_train = X_train[mask]
    y_train = y_train[mask]
    mask = range(num_test)
    X_test = X_test[mask]
    y_test = y_test[mask]

    # Normalize the data: subtract the mean image
    # This centers the data around zero, which helps with training stability
    mean_image = np.mean(X_train, axis=0)
    X_train -= mean_image
    X_val -= mean_image
    X_test -= mean_image

    # Transpose so that channels come first: (N, H, W, C) -> (N, C, H, W)
    # This format is more efficient for convolutional operations
    X_train = X_train.transpose(0, 3, 1, 2).copy()
    X_val = X_val.transpose(0, 3, 1, 2).copy()
    X_test = X_test.transpose(0, 3, 1, 2).copy()

    # Package data into a dictionary
    return {
        'X_train': X_train, 'y_train': y_train,
        'X_val': X_val, 'y_val': y_val,
        'X_test': X_test, 'y_test': y_test,
    }


def load_tiny_imagenet(path: str, dtype: type = np.float32) -> Tuple[List[List[str]], np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, Optional[np.ndarray]]:
    """Load TinyImageNet dataset.

    Each of TinyImageNet-100-A, TinyImageNet-100-B, and TinyImageNet-200 have
    the same directory structure, so this function can be used to load any of
    them.

    Args:
        path: String giving path to the directory to load
        dtype: Numpy datatype used to load the data (default: np.float32)

    Returns:
        A tuple of:
        - class_names: A list where class_names[i] is a list of strings giving
            the WordNet names for class i in the loaded dataset
        - X_train: Array of shape (N_tr, 3, 64, 64) containing training images
        - y_train: Array of shape (N_tr,) containing training labels
        - X_val: Array of shape (N_val, 3, 64, 64) containing validation images
        - y_val: Array of shape (N_val,) containing validation labels
        - X_test: Array of shape (N_test, 3, 64, 64) containing testing images
        - y_test: Array of shape (N_test,) containing test labels; if test labels
            are not available (such as in student code) then y_test will be None
    """
    # First load wnids (WordNet IDs) which identify each class
    with open(os.path.join(path, 'wnids.txt'), 'r') as f:
        wnids = [x.strip() for x in f]

    # Map wnids to integer labels for easier indexing
    wnid_to_label = {wnid: i for i, wnid in enumerate(wnids)}

    # Use words.txt to get human-readable names for each class
    with open(os.path.join(path, 'words.txt'), 'r') as f:
        wnid_to_words = dict(line.split('\t') for line in f)
        # Split comma-separated synonyms into a list
        for wnid, words in wnid_to_words.items():
            wnid_to_words[wnid] = [w.strip() for w in words.split(',')]
    class_names = [wnid_to_words[wnid] for wnid in wnids]

    # Next load training data.
    X_train = []
    y_train = []
    for i, wnid in enumerate(wnids):
        if (i + 1) % 20 == 0:
            print
            'loading training data for synset %d / %d' % (i + 1, len(wnids))
        # To figure out the filenames we need to open the boxes file
        boxes_file = os.path.join(path, 'train', wnid, '%s_boxes.txt' % wnid)
        with open(boxes_file, 'r') as f:
            filenames = [x.split('\t')[0] for x in f]
        num_images = len(filenames)

        X_train_block = np.zeros((num_images, 3, 64, 64), dtype=dtype)
        y_train_block = wnid_to_label[wnid] * np.ones(num_images, dtype=np.int64)
        for j, img_file in enumerate(filenames):
            img_file = os.path.join(path, 'train', wnid, 'images', img_file)
            img = imread(img_file)
            # Handle grayscale images by adding a channel dimension
            if img.ndim == 2:
                img.shape = (64, 64, 1)
            # Transpose from (H, W, C) to (C, H, W) format
            X_train_block[j] = img.transpose(2, 0, 1)
        X_train.append(X_train_block)
        y_train.append(y_train_block)

    # We need to concatenate all training data
    X_train = np.concatenate(X_train, axis=0)
    y_train = np.concatenate(y_train, axis=0)

    # Next load validation data
    with open(os.path.join(path, 'val', 'val_annotations.txt'), 'r') as f:
        img_files = []
        val_wnids = []
        for line in f:
            img_file, wnid = line.split('\t')[:2]
            img_files.append(img_file)
            val_wnids.append(wnid)
        num_val = len(img_files)
        y_val = np.array([wnid_to_label[wnid] for wnid in val_wnids])
        X_val = np.zeros((num_val, 3, 64, 64), dtype=dtype)
        for i, img_file in enumerate(img_files):
            img_file = os.path.join(path, 'val', 'images', img_file)
            img = imread(img_file)
            if img.ndim == 2:
                img.shape = (64, 64, 1)
            X_val[i] = img.transpose(2, 0, 1)

    # Next load test images
    # Students won't have test labels, so we need to iterate over files in the
    # images directory.
    img_files = os.listdir(os.path.join(path, 'test', 'images'))
    X_test = np.zeros((len(img_files), 3, 64, 64), dtype=dtype)
    for i, img_file in enumerate(img_files):
        img_file = os.path.join(path, 'test', 'images', img_file)
        img = imread(img_file)
        if img.ndim == 2:
            img.shape = (64, 64, 1)
        X_test[i] = img.transpose(2, 0, 1)

    y_test = None
    y_test_file = os.path.join(path, 'test', 'test_annotations.txt')
    if os.path.isfile(y_test_file):
        with open(y_test_file, 'r') as f:
            img_file_to_wnid = {}
            for line in f:
                line = line.split('\t')
                img_file_to_wnid[line[0]] = line[1]
        y_test = [wnid_to_label[img_file_to_wnid[img_file]] for img_file in img_files]
        y_test = np.array(y_test)

    return class_names, X_train, y_train, X_val, y_val, X_test, y_test


def load_models(models_dir: str) -> Dict[str, Any]:
    """Load saved models from disk.

    This function attempts to unpickle all files in a directory. Any files
    that give errors on unpickling (such as README.txt) will be skipped.

    Args:
        models_dir: String giving the path to a directory containing model files.
            Each model file should be a pickled dictionary with a 'model' field.

    Returns:
        A dictionary mapping model file names to model objects
    """
    models = {}
    for model_file in os.listdir(models_dir):
        with open(os.path.join(models_dir, model_file), 'rb') as f:
            try:
                models[model_file] = pickle.load(f)['model']
            except pickle.UnpicklingError:
                continue
    return models
