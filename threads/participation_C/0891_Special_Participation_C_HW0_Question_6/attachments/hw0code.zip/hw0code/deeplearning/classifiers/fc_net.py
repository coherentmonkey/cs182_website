"""Fully-connected neural network implementations.

This module provides implementations of fully-connected neural networks
for classification tasks, including two-layer and multi-layer architectures.
"""

from typing import Dict, Optional, Union, List, Tuple
import numpy as np

from deeplearning.layers import *
from deeplearning.layer_utils import *


class TwoLayerNet(object):
    """A two-layer fully-connected neural network with ReLU nonlinearity.

    This network uses a modular layer design with the architecture:
    affine - relu - affine - softmax

    We assume an input dimension of D, a hidden dimension of H, and perform
    classification over C classes.

    Note that this class does not implement gradient descent; instead, it
    will interact with a separate Solver object that is responsible for running
    optimization.

    The learnable parameters of the model are stored in the dictionary
    self.params that maps parameter names to numpy arrays.

    Attributes:
        params: Dictionary mapping parameter names to numpy arrays:
            - 'W1': First layer weights of shape (D, H)
            - 'b1': First layer biases of shape (H,)
            - 'W2': Second layer weights of shape (H, C)
            - 'b2': Second layer biases of shape (C,)
        reg: L2 regularization strength (scalar)
    """

    def __init__(self, input_dim: int = 3 * 32 * 32, hidden_dim: int = 100,
                 num_classes: int = 10, weight_scale: float = 1e-3,
                 reg: float = 0.0) -> None:
        """Initialize a new two-layer network.

        Weights are initialized from a Gaussian distribution with standard
        deviation equal to weight_scale. Biases are initialized to zero.

        Args:
            input_dim: An integer giving the size of the input (default: 3072
                for CIFAR-10 images: 3 * 32 * 32)
            hidden_dim: An integer giving the size of the hidden layer
            num_classes: An integer giving the number of classes to classify
            weight_scale: Scalar giving the standard deviation for random
                initialization of the weights
            reg: Scalar giving L2 regularization strength
        """
        self.params = {}
        self.reg = reg

        ############################################################################
        # TODO: Initialize the weights and biases of the two-layer net. Weights    #
        # should be initialized from a Gaussian with standard deviation equal to   #
        # weight_scale, and biases should be initialized to zero. All weights and  #
        # biases should be stored in the dictionary self.params, with first layer  #
        # weights and biases using the keys 'W1' and 'b1' and second layer weights #
        # and biases using the keys 'W2' and 'b2'.                                 #
        ############################################################################
        ############################################################################
        #                             END OF YOUR CODE                             #
        ############################################################################

    def loss(self, X: np.ndarray, y: Optional[np.ndarray] = None) -> Union[np.ndarray, Tuple[float, Dict[str, np.ndarray]]]:
        """Compute loss and gradient for a minibatch of data.

        This method performs either a test-time forward pass (when y is None)
        or a training-time forward and backward pass (when y is provided).

        Args:
            X: Array of input data of shape (N, d_1, ..., d_k) where N is the
                batch size
            y: Optional array of labels of shape (N,). y[i] gives the label
                for X[i]. If None, performs test-time forward pass only.

        Returns:
            If y is None (test mode):
                scores: Array of shape (N, C) giving classification scores,
                    where scores[i, c] is the classification score for X[i]
                    and class c.

            If y is not None (training mode):
                A tuple of:
                - loss: Scalar value giving the total loss (data loss + L2
                    regularization loss)
                - grads: Dictionary with the same keys as self.params, mapping
                    parameter names to gradients of the loss with respect to
                    those parameters
        """
        scores = None
        ############################################################################
        # TODO: Implement the forward pass for the two-layer net, computing the    #
        # class scores for X and storing them in the scores variable.              #
        ############################################################################
        ############################################################################
        #                             END OF YOUR CODE                             #
        ############################################################################

        # If y is None then we are in test mode so just return scores
        if y is None:
            return scores

        loss, grads = 0, {}
        ############################################################################
        # TODO: Implement the backward pass for the two-layer net. Store the loss  #
        # in the loss variable and gradients in the grads dictionary. Compute data #
        # loss using softmax, and make sure that grads[k] holds the gradients for  #
        # self.params[k]. Don't forget to add L2 regularization on the weights,    #
        # but not the biases.                                                      #
        #                                                                          #
        # NOTE: To ensure that your implementation matches ours and you pass the   #
        # automated tests, make sure that your L2 regularization includes a factor #
        # of 0.5 to simplify the expression for the gradient.                      #
        ############################################################################
        ############################################################################
        #                             END OF YOUR CODE                             #
        ############################################################################

        return loss, grads


class FullyConnectedNet(object):
    """A fully-connected neural network with an arbitrary number of hidden layers.

    This network uses ReLU nonlinearities and a softmax loss function. It supports
    optional dropout and batch normalization. For a network with L layers, the
    architecture will be:

    {affine - [batch norm] - relu - [dropout]} x (L - 1) - affine - softmax

    where batch normalization and dropout are optional, and the {...} block is
    repeated L - 1 times.

    Similar to the TwoLayerNet above, learnable parameters are stored in the
    self.params dictionary and will be learned using the Solver class.

    Attributes:
        use_batchnorm: Boolean indicating whether batch normalization is used
        use_dropout: Boolean indicating whether dropout is used
        reg: L2 regularization strength (scalar)
        num_layers: Total number of layers (including output layer)
        dtype: Numpy datatype for all computations
        params: Dictionary mapping parameter names to numpy arrays
        dropout_param: Dictionary with dropout parameters (if dropout is used)
        bn_params: List of dictionaries with batch normalization parameters
            (if batch normalization is used)
    """

    def __init__(self, hidden_dims: List[int], input_dim: int = 3 * 32 * 32,
                 num_classes: int = 10, dropout: float = 0,
                 use_batchnorm: bool = False, reg: float = 0.0,
                 weight_scale: float = 1e-2, dtype: type = np.float32,
                 seed: Optional[int] = None) -> None:
        """Initialize a new FullyConnectedNet.

        Weights are initialized from a normal distribution with standard
        deviation equal to weight_scale. Biases are initialized to zero.

        Args:
            hidden_dims: A list of integers giving the size of each hidden layer
            input_dim: An integer giving the size of the input (default: 3072
                for CIFAR-10 images: 3 * 32 * 32)
            num_classes: An integer giving the number of classes to classify
            dropout: Scalar between 0 and 1 giving dropout strength. If dropout=0
                then the network should not use dropout at all
            use_batchnorm: Boolean indicating whether the network should use
                batch normalization
            reg: Scalar giving L2 regularization strength
            weight_scale: Scalar giving the standard deviation for random
                initialization of the weights
            dtype: A numpy datatype object; all computations will be performed
                using this datatype. float32 is faster but less accurate, so you
                should use float64 for numeric gradient checking
            seed: If not None, then pass this random seed to the dropout layers.
                This will make the dropout layers deterministic so we can gradient
                check the model
        """
        self.use_batchnorm = use_batchnorm
        self.use_dropout = dropout > 0
        self.reg = reg
        self.num_layers = 1 + len(hidden_dims)
        self.dtype = dtype
        self.params = {}

        ############################################################################
        # TODO: Initialize the parameters of the network, storing all values in    #
        # the self.params dictionary. Store weights and biases for the first layer #
        # in W1 and b1; for the second layer use W2 and b2, etc. Weights should be #
        # initialized from a normal distribution with standard deviation equal to  #
        # weight_scale and biases should be initialized to zero.                   #
        #                                                                          #
        ############################################################################
        ############################################################################
        #                             END OF YOUR CODE                             #
        ############################################################################

        # When using dropout we need to pass a dropout_param dictionary to each
        # dropout layer so that the layer knows the dropout probability and the mode
        # (train / test). You can pass the same dropout_param to each dropout layer.
        self.dropout_param = {}
        if self.use_dropout:
            self.dropout_param = {'mode': 'train', 'p': dropout}
            if seed is not None:
                self.dropout_param['seed'] = seed

        # With batch normalization we need to keep track of running means and
        # variances, so we need to pass a special bn_param object to each batch
        # normalization layer. You should pass self.bn_params[0] to the forward pass
        # of the first batch normalization layer, self.bn_params[1] to the forward
        # pass of the second batch normalization layer, etc.
        self.bn_params = []
        if self.use_batchnorm:
            self.bn_params = [{'mode': 'train'}
                              for _ in range(self.num_layers - 1)]

        # Cast all parameters to the correct datatype
        for k, v in self.params.items():
            self.params[k] = v.astype(dtype)

    def loss(self, X: np.ndarray, y: Optional[np.ndarray] = None) -> Union[np.ndarray, Tuple[float, Dict[str, np.ndarray]]]:
        """Compute loss and gradient for the fully-connected net.

        This method performs either a test-time forward pass (when y is None)
        or a training-time forward and backward pass (when y is provided).

        Args:
            X: Array of input data of shape (N, d_1, ..., d_k) where N is the
                batch size
            y: Optional array of labels of shape (N,). y[i] gives the label
                for X[i]. If None, performs test-time forward pass only.

        Returns:
            If y is None (test mode):
                scores: Array of shape (N, C) giving classification scores,
                    where scores[i, c] is the classification score for X[i]
                    and class c.

            If y is not None (training mode):
                A tuple of:
                - loss: Scalar value giving the total loss (data loss + L2
                    regularization loss)
                - grads: Dictionary with the same keys as self.params, mapping
                    parameter names to gradients of the loss with respect to
                    those parameters
        """
        X = X.astype(self.dtype)
        mode = 'test' if y is None else 'train'

        # Set train/test mode for batchnorm params and dropout param since they
        # behave differently during training and testing.
        if self.dropout_param is not None:
            self.dropout_param['mode'] = mode
        if self.use_batchnorm:
            for bn_param in self.bn_params:
                bn_param['mode'] = mode

        scores = None
        ############################################################################
        # TODO: Implement the forward pass for the fully-connected net, computing  #
        # the class scores for X and storing them in the scores variable.          #
        #                                                                          #
        ############################################################################
        ############################################################################
        #                             END OF YOUR CODE                             #
        ############################################################################

        # If test mode return early
        if mode == 'test':
            return scores

        loss, grads = 0.0, {}
        ############################################################################
        # TODO: Implement the backward pass for the fully-connected net. Store the #
        # loss in the loss variable and gradients in the grads dictionary. Compute #
        # data loss using softmax, and make sure that grads[k] holds the gradients #
        # for self.params[k]. Don't forget to add L2 regularization on the         #
        # weights, but not the biases.                                             #
        #                                                                          #
        #                                                                          #
        # NOTE: To ensure that your implementation matches ours and you pass the   #
        # automated tests, make sure that your L2 regularization includes a factor #
        # of 0.5 to simplify the expression for the gradient.                      #
        ############################################################################
        ############################################################################
        #                             END OF YOUR CODE                             #
        ############################################################################

        return loss, grads
