"""Neural network layer implementations for forward and backward passes.

This module provides implementations of fundamental neural network layers including:
- Affine (fully-connected) layers
- ReLU activation layers
- Loss functions (SVM and Softmax)

All layers follow a consistent interface where forward passes return outputs
and cache objects, and backward passes consume upstream derivatives and cache
objects to compute gradients.
"""

from typing import Tuple
import numpy as np


def affine_forward(x: np.ndarray, w: np.ndarray, b: np.ndarray) -> Tuple[np.ndarray, Tuple]:
    """Computes the forward pass for an affine (fully-connected) layer.

    The affine layer performs a linear transformation: out = xW^T + b
    where x is the input, W are the weights, and b is the bias vector.

    The input x has shape (N, d_1, ..., d_k) and contains a minibatch of N
    examples, where each example x[i] has shape (d_1, ..., d_k). We will
    reshape each input into a vector of dimension D = d_1 * ... * d_k, and
    then transform it to an output vector of dimension M.

    Args:
        x: A numpy array containing input data, of shape (N, d_1, ..., d_k)
        w: A numpy array of weights, of shape (D, M) where D = d_1 * ... * d_k
        b: A numpy array of biases, of shape (M,)

    Returns:
        A tuple of:
        - out: Output of shape (N, M) containing the transformed input
        - cache: Tuple (x, w, b) storing inputs needed for backward pass
    """
    out = None
    #############################################################################
    # TODO: Implement the affine forward pass. Store the result in out. You     #
    # will need to reshape the input into rows.                                 #
    #############################################################################
    #############################################################################
    #                             END OF YOUR CODE                              #
    #############################################################################
    cache = (x, w, b)
    return out, cache


def affine_backward(dout: np.ndarray, cache: Tuple) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Computes the backward pass for an affine layer.

    This function computes gradients using the chain rule:
    - dx = dout * W^T (reshaped to original input shape)
    - dw = X^T * dout where X is the reshaped input
    - db = sum(dout, axis=0) (sum over batch dimension)

    Args:
        dout: Upstream derivative of shape (N, M), representing the gradient
            of the loss with respect to the output of this layer
        cache: Tuple containing:
            - x: Input data of shape (N, d_1, ... d_k)
            - w: Weights of shape (D, M) where D = d_1 * ... * d_k
            - b: Biases of shape (M,)

    Returns:
        A tuple of:
        - dx: Gradient with respect to x, of shape (N, d1, ..., d_k)
        - dw: Gradient with respect to w, of shape (D, M)
        - db: Gradient with respect to b, of shape (M,)
    """
    x, w, b = cache
    dx, dw, db = None, None, None
    #############################################################################
    # TODO: Implement the affine backward pass.                                 #
    #############################################################################
    #############################################################################
    #                             END OF YOUR CODE                              #
    #############################################################################
    return dx, dw, db


def relu_forward(x: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    """Computes the forward pass for a layer of rectified linear units (ReLUs).

    ReLU activation function: f(x) = max(0, x)
    This introduces non-linearity into the network, allowing it to learn
    complex patterns. ReLU sets all negative values to zero.

    Args:
        x: Input array of any shape

    Returns:
        A tuple of:
        - out: Output array of the same shape as x, with ReLU applied element-wise
        - cache: The input x, stored for use in the backward pass
    """
    out = None
    #############################################################################
    # TODO: Implement the ReLU forward pass.                                    #
    #############################################################################
    #############################################################################
    #                             END OF YOUR CODE                              #
    #############################################################################
    cache = x
    return out, cache


def relu_backward(dout: np.ndarray, cache: np.ndarray) -> np.ndarray:
    """Computes the backward pass for a layer of rectified linear units (ReLUs).

    The gradient of ReLU is:
    - 1 where x > 0
    - 0 where x <= 0

    Note: ReLU is not differentiable at x=0, but by convention we assign
    the derivative as 0 at that point.

    Args:
        dout: Upstream derivatives of any shape, representing the gradient
            of the loss with respect to the output of this layer
        cache: Input x from the forward pass, of the same shape as dout

    Returns:
        dx: Gradient with respect to x, of the same shape as dout
    """
    dx, x = None, cache
    #############################################################################
    # TODO: Implement the ReLU backward pass.                                   #
    #############################################################################
    #############################################################################
    #                             END OF YOUR CODE                              #
    #############################################################################
    return dx

def svm_loss(x: np.ndarray, y: np.ndarray) -> Tuple[float, np.ndarray]:
    """Computes the loss and gradient for multiclass SVM classification.

    The multiclass SVM loss (hinge loss) measures how well the classifier
    separates the correct class from incorrect classes. For each example,
    we want the score of the correct class to be at least 1 higher than
    the scores of all incorrect classes.

    Args:
        x: Input scores of shape (N, C) where x[i, j] is the score for the
            jth class for the ith input
        y: Vector of labels of shape (N,) where y[i] is the label for x[i]
            and 0 <= y[i] < C

    Returns:
        A tuple of:
        - loss: Scalar giving the average SVM loss over the batch
        - dx: Gradient of the loss with respect to x, of shape (N, C)
    """
    N = x.shape[0]
    # Extract scores for the correct classes
    correct_class_scores = x[np.arange(N), y]
    
    # Compute margins: max(0, score - correct_score + 1)
    # The margin is positive when an incorrect class has a score that is
    # within 1 of the correct class score
    margins = np.maximum(0, x - correct_class_scores[:, np.newaxis] + 1.0)
    
    # Zero out margins for the correct class (they shouldn't contribute to loss)
    margins[np.arange(N), y] = 0
    
    # Average loss over the batch
    loss = np.sum(margins) / N
    
    # Compute gradient: for each example, count how many classes contributed
    # to the loss (had positive margin)
    num_pos = np.sum(margins > 0, axis=1)
    
    # Initialize gradient: positive contribution for all classes with margin > 0
    dx = np.zeros_like(x)
    dx[margins > 0] = 1
    
    # Subtract the count for the correct class (since it doesn't contribute)
    dx[np.arange(N), y] -= num_pos
    
    # Average gradient over batch
    dx /= N
    return loss, dx


def softmax_loss(x: np.ndarray, y: np.ndarray) -> Tuple[float, np.ndarray]:
    """Computes the loss and gradient for softmax classification.

    The softmax loss (cross-entropy loss) is commonly used for multi-class
    classification. It converts raw scores into probabilities using the
    softmax function and then computes the negative log-likelihood of the
    correct class.

    Args:
        x: Input scores of shape (N, C) where x[i, j] is the score for the
            jth class for the ith input
        y: Vector of labels of shape (N,) where y[i] is the label for x[i]
            and 0 <= y[i] < C

    Returns:
        A tuple of:
        - loss: Scalar giving the average cross-entropy loss over the batch
        - dx: Gradient of the loss with respect to x, of shape (N, C)
    """
    # Numerical stability: subtract max before exponentiating
    # This doesn't change the result but prevents overflow
    shifted_scores = x - np.max(x, axis=1, keepdims=True)
    
    # Compute softmax probabilities: exp(x) / sum(exp(x))
    probs = np.exp(shifted_scores)
    probs /= np.sum(probs, axis=1, keepdims=True)
    
    N = x.shape[0]
    
    # Cross-entropy loss: -log(prob of correct class) averaged over batch
    loss = -np.sum(np.log(probs[np.arange(N), y])) / N
    
    # Gradient: softmax probabilities minus one-hot encoding of correct class
    # This elegant form comes from the derivative of cross-entropy with softmax
    dx = probs.copy()
    dx[np.arange(N), y] -= 1
    dx /= N
    
    return loss, dx
