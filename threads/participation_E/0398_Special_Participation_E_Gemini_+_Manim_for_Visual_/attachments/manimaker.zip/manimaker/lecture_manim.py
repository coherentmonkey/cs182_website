from manim import *

# Set color constants for consistency, inspired by 3Blue1Brown's style
BLUE_A = "#3b739e"
BLUE_B = "#5c94bd"
BLUE_C = "#8ab7d9"
GREEN_A = "#5f9c4f"
GREEN_B = "#81b96f"
RED_A = "#d9534f"
RED_B = "#e37f7c"
YELLOW_A = "#f0ad4e"
YELLOW_B = "#f7c789"
GREY_A = "#666666"
GREY_B = "#999999"
GREY_C = "#CCCCCC"
WHITE = "#FFFFFF"

class RidgeRegressionSVDScene(ThreeDScene):
    def construct(self):
        # --- SCENE SETUP ---
        title = MarkupText("Understanding Ridge Regression with SVD", font_size=40).to_edge(UP)
        self.play(Write(title))
        self.wait(1)

        # --- SLIDE 1: Introduce Ridge Regression Solution ---
        # Show the Ridge regression objective and its closed-form solution
        ridge_objective_text = MarkupText(
            "Ridge regression aims to solve this objective:",
            font_size=28
        ).next_to(title, DOWN, buff=0.5)

        ridge_objective_formula = MathTex(
            r"\min_{\vec{w}}", r"\| \mathbf{X}\vec{w} - \vec{y} \|^2", r"+", r"\lambda", r"\| \vec{w} \|^2",
            font_size=36
        )
        ridge_objective_formula.next_to(ridge_objective_text, DOWN, buff=0.25)
        ridge_objective_formula.set_color_by_tex_to_color_map({
            r"\mathbf{X}\vec{w} - \vec{y}": BLUE_A,
            r"\lambda": YELLOW_A,
            r"\vec{w}": GREEN_A
        })

        self.play(FadeIn(ridge_objective_text))
        self.play(Write(ridge_objective_formula))
        self.wait(1)

        solution_text = MarkupText(
            "This has a well-known closed-form solution:",
            font_size=28
        ).next_to(ridge_objective_formula, DOWN, buff=0.7)
        
        w_star_formula = MathTex(
            r"\vec{w}_{*} = (", r"\mathbf{X}^T \mathbf{X}", r"+", r"\lambda \mathbf{I}", r")^{-1}", r"\mathbf{X}^T \vec{y}",
            font_size=40
        ).next_to(solution_text, DOWN, buff=0.25)
        w_star_formula.set_color_by_tex_to_color_map({
            r"\mathbf{X}": BLUE_B,
            r"\lambda": YELLOW_A,
        })
        
        self.play(FadeIn(solution_text))
        self.play(Write(w_star_formula))
        self.wait(2)

        # Narration about needing a deeper look
        intuition_text = MarkupText(
            "But to build intuition, let's view this through a different lens...",
            font_size=28
        ).next_to(w_star_formula, DOWN, buff=1.0)
        svd_text = MarkupText(
            "The lens of Singular Value Decomposition (SVD).",
            font_size=32,
            color=BLUE_C
        ).next_to(intuition_text, DOWN)
        
        # Fade out title BEFORE showing new intro text to reduce clutter
        self.play(FadeOut(title))
        self.play(Write(intuition_text))
        self.play(Write(svd_text))
        self.wait(2)
        
        self.play(
            FadeOut(ridge_objective_text),
            FadeOut(ridge_objective_formula),
            FadeOut(solution_text),
            FadeOut(intuition_text),
            FadeOut(svd_text),
            w_star_formula.animate.to_edge(UP).scale(0.8)
        )
        self.wait(1)

        # --- SLIDE 2: Substitute SVD into the formula ---
        # Show the SVD of X and substitute it into the solution for w*
        svd_formula = MathTex(r"\mathbf{X}", r"=", r"\mathbf{U}", r"\boldsymbol{\Sigma}", r"\mathbf{V}^T", font_size=36).next_to(w_star_formula, DOWN, buff=0.5)
        svd_formula.set_color_by_tex_to_color_map({
            r"\mathbf{X}": BLUE_B,
            r"\mathbf{U}": RED_A,
            r"\boldsymbol{\Sigma}": WHITE,
            r"\mathbf{V}": GREEN_A
        })
        self.play(Write(svd_formula))
        self.wait(1)
        
        # Animate the substitution step-by-step
        sub_text = MarkupText("Let's substitute this into the solution:", font_size=28).next_to(svd_formula, DOWN, buff=0.5).align_to(w_star_formula, LEFT)
        self.play(Write(sub_text))
        
        # Step 1: Full substitution
        w_sub = MathTex(
            r"\vec{w}_{*} = (",
            r"(\mathbf{U}\boldsymbol{\Sigma}\mathbf{V}^T)^T", r"(\mathbf{U}\boldsymbol{\Sigma}\mathbf{V}^T)",
            r"+ \lambda \mathbf{I})^{-1}",
            r"(\mathbf{U}\boldsymbol{\Sigma}\mathbf{V}^T)^T", r"\vec{y}",
            font_size=32
        ).next_to(sub_text, DOWN, buff=0.5)
        w_sub.set_color_by_tex_to_color_map({
            r"\mathbf{U}": RED_A, r"\boldsymbol{\Sigma}": WHITE, r"\mathbf{V}": GREEN_A, r"\lambda": YELLOW_A,
        })
        self.play(Write(w_sub))
        self.wait(1.5)

        # Step 2: Simplify X^T X
        w_sub_2 = MathTex(
            r"\vec{w}_{*} = (",
            r"\mathbf{V}\boldsymbol{\Sigma}^T\mathbf{U}^T", r"\mathbf{U}\boldsymbol{\Sigma}\mathbf{V}^T",
            r"+ \lambda \mathbf{I})^{-1}",
            r"\mathbf{V}\boldsymbol{\Sigma}^T\mathbf{U}^T", r"\vec{y}",
            font_size=32
        ).move_to(w_sub)
        w_sub_2.set_color_by_tex_to_color_map({
            r"\mathbf{U}": RED_A, r"\boldsymbol{\Sigma}": WHITE, r"\mathbf{V}": GREEN_A, r"\lambda": YELLOW_A,
        })
        self.play(TransformMatchingTex(w_sub, w_sub_2))
        self.wait(1)

        u_cancel_box = SurroundingRectangle(w_sub_2, color=RED_B, buff=0.15)
        u_cancel_text = MathTex(r"\mathbf{U}^T \mathbf{U} = \mathbf{I}", color=RED_B).next_to(u_cancel_box, DOWN)
        self.play(Create(u_cancel_box))
        self.play(Write(u_cancel_text))
        self.wait(1)

        # Step 3: Replace I with VV^T and factor
        w_sub_3 = MathTex(
            r"\vec{w}_{*} = (",
            r"\mathbf{V}\boldsymbol{\Sigma}^T\boldsymbol{\Sigma}\mathbf{V}^T",
            r"+ \lambda \mathbf{V}\mathbf{V}^T", r")^{-1}",
            r"\mathbf{V}\boldsymbol{\Sigma}^T\mathbf{U}^T", r"\vec{y}",
            font_size=32
        ).move_to(w_sub)
        w_sub_3.set_color_by_tex_to_color_map({
            r"\mathbf{U}": RED_A, r"\boldsymbol{\Sigma}": WHITE, r"\mathbf{V}": GREEN_A, r"\lambda": YELLOW_A,
        })
        self.play(FadeOut(u_cancel_box, u_cancel_text), TransformMatchingTex(w_sub_2, w_sub_3))
        self.wait(1.5)
        
        w_sub_4 = MathTex(
            r"\vec{w}_{*} = (",
            r"\mathbf{V}", r"(\boldsymbol{\Sigma}^T\boldsymbol{\Sigma} + \lambda \mathbf{I})", r"\mathbf{V}^T",
            r")^{-1}",
            r"\mathbf{V}\boldsymbol{\Sigma}^T\mathbf{U}^T", r"\vec{y}",
            font_size=32
        ).move_to(w_sub)
        w_sub_4.set_color_by_tex_to_color_map({
            r"\mathbf{U}": RED_A, r"\boldsymbol{\Sigma}": WHITE, r"\mathbf{V}": GREEN_A, r"\lambda": YELLOW_A,
        })
        self.play(TransformMatchingTex(w_sub_3, w_sub_4))
        self.wait(1.5)

        # Step 4: Distribute the inverse and (conceptually) cancel V's
        w_sub_5 = MathTex(
            r"\vec{w}_{*} = ",
            r"\mathbf{V}", r"(\boldsymbol{\Sigma}^T\boldsymbol{\Sigma} + \lambda \mathbf{I})^{-1}", r"\mathbf{V}^T",
            r"\mathbf{V}", r"\boldsymbol{\Sigma}^T\mathbf{U}^T", r"\vec{y}",
            font_size=32
        ).move_to(w_sub)
        w_sub_5.set_color_by_tex_to_color_map({
            r"\mathbf{U}": RED_A, r"\boldsymbol{\Sigma}": WHITE, r"\mathbf{V}": GREEN_A, r"\lambda": YELLOW_A,
        })
        self.play(TransformMatchingTex(w_sub_4, w_sub_5))
        self.wait(1)
        
        # Highlight the place where V^T V collapses to I — again, box the whole expression for robustness.
        v_cancel_box = SurroundingRectangle(w_sub_5, color=GREEN_B, buff=0.15)
        v_cancel_text = MathTex(r"\mathbf{V}^T \mathbf{V} = \mathbf{I}", color=GREEN_B).next_to(v_cancel_box, DOWN)
        self.play(Create(v_cancel_box))
        self.play(Write(v_cancel_text))
        self.wait(1)

        # Step 5: Final simplified form
        w_final_matrix = MathTex(
            r"\vec{w}_{*} = ",
            r"\mathbf{V}", r"(\boldsymbol{\Sigma}^T\boldsymbol{\Sigma} + \lambda \mathbf{I})^{-1}", r"\boldsymbol{\Sigma}^T", r"\mathbf{U}^T", r"\vec{y}",
            font_size=36
        ).move_to(w_sub)
        w_final_matrix.set_color_by_tex_to_color_map({
            r"\mathbf{U}": RED_A, r"\boldsymbol{\Sigma}": WHITE, r"\mathbf{V}": GREEN_A, r"\lambda": YELLOW_A,
        })
        self.play(FadeOut(v_cancel_box, v_cancel_text), TransformMatchingTex(w_sub_5, w_final_matrix))
        self.wait(2)

        # Fade out previous steps to clear the screen for the next part
        self.play(
            FadeOut(w_star_formula),
            FadeOut(svd_formula),
            FadeOut(sub_text),
            FadeOut(w_sub_5),
            w_final_matrix.animate.scale(1.1).center().to_edge(UP)
        )
        self.wait(1)

        # --- SLIDE 3: The Diagonal Shrinkage Term ---
        # Focus on the diagonal matrix in the middle
        middle_term_text = MarkupText(
            "The magic happens in this middle term, which is diagonal:",
            font_size=28
        ).next_to(w_final_matrix, DOWN, buff=0.5)
        self.play(Write(middle_term_text))
        
        middle_term = w_final_matrix.get_part_by_tex(r"(\boldsymbol{\Sigma}^T\boldsymbol{\Sigma} + \lambda \mathbf{I})^{-1}")
        middle_term_box = SurroundingRectangle(middle_term, color=YELLOW_B, buff=0.1)
        self.play(Create(middle_term_box))
        self.wait(1)
        
        # Show the structure of the matrices
        sigma_sq = MathTex(r"\boldsymbol{\Sigma}^T\boldsymbol{\Sigma} = \begin{pmatrix} \sigma_1^2 & & \\ & \sigma_2^2 & \\ & & \ddots \end{pmatrix}", font_size=32).shift(LEFT * 3.5)
        lambda_i = MathTex(r"\lambda\mathbf{I} = \begin{pmatrix} \lambda & & \\ & \lambda & \\ & & \ddots \end{pmatrix}", font_size=32).shift(RIGHT * 3.5)

        self.play(Write(sigma_sq))
        self.play(Write(lambda_i))
        self.wait(1.5)

        sum_matrix = MathTex(
            r"\boldsymbol{\Sigma}^T\boldsymbol{\Sigma} + \lambda\mathbf{I} = \begin{pmatrix} \sigma_1^2 + \lambda & & \\ & \sigma_2^2 + \lambda & \\ & & \ddots \end{pmatrix}",
            font_size=32
        ).next_to(middle_term_text, DOWN, buff=1.5)
        self.play(
             FadeOut(sigma_sq),
             FadeOut(lambda_i),
             FadeIn(sum_matrix)
        )
        self.wait(1.5)

        inv_matrix = MathTex(
            r"(\boldsymbol{\Sigma}^T\boldsymbol{\Sigma} + \lambda\mathbf{I})^{-1} = \begin{pmatrix} \frac{1}{\sigma_1^2 + \lambda} & & \\ & \frac{1}{\sigma_2^2 + \lambda} & \\ & & \ddots \end{pmatrix}",
            font_size=32
        ).next_to(sum_matrix, DOWN, buff=0.7)
        self.play(TransformFromCopy(sum_matrix, inv_matrix))
        self.wait(2)
        
        self.play(FadeOut(middle_term_text, middle_term_box, sum_matrix, inv_matrix))
        self.wait(0.5)
        
        # --- SLIDE 4: The Solution as a Sum ---
        # Rewrite the formula as a sum over singular components
        sum_form_text = MarkupText(
            "This diagonal structure means we can write the solution as a sum:",
            font_size=28
        ).next_to(w_final_matrix, DOWN, buff=0.5)
        
        w_sum_form = MathTex(
            r"\vec{w}_{*} = \sum_{i} \vec{v}_i",
            r"\left( \frac{\sigma_i}{\sigma_i^2 + \lambda} \right)",
            r"(\vec{u}_i^T \vec{y})",
            font_size=40
        ).next_to(sum_form_text, DOWN, buff=0.5)
        w_sum_form.set_color_by_tex_to_color_map({
            r"\vec{v}_i": GREEN_A,
            r"\sigma_i": WHITE,
            r"\lambda": YELLOW_A,
            r"\vec{u}_i": RED_A
        })
        
        self.play(Write(sum_form_text))
        self.play(TransformMatchingTex(w_final_matrix.copy(), w_sum_form))
        self.wait(2)

        shrinkage_term_box = SurroundingRectangle(w_sum_form.get_part_by_tex(r"\frac{\sigma_i}{\sigma_i^2 + \lambda}"), color=YELLOW_B)
        shrinkage_text = MarkupText("The 'shrinkage' factor", color=YELLOW_B, font_size=28).next_to(shrinkage_term_box, DOWN)
        self.play(Create(shrinkage_term_box))
        self.play(Write(shrinkage_text))
        self.wait(2)

        self.play(*[FadeOut(mob) for mob in self.mobjects])
        self.wait(0.5)

        # --- SLIDE 5: Geometric Intuition ---
        # First, explain the shrinkage factor for large and small sigma_i (centered, no graph yet)
        intro_text = MarkupText(
            "Let's see what this shrinkage factor does in two cases:",
            font_size=32
        ).to_edge(UP)
        self.play(Write(intro_text))
        self.wait(1)
        
        analysis_group = VGroup()
        case1_text = MarkupText("<b>Case 1:</b> Large singular value", font_size=28)
        case1_math = MathTex(r"\text{If } \sigma_1^2 \gg \lambda, \quad \frac{\sigma_1}{\sigma_1^2 + \lambda} \approx \frac{1}{\sigma_1}", font_size=32).next_to(case1_text, DOWN, aligned_edge=LEFT, buff=0.3)
        case1_result = MarkupText("Component is kept (like standard least squares).", font_size=24, color=GREY_C).next_to(case1_math, DOWN, aligned_edge=LEFT, buff=0.2)
        case1_group = VGroup(case1_text, case1_math, case1_result)
        analysis_group.add(case1_group)

        case2_text = MarkupText("<b>Case 2:</b> Small singular value", font_size=28).next_to(case1_result, DOWN, buff=0.7, aligned_edge=LEFT)
        case2_math = MathTex(r"\text{If } \sigma_2^2 \ll \lambda, \quad \frac{\sigma_2}{\sigma_2^2 + \lambda} \approx \frac{\sigma_2}{\lambda} \to 0", font_size=32).next_to(case2_text, DOWN, aligned_edge=LEFT, buff=0.3)
        case2_result = MarkupText("Component is heavily suppressed (shrunk to zero).", font_size=24, color=RED_B).next_to(case2_math, DOWN, aligned_edge=LEFT, buff=0.2)
        case2_group = VGroup(case2_text, case2_math, case2_result)
        analysis_group.add(case2_group)
        
        # Center the entire analysis group
        analysis_group.arrange(DOWN, center=True, buff=0.5).next_to(intro_text, DOWN, buff=0.7)
        
        self.play(Write(case1_group))
        self.wait(2)
        self.play(Write(case2_group))
        self.wait(3)
        
        # Fade out the analysis, then show the geometric visualization
        self.play(FadeOut(intro_text), FadeOut(analysis_group))
        self.wait(0.5)
        
        # Now show the data cloud and axes (centered)
        data_text = MarkupText(
            "Let's visualize this with some data:",
            font_size=28
        ).to_edge(UP)
        self.play(Write(data_text))
        self.wait(3)
        self.play(FadeOut(data_text))
        
        axes = Axes(
            x_range=[-5, 5, 1], y_range=[-3, 3, 1],
            x_length=10, y_length=6,
            axis_config={"color": GREY_B, "include_tip": False}
        )
        x_label = MathTex(r"\vec{v}_1 \text{ direction}", font_size=32, color=GREEN_B).next_to(axes.x_axis, RIGHT)
        y_label = MathTex(r"\vec{v}_2 \text{ direction}", font_size=32, color=GREEN_B).next_to(axes.y_axis, UP)
        
        self.play(Create(axes), Write(x_label), Write(y_label))

        scatter = VGroup(*[
            Dot(axes.c2p(np.random.normal(0, 2), np.random.normal(0, 0.4)), color=BLUE_C, radius=0.05)
            for _ in range(200)
        ])
        
        self.play(LaggedStart(*[FadeIn(dot, scale=0.5) for dot in scatter], lag_ratio=0.05))

        sigma1_label = MathTex(r"\text{Large } \sigma_1", font_size=28).next_to(x_label, DOWN, buff=0.2)
        sigma2_label = MathTex(r"\text{Small } \sigma_2", font_size=28).next_to(y_label, LEFT, buff=0.2)
        self.play(Write(sigma1_label), Write(sigma2_label))
        self.wait(2)
        
        # Clear data and labels before showing vector comparison
        self.play(FadeOut(scatter, sigma1_label, sigma2_label))
        self.wait(0.5)

        # Show the geometric effect on a solution vector
        w_ls_coord = np.array([3, 2, 0])
        w_ridge_coord = np.array([2.9, 0.4, 0])
        
        origin = axes.c2p(0, 0)
        w_ls_point = axes.c2p(*w_ls_coord[:2])
        w_ridge_point = axes.c2p(*w_ridge_coord[:2])

        w_ls_vec = Arrow(origin, w_ls_point, buff=0, color=BLUE_A, stroke_width=7)
        w_ls_label = MathTex(r"\vec{w}_{LS}", color=BLUE_A).next_to(w_ls_vec.get_end(), UR, buff=0.1)
        
        self.play(GrowArrow(w_ls_vec), Write(w_ls_label))
        self.wait(1)

        w_ridge_vec = Arrow(origin, w_ridge_point, buff=0, color=YELLOW_A, stroke_width=7)
        w_ridge_label = MathTex(r"\vec{w}_{ridge}", color=YELLOW_A).next_to(w_ridge_vec.get_end(), DR, buff=0.1)
        
        path = DashedLine(w_ls_point, w_ridge_point, color=GREY_A, dash_length=0.1)
        
        self.play(Create(path))
        self.play(Transform(w_ls_vec, w_ridge_vec), Transform(w_ls_label, w_ridge_label))
        self.wait(2)

        # Highlight the shrinkage along the v2 axis
        v1_comp = Line(origin, axes.c2p(w_ls_coord[0], 0), color=GREY_C, stroke_width=2, stroke_opacity=0.5)
        v2_comp_ls = Line(axes.c2p(w_ls_coord[0], 0), w_ls_point, color=GREY_C, stroke_width=2, stroke_opacity=0.5)
        v2_comp_ridge = Line(axes.c2p(w_ridge_coord[0], 0), w_ridge_point, color=RED_B, stroke_width=4)
        v2_comp_brace = Brace(v2_comp_ls, direction=RIGHT, buff=0.1)
        # Manim's Brace.get_text() creates a Tex and does not accept font_size; scale afterwards.
        v2_comp_text = v2_comp_brace.get_text("Shrunk!")
        v2_comp_text.scale(0.8)
        
        self.play(Create(v1_comp), Create(v2_comp_ls))
        self.wait(1)
        self.play(Transform(v2_comp_ls, v2_comp_ridge), GrowFromCenter(v2_comp_brace), Write(v2_comp_text))
        self.wait(3)

        # --- SLIDE 6: Conclusion ---
        self.play(*[FadeOut(mob) for mob in self.mobjects])
        
        conclusion_text = MarkupText(
            "Ridge regression performs a <span fgcolor='{yellow}'>selective shrinkage</span>.".format(yellow=YELLOW_A),
            font_size=36
        ).shift(UP*0.5)
        
        conclusion_detail = MarkupText(
            "It suppresses directions of <span fgcolor='{red}'>low data variance</span> (small singular values),\n"
            "which often correspond to noise, thus preventing overfitting.".format(red=RED_B),
            font_size=32,
            justify=True
        ).next_to(conclusion_text, DOWN, buff=0.5)
        
        self.play(Write(conclusion_text))
        self.play(Write(conclusion_detail))
        self.wait(4)
        
        self.play(*[FadeOut(mob) for mob in self.mobjects])
        self.wait(1)
