import os

from google import genai

def read_text_file(path: str) -> str:
    with open(path, "r", encoding="utf-8") as f:
        content = f.read()
    print(f"Successfully read text from {path}")
    return content


def build_contents_for_gemini(
    lecture_notes_path: str,
    transcript_text: str,
    topic_focus: str,
):
    """
    Build the `contents` payload for Gemini using:
    - the lecture transcript (text)
    - the lecture notes as LaTeX/text.
    """
    notes_ext = os.path.splitext(lecture_notes_path)[1].lower()

    base_prompt = f"""
You are helping create high–quality, visually engaging Manim videos
in the style of 3Blue1Brown for a CS 182 (Deep Neural Networks) lecture.

You are given:
1. The full lecture transcript.
2. The lecture notes as LaTeX.

However, you should focus on ONLY ONE SMALL COMPONENT of the lecture,
described below, and ignore the rest of the content.

FOCUS TOPIC (very important, stay within this slice of the lecture):
{topic_focus}

Your job is to design and WRITE the complete Manim code for a very small number
of short scenes (ideally 1, at most 2) that clearly and beautifully explain
this specific topic in depth,
in a way that a student could watch this instead of that portion of the lecture
and deeply understand it.

**Requirements for the output (VERY IMPORTANT):**
- Output **ONLY valid Python code** for Manim Community Edition (no backticks, no prose).
- Use clear, well–structured `Scene` or `ThreeDScene` subclasses.
- Prefer a slow, **highly explanatory** 3Blue1Brown style:
  - Break the story into many short "slides" / beats, each focusing on one idea at a time.
  - Use animations that build intuition (moving vectors, graphs, step–by–step formulas, geometric pictures).
  - Use color, positioning, and smooth transitions to highlight key ideas and connect them.
- Include **plenty of narration text on screen** using `Text`/`MarkupText` objects that summarize and explain,
  not just equations.
- Add concise comments in the code to explain the intent of each major block or animation.
- Keep the scope small: use one or two scenes that thoroughly explain ONLY the focus topic above.
- Within each scene, structure the animations as if they were a slide deck with transitions.
- Make sure the code is runnable as–is from a typical `manim` command.

You should:
- Infer the important concepts from both the transcript and the notes.
- Choose visual representations (diagrams, graphs, equations, arrows, pictures of data, loss landscapes, etc.)
  that best illustrate each concept.
- Name scenes and variables meaningfully (e.g., `GradientDescentScene`, `LossLandscapeScene`).
 - Whenever helpful, show visuals or geometric intuition **before** showing the formal equations,
   then connect them.

FIRST think through and internally plan the structure of the scenes,
THEN output only the final Python Manim code.

Here is the lecture transcript:

{transcript_text}
"""

    contents = [base_prompt]

    # The notes are expected to be LaTeX/text; append them as additional text.
    if notes_ext not in {".tex", ".txt", ".md"}:
        print(
            f"Warning: lecture notes file '{lecture_notes_path}' does not look like LaTeX/text "
            f"(extension: '{notes_ext}'). Proceeding anyway, treating it as text."
        )

    print(f"Reading lecture notes as text: {lecture_notes_path}")
    notes_text = read_text_file(lecture_notes_path)
    notes_block = f"""

Here are the lecture notes (LaTeX/text) that correspond to the transcript.
Use these to guide the structure, notation, key equations, and the order of topics in your Manim scenes:

{notes_text}
"""
    contents[0] += notes_block

    return contents


def call_gemini_for_manim_script(
    lecture_notes_path: str,
    transcript_path: str,
    api_key: str,
    topic_focus: str,
    model: str = "gemini-2.5-pro",
) -> str:
    if not api_key:
        raise ValueError("GEMINI_API_KEY is empty. Please provide a valid API key.")

    transcript_text = read_text_file(transcript_path)
    contents = build_contents_for_gemini(
        lecture_notes_path=lecture_notes_path,
        transcript_text=transcript_text,
        topic_focus=topic_focus,
    )

    print("Calling Gemini API to generate Manim script...")
    client = genai.Client(api_key=api_key)

    response = client.models.generate_content(
        model=model,
        contents=contents,
    )
    print("Successfully received response from Gemini API")

    return response.text


def clean_python_output(content: str) -> str:
    """
    Strip common Markdown fences (```python, ```py, ```), leaving just Python code.
    """
    content = content.lstrip()

    # Remove leading fences
    for prefix in ("```python", "```py", "```Python", "```"):
        if content.startswith(prefix):
            content = content[len(prefix) :].lstrip()
            break

    # Remove trailing fence if present
    content = content.rstrip()
    if content.endswith("```"):
        content = content[: -3].rstrip()

    return content


def save_manim_script(content: str, output_path: str):
    cleaned = clean_python_output(content)
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(cleaned)
    print(f"Successfully saved Manim script to {output_path}")


if __name__ == "__main__":
    LECTURE_NOTES_FILE = "lecture_notes.tex" 
    TRANSCRIPT_FILE = "lecture_transcript.txt"
    OUTPUT_MANIM_FILE = "lecture_manim.py"

    # Describe a SMALL slice of the lecture to visualize.
    # Edit this string each time you want to generate a different focused video.
    TOPIC_FOCUS = (
        "Explain Ridge regression in the SVD basis, including the formula for "
        "w_* = (X^T X + lambda I)^{-1} X^T y, how it becomes a diagonal shrinkage "
        "in the singular value basis, and geometric intuition for why small singular "
        "values are suppressed. Do not cover momentum or SGD here."
    )

    GEMINI_API_KEY = "AIzaSyAeUyDBAg9gPG2eLzJTk5GSoenGM6keEGg"

    manim_code = call_gemini_for_manim_script(
        lecture_notes_path=LECTURE_NOTES_FILE,
        transcript_path=TRANSCRIPT_FILE,
        api_key=GEMINI_API_KEY,
        topic_focus=TOPIC_FOCUS,
    )

    save_manim_script(manim_code, OUTPUT_MANIM_FILE)