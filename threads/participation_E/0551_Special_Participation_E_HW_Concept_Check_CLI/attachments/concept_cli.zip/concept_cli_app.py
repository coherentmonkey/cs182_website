import argparse
import json
import os
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from openai import OpenAI


def load_concept_banks(concept_dir: Path) -> Dict[str, Dict[str, Any]]:
    """Load all homework concept bank JSON files from concept_dir."""
    if not concept_dir.is_dir():
        raise SystemExit(
            f"Concept bank directory not found at {concept_dir}. "
            "Run build_concept_bank.py first to generate banks."
        )

    banks: Dict[str, Dict[str, Any]] = {}
    for json_path in sorted(concept_dir.glob("*.json")):
        try:
            with json_path.open("r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception as e:
            print(f"Warning: failed to load {json_path}: {e}")
            continue

        hw_id = str(data.get("homework_id") or json_path.stem)
        questions = data.get("questions")
        if not isinstance(questions, dict) or not questions:
            print(f"Warning: no valid 'questions' in {json_path}, skipping.")
            continue
        banks[hw_id] = data

    if not banks:
        raise SystemExit(
            f"No valid concept bank JSON files found in {concept_dir}. "
            "Run build_concept_bank.py first."
        )

    return banks


def choose_from_list(prompt: str, options: List[str]) -> Optional[str]:
    """Simple menu to choose an option by index or exact value."""
    if not options:
        return None

    print(prompt)
    for idx, opt in enumerate(options, start=1):
        print(f"  [{idx}] {opt}")
    print("  [q] Quit / back")

    while True:
        choice = input("> ").strip()
        if choice.lower() in {"q", "quit", "exit"}:
            return None
        if choice.isdigit():
            i = int(choice)
            if 1 <= i <= len(options):
                return options[i - 1]
        if choice in options:
            return choice
        print("Please enter a valid index, value, or 'q' to quit/back.")


def ensure_client(api_key: Optional[str]) -> OpenAI:
    """Initialize an OpenAI client, prompting the user for a key if needed."""
    key = api_key or os.getenv("OPENAI_API_KEY")
    if not key:
        print("No OpenAI API key found in OPENAI_API_KEY.")
        key = input("Please paste your OpenAI API key (it will not be stored): ").strip()
        if not key:
            raise SystemExit("No API key provided; cannot call OpenAI.")
    return OpenAI(api_key=key)


def grade_response(
    client: OpenAI,
    model: str,
    conceptual_question: str,
    ideal_answer: str,
    student_answer: str,
    conversation_history: Optional[str] = None,
) -> Dict[str, Any]:
    """Call OpenAI to grade a student's response and optionally ask a follow-up question."""
    system_msg = (
        "You are an assistant helping a student check their conceptual understanding.\n"
        "You will be given a conceptual question, an ideal answer, and the student's answer.\n"
        "Your job is to:\n"
        "1. Judge whether the student's answer is correct, partially correct, or incorrect.\n"
        "2. Provide a short explanation of your judgment.\n"
        "3. Optionally ask at most one follow-up question that would further probe their understanding.\n\n"
        "Respond in JSON with fields:\n"
        "{\n"
        '  \"evaluation\": \"correct\" | \"partially_correct\" | \"incorrect\",\n'
        '  \"feedback\": \"short explanation\",\n'
        '  \"followup_question\": string or null\n'
        "}\n"
        "Do not include any other top-level fields."
    )
    user_msg = (
        "Conceptual question:\n"
        f"{conceptual_question}\n\n"
        "Ideal answer:\n"
        f"{ideal_answer}\n\n"
        "Most recent student answer:\n"
        f"{student_answer}\n\n"
    )
    if conversation_history:
        user_msg += (
            "Conversation so far (previous follow-up questions and answers):\n"
            f"{conversation_history}\n"
        )

    response = client.chat.completions.create(
        model=model,
        response_format={"type": "json_object"},
        temperature=0.2,
        messages=[
            {"role": "system", "content": system_msg},
            {"role": "user", "content": user_msg},
        ],
    )
    content = response.choices[0].message.content
    if not content:
        raise RuntimeError("Empty response from OpenAI during grading.")
    try:
        data = json.loads(content)
    except json.JSONDecodeError as e:
        raise RuntimeError(f"Failed to parse grading JSON: {e}\nRaw: {content}") from e
    return data


def interaction_loop_for_question(
    client: Optional[OpenAI],
    api_key: Optional[str],
    model: str,
    hw_id: str,
    q_id: str,
    concept_entries: List[Dict[str, Any]],
) -> None:
    """Interactive CLI loop for one homework question's conceptual checks."""
    idx = 0
    total = len(concept_entries)
    current_client = client

    while 0 <= idx < total:
        entry = concept_entries[idx]
        cq = entry.get("concept_question", "").strip()
        hint = entry.get("hint", "").strip()
        ideal = entry.get("ideal_answer", "").strip()

        print("\n" + "=" * 60)
        print(f"Homework {hw_id} - Question {q_id} - Concept check {idx + 1}/{total}")
        print("-" * 60)
        print(f"Conceptual question:\n{cq}\n")

        while True:
            print("Commands: [h] hint  [a] ideal answer  [r] respond  "
                  "[n] next  [p] previous  [b] back to question menu  [q] quit")
            cmd = input("> ").strip().lower()

            if cmd in {"h", "hint"}:
                print(f"\nHint:\n{hint}\n")
            elif cmd in {"a", "answer"}:
                print(f"\nIdeal answer:\n{ideal}\n")
            elif cmd in {"r", "respond"}:
                student_answer = input("\nType your answer (single line, be concise):\n> ").strip()
                if not student_answer:
                    print("No answer entered.")
                    continue
                if current_client is None:
                    current_client = ensure_client(api_key)
                # Up to three grading steps: initial answer + at most two follow-up rounds.
                conversation_history: str = ""
                current_answer = student_answer
                max_steps = 3

                for step in range(1, max_steps + 1):
                    try:
                        result = grade_response(
                            client=current_client,
                            model=model,
                            conceptual_question=cq,
                            ideal_answer=ideal,
                            student_answer=current_answer,
                            conversation_history=conversation_history or None,
                        )
                    except Exception as e:
                        print(f"Error during grading: {e}")
                        break

                    evaluation = result.get("evaluation", "unknown")
                    feedback = result.get("feedback", "")
                    followup = result.get("followup_question")

                    print(f"\nStep {step} evaluation: {evaluation}")
                    if feedback:
                        print(f"Feedback: {feedback}")

                    # Stop if no follow-up or we've reached the step limit.
                    if not followup or step == max_steps:
                        print()
                        break

                    print(f"\nFollow-up question:\n{followup}")
                    followup_answer = input(
                        "Your answer to the follow-up (press Enter to skip and end evaluation):\n> "
                    ).strip()
                    if not followup_answer:
                        print()
                        break

                    # Record this Q+A in the conversation history and continue.
                    if conversation_history:
                        conversation_history += "\n"
                    conversation_history += (
                        f"Follow-up question {step}: {followup}\n"
                        f"Student answer {step}: {followup_answer}"
                    )
                    current_answer = followup_answer

            elif cmd in {"n", "next"}:
                idx += 1
                break
            elif cmd in {"p", "prev", "previous"}:
                idx -= 1
                break
            elif cmd in {"b", "back"}:
                return
            elif cmd in {"q", "quit", "exit"}:
                raise SystemExit(0)
            else:
                print("Unrecognized command.")


def pick_homework_and_question(
    banks: Dict[str, Dict[str, Any]],
    pre_hw: Optional[str],
    pre_q: Optional[str],
) -> Tuple[Optional[str], Optional[str]]:
    """Handle selection of homework and question, with optional pre-selection."""
    hw_ids = sorted(banks.keys(), key=lambda s: int(s[2:]))

    # Homework selection
    hw_id: Optional[str] = None
    if pre_hw:
        if pre_hw in hw_ids:
            hw_id = pre_hw
        else:
            print(f"Requested homework '{pre_hw}' not found among: {', '.join(hw_ids)}")
    if hw_id is None:
        hw_id = choose_from_list("Select a homework:", hw_ids)
    if hw_id is None:
        return None, None

    # Question selection
    questions = banks[hw_id].get("questions", {})
    q_ids = sorted(questions.keys(), key=lambda x: (len(x), x))

    q_id: Optional[str] = None
    if pre_q:
        if pre_q in q_ids:
            q_id = pre_q
        else:
            print(f"Requested question '{pre_q}' not found for {hw_id}. Available: {', '.join(q_ids)}")
    if q_id is None:
        q_id = choose_from_list(f"Select a question from {hw_id}:", q_ids)
    return hw_id, q_id


def main() -> None:
    parser = argparse.ArgumentParser(
        description="CLI concept-check app using pre-built homework conceptual question banks."
    )
    parser.add_argument(
        "--hw",
        "-w",
        type=str,
        default=None,
        help="Homework ID to jump to (e.g., 'hw1'). If omitted, you will choose interactively.",
    )
    parser.add_argument(
        "--q",
        type=str,
        default=None,
        help="Question ID within the homework (e.g., '1'). If omitted, you will choose interactively.",
    )
    parser.add_argument(
        "--model",
        type=str,
        default="gpt-4.1-mini",
        help="OpenAI model to use for grading (default: gpt-4.1-mini).",
    )
    args = parser.parse_args()

    base_dir = Path(__file__).resolve().parent
    concept_dir = base_dir / "concept_banks"

    banks = load_concept_banks(concept_dir)

    api_key = os.getenv("OPENAI_API_KEY") or None
    client: Optional[OpenAI] = None  # lazily initialized when first needed

    while True:
        hw_id, q_id = pick_homework_and_question(banks, args.hw, args.q)
        # After first loop iteration, ignore preselection (so that subsequent loops are all interactive).
        args.hw = None
        args.q = None

        if hw_id is None or q_id is None:
            print("Goodbye.")
            return

        concept_entries = banks[hw_id]["questions"].get(q_id) or []
        if not concept_entries:
            print(f"No conceptual entries found for homework {hw_id}, question {q_id}.")
            continue

        interaction_loop_for_question(
            client=client,
            api_key=api_key,
            model=args.model,
            hw_id=hw_id,
            q_id=q_id,
            concept_entries=concept_entries,
        )


if __name__ == "__main__":
    main()


