import argparse
import json
import os
from pathlib import Path
from typing import Any, Dict, List, Optional

from openai import OpenAI
from pypdf import PdfReader


def load_pdf_text(pdf_path: Path) -> str:
    """Extract text from a PDF file using pypdf."""
    reader = PdfReader(str(pdf_path))
    parts: List[str] = []
    for page in reader.pages:
        text = page.extract_text() or ""
        parts.append(text)
    full_text = "\n".join(parts)
    # Basic whitespace normalization
    return "\n".join(line.strip() for line in full_text.splitlines() if line.strip())


def build_prompt(homework_id: str, pdf_text: str) -> List[Dict[str, str]]:
    """Construct chat messages for the OpenAI API to generate conceptual questions."""
    system_msg = (
        "You are helping an instructor create conceptual understanding checks for an "
        "undergraduate machine learning / AI course.\n"
        "You will be given the full text of a homework assignment PDF.\n"
        "Your job is to:\n"
        "1. Identify each numbered homework question (1, 2, 3, ...) from the text.\n"
        "2. For each question, generate up to 3 conceptual questions that test deep understanding, "
        "not just surface-level computation.\n"
        "3. For each conceptual question, also provide:\n"
        "   - a short hint, and\n"
        '   - a concise ideal answer (2–6 sentences).\n\n'
        "Return your output as a single JSON object with the following exact structure:\n"
        '{\n'
        '  \"homework_id\": \"hwX\",\n'
        '  \"questions\": {\n'
        '    \"1\": [\n'
        '      {\n'
        '        \"concept_question\": \"...\",\n'
        '        \"hint\": \"...\",\n'
        '        \"ideal_answer\": \"...\"\n'
        '      }\n'
        '    ],\n'
        '    \"2\": [ ... ],\n'
        '    ...\n'
        '  }\n'
        '}\n\n'
        "- Use the question numbers as strings (\"1\", \"2\", ...).\n"
        "- Include only fields listed above. Do not include any extra fields.\n"
        "- Ensure the JSON is valid and can be parsed by a standard JSON parser."
    )

    user_msg = (
        f"Homework ID: {homework_id}\n\n"
        "Here is the full text of the homework PDF. Use it to identify the questions and create "
        "conceptual checks as described:\n\n"
        "----- BEGIN HOMEWORK TEXT -----\n"
        f"{pdf_text}\n"
        "----- END HOMEWORK TEXT -----\n"
    )

    return [
        {"role": "system", "content": system_msg},
        {"role": "user", "content": user_msg},
    ]


def call_openai(
    client: OpenAI, model: str, messages: List[Dict[str, str]]
) -> Dict[str, Any]:
    """Call the OpenAI Chat Completions API and parse JSON response."""
    response = client.chat.completions.create(
        model=model,
        messages=messages,
        response_format={"type": "json_object"},
        temperature=0.4,
    )
    content = response.choices[0].message.content
    if not content:
        raise RuntimeError("Empty response from OpenAI")
    try:
        data = json.loads(content)
    except json.JSONDecodeError as e:
        raise RuntimeError(f"Failed to parse JSON from OpenAI response: {e}\nRaw: {content}") from e
    return data


def validate_schema(data: Dict[str, Any], homework_id: str) -> Dict[str, Any]:
    """Basic validation of the conceptual bank structure."""
    if not isinstance(data, dict):
        raise ValueError("Top-level response must be a JSON object.")

    if "homework_id" not in data:
        data["homework_id"] = homework_id
    if data["homework_id"] != homework_id:
        data["homework_id"] = homework_id

    questions = data.get("questions")
    if not isinstance(questions, dict):
        raise ValueError("'questions' must be an object mapping question numbers to lists.")

    for q_num, entries in list(questions.items()):
        if not isinstance(entries, list):
            raise ValueError(f"questions['{q_num}'] must be a list.")
        cleaned_entries = []
        for entry in entries:
            if not isinstance(entry, dict):
                continue
            cq = entry.get("concept_question")
            hint = entry.get("hint")
            ideal = entry.get("ideal_answer")
            if not (isinstance(cq, str) and isinstance(hint, str) and isinstance(ideal, str)):
                continue
            cleaned_entries.append(
                {
                    "concept_question": cq.strip(),
                    "hint": hint.strip(),
                    "ideal_answer": ideal.strip(),
                }
            )
        if cleaned_entries:
            questions[q_num] = cleaned_entries
        else:
            # Drop questions with no valid entries
            questions.pop(q_num, None)

    data["questions"] = questions
    return data


def infer_homework_id(pdf_path: Path) -> str:
    """Infer a homework ID from a PDF filename, e.g. hw1.pdf -> hw1."""
    return pdf_path.stem


def find_homework_pdfs(hws_dir: Path, homework_filter: Optional[str]) -> List[Path]:
    """Find homework PDFs in the given directory, optionally filtered by ID."""
    pdfs = sorted(hws_dir.glob("*.pdf"))
    if homework_filter is None:
        return pdfs

    # Allow 'hw1' or 'hw1.pdf'
    target_stem = Path(homework_filter).stem
    return [p for p in pdfs if p.stem == target_stem]


def save_concept_bank(output_dir: Path, homework_id: str, data: Dict[str, Any]) -> Path:
    """Save the conceptual bank JSON for a homework."""
    output_dir.mkdir(parents=True, exist_ok=True)
    out_path = output_dir / f"{homework_id}.json"
    with out_path.open("w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    return out_path


def ensure_api_key() -> str:
    key = os.getenv("OPENAI_API_KEY")
    if not key:
        raise RuntimeError(
            "OPENAI_API_KEY environment variable is not set. "
            "Please export your OpenAI API key before running this script."
        )
    return key


def process_homework_pdf(
    client: OpenAI,
    model: str,
    pdf_path: Path,
    output_dir: Path,
    dry_run: bool = False,
) -> None:
    homework_id = infer_homework_id(pdf_path)
    print(f"\n=== Processing {pdf_path.name} (homework_id={homework_id}) ===")

    text = load_pdf_text(pdf_path)
    messages = build_prompt(homework_id, text)

    if dry_run:
        print("Dry run enabled; showing prompt but not calling OpenAI.")
        print("System message:\n", messages[0]["content"][:1000], "...\n")
        print("User message (first 1000 chars of homework text section):\n")
        print(messages[1]["content"][:1000], "...\n")
        return

    data = call_openai(client, model, messages)
    data = validate_schema(data, homework_id)
    if not data.get("questions"):
        print(f"Warning: no valid questions found for {homework_id}. Skipping save.")
        return

    out_path = save_concept_bank(output_dir, homework_id, data)
    print(f"Saved concept bank to {out_path}")


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Build conceptual question banks from homework PDFs using OpenAI."
    )
    parser.add_argument(
        "--hw",
        "-w",
        type=str,
        default=None,
        help="Specific homework ID or PDF name to process (e.g., 'hw1' or 'hw1.pdf'). "
        "If omitted, all PDFs in 'hws/' are processed.",
    )
    parser.add_argument(
        "--model",
        type=str,
        default="gpt-4.1-mini",
        help="OpenAI model to use for generation (default: gpt-4.1-mini).",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="If set, print the constructed prompt instead of calling the OpenAI API.",
    )

    args = parser.parse_args()

    base_dir = Path(__file__).resolve().parent
    hws_dir = base_dir / "hws"
    output_dir = base_dir / "concept_banks"

    if not hws_dir.is_dir():
        raise SystemExit(f"hws directory not found at: {hws_dir}")

    pdfs = find_homework_pdfs(hws_dir, args.hw)
    if not pdfs:
        if args.hw:
            raise SystemExit(f"No matching PDF found for homework filter '{args.hw}' in {hws_dir}")
        raise SystemExit(f"No PDF files found in {hws_dir}")

    if not args.dry_run:
        api_key = ensure_api_key()
        client = OpenAI(api_key=api_key)
    else:
        client = None  # type: ignore[assignment]

    for pdf in pdfs:
        process_homework_pdf(
            client=client,  # type: ignore[arg-type]
            model=args.model,
            pdf_path=pdf,
            output_dir=output_dir,
            dry_run=args.dry_run,
        )


if __name__ == "__main__":
    main()


