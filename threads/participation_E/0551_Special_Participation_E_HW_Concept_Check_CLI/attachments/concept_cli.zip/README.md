## Homework Concept Check Tool

This repo contains a small workflow to turn homework PDFs into conceptual check questions and then run an interactive CLI for students.

### Prerequisites

- Python 3.10+ recommended
- An OpenAI API key (for both bank building and grading)

Install dependencies from the project root:

```bash
pip install -r requirements.txt
```

### 1. Build the conceptual question banks

Place homework PDFs in the `hws/` directory (e.g., `hw1.pdf`, `hw2.pdf`, ...), then set your API key and run:

```bash
export OPENAI_API_KEY="sk-..."   # your key
python build_concept_bank.py          # processes all PDFs in hws/
```

To process just one homework:

```bash
python build_concept_bank.py --hw hw3
```

JSON concept banks will be written to `concept_banks/` as `hwX.json`.

### 2. Run the CLI concept checker

The CLI loads the JSON banks and lets a student pick a homework and question, view conceptual questions, request hints/answers, and get LLM-based grading.

From the project root:

```bash
python concept_cli_app.py
```

You can jump directly to a specific homework/question:

```bash
python concept_cli_app.py --hw hw3 --q 2
```

If `OPENAI_API_KEY` is not set, the CLI will prompt you once to paste a key for grading.


