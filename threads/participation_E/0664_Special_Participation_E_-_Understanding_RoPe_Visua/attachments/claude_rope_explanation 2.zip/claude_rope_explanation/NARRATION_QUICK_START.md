# Narration Quick Reference

## 🎯 What You Need to Do

Add voice narration to your RoPE video animations. Choose one of 3 methods below.

---

## ⚡ Quick Start (5 minutes)

### Option 1: Auto-Generate with Google TTS (EASIEST)

```bash
# Install
pip install gtts

# Generate all audio files
cd /mnt/user-data/outputs
python tts_generator.py --method gtts --scene all
```

**Result:** Audio files in `audio/` directory, ready to sync with video!

---

## 📊 Comparison Table

| Method | Quality | Time | Cost | Difficulty |
|--------|---------|------|------|-----------|
| **Google TTS** | ⭐⭐⭐ | 10 min | FREE | ⭐ Easy |
| **ElevenLabs TTS** | ⭐⭐⭐⭐⭐ | 10 min | $5/mo | ⭐⭐ Easy |
| **Manual Recording** | ⭐⭐⭐⭐⭐ | 3 hours | FREE | ⭐⭐⭐ Medium |
| **Manim Voiceover** | ⭐⭐⭐ | 1 hour | FREE | ⭐⭐⭐⭐ Hard |

---

## 🎤 Method 1: Google TTS (Recommended Start)

**Best for:** Quick preview, testing, or if you don't want to record

```bash
pip install gtts
python tts_generator.py --method gtts --scene all
```

**Output:** `audio/IntroScene_segment_01.mp3`, etc.

**Next:** Sync with video in DaVinci Resolve or iMovie

---

## 🎙️ Method 2: ElevenLabs TTS (Best Quality)

**Best for:** High-quality automated narration

```bash
# 1. Get free API key from https://elevenlabs.io/
pip install elevenlabs

# 2. Edit tts_generator.py, add your API key:
#    set_api_key("your-key-here")

# 3. Generate
python tts_generator.py --method elevenlabs --scene all
```

**Free tier:** 10,000 characters/month (enough for 2-3 scenes)

---

## 🎬 Method 3: Manual Recording (Pro Quality)

**Best for:** Final production, professional results

```bash
# 1. View the script
cat rope_narration_script.txt

# 2. Record using Audacity (free)
#    - Download: https://www.audacityteam.org/
#    - Follow timing in script
#    - Record in quiet room

# 3. Export as MP3
#    File > Export > Export as MP3
```

---

## 🔄 Method 4: Manim Voiceover (Integrated)

**Best for:** Automatic timing sync

```bash
pip install "manim-voiceover[gtts]"

# Modify rope_video.py scenes to add voiceover
# See NARRATION_GUIDE.md for code examples
```

---

## 📁 Files You Have

| File | Purpose |
|------|---------|
| `narration_generator.py` | Creates timed scripts |
| `tts_generator.py` | Auto-generates audio |
| `rope_narration_script.txt` | Full script with timing |
| `NARRATION_GUIDE.md` | Complete instructions |

---

## 🎬 Complete Workflow

### Fast Track (2 hours)
```bash
# 1. Generate audio
python tts_generator.py --method gtts --scene all

# 2. Render videos
manim -qh rope_video.py IntroScene
# (repeat for all scenes)

# 3. Sync in DaVinci Resolve
# Import videos and audio
# Align on timeline
# Export final video
```

### Pro Track (8 hours)
```bash
# 1. Review script
cat rope_narration_script.txt

# 2. Record your voice
# Use Audacity
# Follow script timing
# Export each scene

# 3. Render videos
manim -qh rope_video.py IntroScene
# (repeat for all scenes)

# 4. Edit in DaVinci Resolve
# Import all files
# Sync perfectly
# Add music
# Color grade
# Export final
```

---

## 📝 Scene-by-Scene Timing

```
IntroScene              : 2-3 min (8 segments)
TwoDRotationScene       : 2-3 min (8 segments)
TheMagicScene           : 3-4 min (10 segments)
ConcreteExampleScene    : 2-3 min (8 segments)
ChunkingScene           : 2-3 min (8 segments)
FrequencyScene          : 3-4 min (9 segments)
AlgorithmScene          : 2-3 min (8 segments)
PropertiesScene         : 2-3 min (8 segments)
SummaryScene            : 2-3 min (10 segments)
FourDimensionalExample  : 3-4 min (12 segments)

TOTAL: 25-30 minutes
```

---

## 🚀 Start Now

**Absolute fastest:**
```bash
cd /mnt/user-data/outputs
pip install gtts
python tts_generator.py --method gtts --scene IntroScene
```

**Check output:**
```bash
ls audio/
# Should see: IntroScene_segment_01.mp3, etc.
```

**Test it:**
```bash
# Play audio file (Mac)
afplay audio/IntroScene_segment_01.mp3

# Play audio file (Linux)
mpg123 audio/IntroScene_segment_01.mp3
```

---

## ❓ Questions?

- **Audio doesn't match timing?** Adjust `wait()` in rope_video.py
- **TTS sounds bad?** Try ElevenLabs or record manually
- **Need help editing?** See NARRATION_GUIDE.md
- **Want examples?** Audio files will be in `audio/` folder

---

## ✅ Checklist

- [ ] Choose narration method
- [ ] Install required packages
- [ ] Generate or record audio
- [ ] Render video scenes
- [ ] Sync in video editor
- [ ] Export final video
- [ ] Upload and share! 🎉

**Time to completion:** 2-8 hours depending on method

Good luck! 🎬
