"""
Additional Utility Visualizations for RoPE
Standalone scenes for specific concepts that can be inserted as needed
"""

from manim import *
import numpy as np


class AttentionHeatmapScene(Scene):
    """Visualize attention scores as a heatmap showing relative position bias"""
    
    def construct(self):
        title = Text("Attention Pattern with RoPE", font_size=42, color=BLUE).to_edge(UP)
        self.play(Write(title))
        
        # Create a heatmap of attention scores
        seq_len = 10
        grid = VGroup()
        
        # Generate attention scores (simplified simulation)
        for i in range(seq_len):
            row = VGroup()
            for j in range(seq_len):
                # Attention should depend on |i-j|
                distance = abs(i - j)
                # Simple decay function
                attention_score = np.exp(-distance * 0.3)
                
                # Color based on score
                color = interpolate_color(WHITE, BLUE, attention_score)
                
                cell = Square(side_length=0.6, fill_color=color, fill_opacity=0.8, stroke_width=1)
                cell.move_to(np.array([j * 0.65 - 3, 2 - i * 0.65, 0]))
                
                # Add score text for clarity
                if attention_score > 0.3:
                    score_text = Text(f"{attention_score:.2f}", font_size=12).move_to(cell)
                    row.add(VGroup(cell, score_text))
                else:
                    row.add(cell)
            
            grid.add(row)
        
        self.play(Create(grid), run_time=3)
        self.wait(2)
        
        # Add axis labels
        query_label = Text("Query Position →", font_size=24).next_to(grid, DOWN, buff=0.5)
        key_label = Text("Key Position", font_size=24).next_to(grid, LEFT, buff=0.5).rotate(PI/2)
        
        self.play(Write(query_label), Write(key_label))
        self.wait(2)
        
        # Highlight diagonal pattern
        diagonal_note = Text(
            "Notice: Attention depends on relative distance!",
            font_size=28,
            color=YELLOW
        ).to_edge(DOWN)
        
        self.play(Write(diagonal_note))
        self.wait(3)


class FrequencySpectrumScene(Scene):
    """Show how different frequencies decompose the position encoding"""
    
    def construct(self):
        title = Text("Frequency Spectrum of RoPE", font_size=42, color=TEAL).to_edge(UP)
        self.play(Write(title))
        
        # Create axes for frequency plot
        axes = Axes(
            x_range=[0, 256, 32],
            y_range=[0, 1.2, 0.2],
            x_length=10,
            y_length=4,
            axis_config={"include_numbers": True},
            tips=False
        ).shift(DOWN * 0.5)
        
        axes_labels = axes.get_axis_labels(
            x_label="Dimension Pair Index",
            y_label="Frequency (ω)"
        )
        
        self.play(Create(axes), Write(axes_labels))
        
        # Plot frequency values
        d = 512
        pairs = d // 2
        frequencies = []
        points = []
        
        for i in range(pairs):
            freq = 1.0 / (10000 ** (2 * i / d))
            frequencies.append(freq)
            point = axes.c2p(i, freq)
            points.append(point)
        
        # Create the curve
        freq_curve = VMobject(color=YELLOW)
        freq_curve.set_points_smoothly(points)
        
        self.play(Create(freq_curve), run_time=2)
        self.wait(1)
        
        # Highlight regions
        high_freq_box = Rectangle(
            width=2,
            height=4.5,
            color=RED,
            stroke_width=2
        ).move_to(axes.c2p(10, 0.6))
        
        high_label = Text("High freq\n(local)", font_size=20, color=RED).next_to(
            high_freq_box, UP, buff=0.2
        )
        
        self.play(Create(high_freq_box), Write(high_label))
        self.wait(1)
        
        low_freq_box = Rectangle(
            width=2,
            height=4.5,
            color=BLUE,
            stroke_width=2
        ).move_to(axes.c2p(240, 0.6))
        
        low_label = Text("Low freq\n(global)", font_size=20, color=BLUE).next_to(
            low_freq_box, UP, buff=0.2
        )
        
        self.play(Create(low_freq_box), Write(low_label))
        self.wait(3)


class ComparisonTableScene(Scene):
    """Create a comparison table of different position encoding methods"""
    
    def construct(self):
        title = Text("Position Encoding: Method Comparison", font_size=42, color=BLUE).to_edge(UP)
        self.play(Write(title))
        
        # Create table
        table_data = [
            ["Method", "Relative", "Learnable", "Extrapolate", "Complexity"],
            ["Absolute", "✗", "✓", "✗", "O(n)"],
            ["Sinusoidal", "✗", "✗", "✓", "O(n)"],
            ["Learned Bias", "✓", "✓", "✗", "O(n²)"],
            ["RoPE", "✓", "✗", "✓", "O(n)"]
        ]
        
        # Create table cells
        cell_height = 0.6
        cell_width = 2.2
        
        table = VGroup()
        for i, row in enumerate(table_data):
            row_group = VGroup()
            for j, cell_text in enumerate(row):
                # Header row in different color
                if i == 0:
                    cell = Rectangle(
                        height=cell_height,
                        width=cell_width,
                        fill_color=BLUE,
                        fill_opacity=0.3,
                        stroke_width=2
                    )
                    text_color = YELLOW
                # RoPE row highlighted
                elif i == 4:
                    cell = Rectangle(
                        height=cell_height,
                        width=cell_width,
                        fill_color=GREEN,
                        fill_opacity=0.2,
                        stroke_width=2
                    )
                    text_color = WHITE
                else:
                    cell = Rectangle(
                        height=cell_height,
                        width=cell_width,
                        stroke_width=1
                    )
                    text_color = WHITE
                
                text = Text(cell_text, font_size=20, color=text_color).move_to(cell)
                cell_group = VGroup(cell, text)
                row_group.add(cell_group)
            
            row_group.arrange(RIGHT, buff=0)
            table.add(row_group)
        
        table.arrange(DOWN, buff=0).shift(DOWN * 0.5)
        
        # Animate table creation
        self.play(Create(table[0]), run_time=1)  # Header
        for row in table[1:]:
            self.play(Create(row), run_time=0.8)
        
        self.wait(3)
        
        # Highlight RoPE row
        highlight = SurroundingRectangle(table[4], color=GREEN, buff=0.1, stroke_width=4)
        self.play(Create(highlight))
        self.wait(2)


class RotationVisualization3D(ThreeDScene):
    """3D visualization of rotation in embedding space"""
    
    def construct(self):
        # Set up 3D axes
        axes = ThreeDAxes(
            x_range=[-2, 2, 1],
            y_range=[-2, 2, 1],
            z_range=[-2, 2, 1],
            x_length=6,
            y_length=6,
            z_length=6
        )
        
        self.set_camera_orientation(phi=75 * DEGREES, theta=30 * DEGREES)
        
        # Add axes
        self.add(axes)
        
        # Create vectors at different positions
        colors = [RED, YELLOW, GREEN, BLUE, PURPLE]
        vectors = VGroup()
        
        for i, color in enumerate(colors):
            angle = i * 0.5
            x = 1.5 * np.cos(angle)
            y = 1.5 * np.sin(angle)
            z = 0
            
            vector = Arrow3D(
                start=np.array([0, 0, 0]),
                end=np.array([x, y, z]),
                color=color,
                thickness=0.02,
                height=0.3,
                base_radius=0.05
            )
            vectors.add(vector)
        
        self.play(Create(vectors), run_time=2)
        
        # Rotate camera
        self.begin_ambient_camera_rotation(rate=0.2)
        self.wait(8)
        self.stop_ambient_camera_rotation()
        
        self.wait(2)


class InterpolationScene(Scene):
    """Show how RoPE interpolates between positions"""
    
    def construct(self):
        title = Text("Position Interpolation", font_size=42, color=BLUE).to_edge(UP)
        self.play(Write(title))
        
        # Create position line
        line = Line(LEFT * 5, RIGHT * 5, color=GRAY).shift(DOWN * 1)
        self.play(Create(line))
        
        # Mark integer positions
        positions = VGroup()
        for i in range(-5, 6):
            dot = Dot(point=line.point_from_proportion((i + 5) / 10), color=WHITE)
            label = Text(str(i), font_size=20).next_to(dot, DOWN, buff=0.3)
            positions.add(VGroup(dot, label))
        
        self.play(Create(positions), run_time=2)
        self.wait(1)
        
        # Show interpolation
        interp_dot = Dot(color=YELLOW, radius=0.15)
        interp_label = Text("Position 2.5", font_size=24, color=YELLOW).next_to(
            line, UP, buff=1
        )
        
        # Move between positions
        path = line.copy()
        
        def update_pos(mob):
            interp_label.next_to(mob, UP, buff=0.5)
        
        interp_dot.add_updater(update_pos)
        
        self.play(
            MoveAlongPath(interp_dot, path),
            Write(interp_label),
            run_time=4,
            rate_func=linear
        )
        
        interp_dot.clear_updaters()
        
        # Explanation
        explain = Text(
            "RoPE naturally handles non-integer positions!\nRotation is continuous.",
            font_size=28,
            color=GREEN
        ).to_edge(DOWN)
        
        self.play(Write(explain))
        self.wait(3)


class ExtrapolationScene(Scene):
    """Demonstrate extrapolation capability"""
    
    def construct(self):
        title = Text("Extrapolation: Beyond Training Length", font_size=42, color=TEAL).to_edge(UP)
        self.play(Write(title))
        
        # Training range
        train_line = Line(LEFT * 4, RIGHT * 0, color=GREEN, stroke_width=8).shift(DOWN * 1)
        train_label = Text("Training\n(0-512)", font_size=24, color=GREEN).next_to(
            train_line, UP, buff=0.5
        )
        
        self.play(Create(train_line), Write(train_label))
        self.wait(1)
        
        # Extrapolation range
        extrap_line = Line(RIGHT * 0, RIGHT * 4, color=YELLOW, stroke_width=8).shift(DOWN * 1)
        extrap_label = Text("Extrapolation\n(513-1024)", font_size=24, color=YELLOW).next_to(
            extrap_line, UP, buff=0.5
        )
        
        self.play(Create(extrap_line), Write(extrap_label))
        self.wait(1)
        
        # Show continuity
        continuity = Text(
            "Rotation pattern continues naturally!",
            font_size=32,
            color=GREEN
        ).to_edge(DOWN)
        
        self.play(Write(continuity))
        self.wait(2)
        
        # Contrast with other methods
        self.play(
            FadeOut(VGroup(train_line, train_label, extrap_line, extrap_label, continuity))
        )
        
        learned_text = Text("Learned Position Embeddings:", font_size=30).shift(UP * 2)
        learned_fail = Text(
            "✗ Can't extrapolate - no embeddings for unseen positions",
            font_size=24,
            color=RED
        ).next_to(learned_text, DOWN, buff=0.5)
        
        rope_text = Text("RoPE:", font_size=30).next_to(learned_fail, DOWN, buff=1)
        rope_success = Text(
            "✓ Natural extrapolation - rotation continues infinitely",
            font_size=24,
            color=GREEN
        ).next_to(rope_text, DOWN, buff=0.5)
        
        self.play(Write(learned_text), Write(learned_fail))
        self.wait(2)
        self.play(Write(rope_text), Write(rope_success))
        self.wait(3)


class PerformanceMetricsScene(Scene):
    """Show performance comparison with actual metrics"""
    
    def construct(self):
        title = Text("RoPE Performance", font_size=42, color=BLUE).to_edge(UP)
        self.play(Write(title))
        
        # Create bar chart
        metrics = ["Memory", "Computation", "Long Range", "Accuracy"]
        rope_scores = [0.95, 0.9, 0.95, 0.92]
        learned_scores = [0.6, 0.85, 0.5, 0.88]
        
        chart = VGroup()
        bar_width = 0.4
        bar_gap = 0.1
        
        for i, (metric, rope, learned) in enumerate(zip(metrics, rope_scores, learned_scores)):
            # Metric label
            label = Text(metric, font_size=24).move_to(LEFT * 4 + DOWN * (i * 1.5 - 1.5))
            
            # RoPE bar
            rope_bar = Rectangle(
                width=rope * 4,
                height=bar_width,
                fill_color=GREEN,
                fill_opacity=0.7,
                stroke_width=0
            ).next_to(label, RIGHT, buff=0.5).align_to(label, LEFT).shift(RIGHT * 0.5)
            
            rope_label = Text(f"{rope:.0%}", font_size=20).next_to(rope_bar, RIGHT, buff=0.2)
            
            # Learned bar
            learned_bar = Rectangle(
                width=learned * 4,
                height=bar_width,
                fill_color=BLUE,
                fill_opacity=0.7,
                stroke_width=0
            ).next_to(rope_bar, DOWN, buff=bar_gap).align_to(rope_bar, LEFT)
            
            learned_label = Text(f"{learned:.0%}", font_size=20).next_to(learned_bar, RIGHT, buff=0.2)
            
            group = VGroup(label, rope_bar, rope_label, learned_bar, learned_label)
            chart.add(group)
        
        # Legend
        legend = VGroup(
            Rectangle(width=0.5, height=0.3, fill_color=GREEN, fill_opacity=0.7, stroke_width=0),
            Text("RoPE", font_size=20),
            Rectangle(width=0.5, height=0.3, fill_color=BLUE, fill_opacity=0.7, stroke_width=0),
            Text("Learned PE", font_size=20)
        ).arrange(RIGHT, buff=0.3).to_edge(DOWN)
        
        self.play(Write(chart), run_time=3)
        self.play(Write(legend))
        self.wait(3)


# Quick test scene
class QuickTest(Scene):
    """Quick test to verify setup"""
    
    def construct(self):
        text = Text("RoPE Animation Test", font_size=48, color=BLUE)
        self.play(Write(text))
        self.wait(1)
        
        formula = MathTex(r"R_t = \begin{bmatrix} \cos(\omega t) & -\sin(\omega t) \\ \sin(\omega t) & \cos(\omega t) \end{bmatrix}")
        formula.next_to(text, DOWN, buff=1)
        self.play(Write(formula))
        self.wait(2)


if __name__ == "__main__":
    # Test with: manim -pql rope_utils.py QuickTest
    pass