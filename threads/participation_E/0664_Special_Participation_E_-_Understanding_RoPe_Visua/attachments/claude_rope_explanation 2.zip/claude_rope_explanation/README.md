# RoPE Video Animation - Complete Guide

This is a comprehensive 3Blue1Brown-style educational video about RoPE (Rotary Position Embedding) using Manim.

## Installation

First, install Manim Community Edition:

```bash
pip install manim
```

For additional dependencies:
```bash
pip install numpy
```

## Running the Animation

### Render All Scenes in Sequence

To render all scenes at low quality (for preview):
```bash
manim -pql rope_video.py IntroScene TwoDRotationScene TheMagicScene ConcreteExampleScene ChunkingScene FrequencyScene AlgorithmScene PropertiesScene SummaryScene FourDimensionalExample
```

### Render Individual Scenes

**Scene 1: Introduction**
```bash
manim -pql rope_video.py IntroScene
```

**Scene 2: 2D Rotation Concept**
```bash
manim -pql rope_video.py TwoDRotationScene
```

**Scene 3: The Magic (Relative Position)**
```bash
manim -pql rope_video.py TheMagicScene
```

**Scene 4: Concrete Example with Numbers**
```bash
manim -pql rope_video.py ConcreteExampleScene
```

**Scene 5: Chunking for Higher Dimensions**
```bash
manim -pql rope_video.py ChunkingScene
```

**Scene 6: Multiple Frequencies (Clock Analogy)**
```bash
manim -pql rope_video.py FrequencyScene
```

**Scene 7: Algorithm Walkthrough**
```bash
manim -pql rope_video.py AlgorithmScene
```

**Scene 8: Key Properties**
```bash
manim -pql rope_video.py PropertiesScene
```

**Scene 9: Summary**
```bash
manim -pql rope_video.py SummaryScene
```

**Scene 10: 4D Detailed Example**
```bash
manim -pql rope_video.py FourDimensionalExample
```

## Quality Settings

- `-ql`: Low quality (480p15) - fast rendering for preview
- `-qm`: Medium quality (720p30) - good balance
- `-qh`: High quality (1080p60) - production quality
- `-qk`: 4K quality (2160p60) - highest quality

Example for high quality:
```bash
manim -pqh rope_video.py IntroScene
```

## Scene Structure

### 1. IntroScene (2-3 minutes)
- Introduces the problem: standard attention has no position information
- Shows what we want: relative position encoding
- Introduces RoPE as the solution

### 2. TwoDRotationScene (2-3 minutes)
- Visualizes 2D rotation concept
- Shows vectors at different positions rotating
- Introduces rotation matrix formula

### 3. TheMagicScene (3-4 minutes)
- Proves why rotation gives relative position
- Shows R_t^T × R_i = R_(t-i)
- Mathematical proof with step-by-step derivation

### 4. ConcreteExampleScene (2-3 minutes)
- Works through concrete numbers
- Uses ω=1, position 3 and position 1
- Shows actual calculations

### 5. ChunkingScene (2-3 minutes)
- Shows how to extend to higher dimensions
- Visualizes splitting vector into pairs
- Demonstrates different rotations per pair

### 6. FrequencyScene (3-4 minutes)
- Clock analogy visualization
- Shows multiple frequencies rotating at different speeds
- Explains high vs. low frequency roles

### 7. AlgorithmScene (2-3 minutes)
- Shows complete Python implementation
- Highlights key parts of the code
- Explains the algorithm flow

### 8. PropertiesScene (2-3 minutes)
- Lists all key properties
- Relative position, translation invariance, etc.
- Explains why each property matters

### 9. SummaryScene (2-3 minutes)
- Recap of main concepts
- Three key components
- Final takeaway message

### 10. FourDimensionalExample (3-4 minutes)
- Detailed 4D walkthrough
- Shows frequency calculation
- Demonstrates multi-scale encoding

## Customization

### Changing Colors

Edit the color constants at the top of `rope_video.py`:
```python
BLUE_E_CUSTOM = "#1C758A"
TEAL_E_CUSTOM = "#49A88F"
# etc.
```

### Adjusting Timing

Modify `wait()` durations in each scene:
```python
self.wait(2)  # Wait 2 seconds
```

Or animation run times:
```python
self.play(Write(text), run_time=1.5)
```

### Adding Narration

You can add voice-over by:
1. Using Manim's built-in voice-over features
2. Recording separately and syncing in post-production
3. Using text-to-speech tools

## Tips for Best Results

1. **Start with low quality** (`-ql`) to preview quickly
2. **Render final version in high quality** (`-qh` or `-qk`)
3. **Test individual scenes** before rendering all
4. **Adjust timing** based on your narration pace
5. **Use `-p` flag** to automatically play after rendering

## Combining Scenes

After rendering all scenes, combine them using video editing software:
- DaVinci Resolve (free)
- Adobe Premiere Pro
- Final Cut Pro
- Or use ffmpeg:

```bash
# Create a file list
echo "file 'IntroScene.mp4'" > files.txt
echo "file 'TwoDRotationScene.mp4'" >> files.txt
# ... add all scenes

# Concatenate
ffmpeg -f concat -safe 0 -i files.txt -c copy final_rope_video.mp4
```

## Troubleshooting

**Problem:** "ModuleNotFoundError: No module named 'manim'"
**Solution:** Install manim: `pip install manim`

**Problem:** Rendering is too slow
**Solution:** Use lower quality (`-ql`) for previews

**Problem:** Colors look wrong
**Solution:** Check your terminal/display color settings

**Problem:** Text doesn't fit
**Solution:** Adjust font_size parameter in the Text objects

## Advanced Modifications

### Adding Interactive Elements

You can make parts interactive for jupyter notebooks:
```python
from manim import *
from manim.interactive import *

class InteractiveRoPE(Scene):
    def construct(self):
        # Your interactive code here
        pass
```

### Exporting as GIF

```bash
manim -pql --format=gif rope_video.py IntroScene
```

### Rendering Specific Frame Range

```bash
manim -ql rope_video.py IntroScene -n 10,50
```
This renders frames 10-50 only.

## Additional Resources

- Manim Documentation: https://docs.manim.community/
- 3Blue1Brown: https://www.3blue1brown.com/
- RoPE Paper: "RoFormer: Enhanced Transformer with Rotary Position Embedding"

## Video Length Estimate

- Total runtime: ~25-30 minutes
- Can be shortened by:
  - Reducing wait times
  - Combining some scenes
  - Focusing on key concepts only

## License

Feel free to modify and use this code for educational purposes!