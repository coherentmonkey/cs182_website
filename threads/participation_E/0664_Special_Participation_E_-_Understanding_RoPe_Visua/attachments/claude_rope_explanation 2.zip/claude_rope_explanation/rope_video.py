"""
3Blue1Brown Style RoPE (Rotary Position Embedding) Video
Complete implementation covering all concepts from the detailed notes
"""

from manim import *
import numpy as np

# Configuration for 3B1B style
config.background_color = "#0f0f0f"
BLUE_E_CUSTOM = "#1C758A"
TEAL_E_CUSTOM = "#49A88F"
GREEN_E_CUSTOM = "#7AC74F"
YELLOW_E_CUSTOM = "#FAA613"
RED_E_CUSTOM = "#DC423F"


class IntroScene(Scene):
    """Scene 1: Introduction - The Problem RoPE Solves"""
    
    def construct(self):
        # Title
        title = Text("RoPE: Rotary Position Embedding", font_size=48, color=BLUE)
        subtitle = Text("How Transformers Learn Token Positions", font_size=32, color=GRAY)
        subtitle.next_to(title, DOWN)
        
        self.play(Write(title), run_time=1.5)
        self.play(FadeIn(subtitle, shift=UP), run_time=1)
        self.wait(2)
        self.play(FadeOut(title), FadeOut(subtitle))
        
        # The Problem
        problem_title = Text("The Problem", font_size=42, color=YELLOW).to_edge(UP)
        self.play(Write(problem_title))
        
        # Show tokens
        tokens = VGroup(
            *[Rectangle(height=0.8, width=1.2, color=BLUE, fill_opacity=0.3) 
              for _ in range(5)]
        ).arrange(RIGHT, buff=0.5)
        
        token_labels = VGroup(
            *[Text(f"Token\n{i}", font_size=20).move_to(tokens[i]) 
              for i in range(5)]
        )
        
        self.play(Create(tokens), Write(token_labels))
        self.wait(1)
        
        # Show the issue
        issue_text = Text(
            "Standard attention has NO position information!",
            font_size=32,
            color=RED
        ).next_to(tokens, DOWN, buff=1)
        
        formula = Text(
            "Attention = <q_t, k_i> / sqrt(d)",
            font_size=36,
            color=WHITE
        ).next_to(issue_text, DOWN, buff=0.5)
        
        self.play(Write(issue_text))
        self.wait(1)
        self.play(Write(formula))
        self.wait(2)
        
        # Show what we want
        self.play(
            FadeOut(issue_text),
            FadeOut(formula)
        )
        
        want_text = Text("What We Want:", font_size=36, color=GREEN).next_to(tokens, DOWN, buff=1)
        want_details = VGroup(
            Text("• Relative positions matter", font_size=28),
            Text("• Position 5→3 same as 105→103", font_size=28),
            Text("• Both have distance = 2", font_size=28)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.3).next_to(want_text, DOWN, buff=0.5)
        
        self.play(Write(want_text))
        self.play(Write(want_details), run_time=2)
        self.wait(2)
        
        # Transition to solution
        solution = Text("RoPE's Solution: ROTATE!", font_size=42, color=TEAL)
        self.play(
            FadeOut(problem_title),
            FadeOut(tokens),
            FadeOut(token_labels),
            FadeOut(want_text),
            FadeOut(want_details),
            Transform(solution, solution.move_to(ORIGIN))
        )
        self.wait(2)
        self.play(FadeOut(solution))


class TwoDRotationScene(Scene):
    """Scene 2: 2D Rotation - The Core Concept"""
    
    def construct(self):
        title = Text("RoPE in 2D: The Foundation", font_size=42, color=BLUE).to_edge(UP)
        self.play(Write(title))
        
        # Set up coordinate system
        axes = Axes(
            x_range=[-2, 2, 1],
            y_range=[-2, 2, 1],
            x_length=6,
            y_length=6,
            tips=False
        ).shift(LEFT * 3)
        
        axes_labels = axes.get_axis_labels(
            x_label=Text("x₁", font_size=24),
            y_label=Text("x₂", font_size=24)
        )
        
        self.play(Create(axes), Write(axes_labels))
        
        # Show rotation formula as text
        rotation_formula = VGroup(
            Text("Rotation Matrix R_t:", font_size=28, color=YELLOW),
            Text("[ cos(ωt)  -sin(ωt) ]", font_size=26),
            Text("[ sin(ωt)   cos(ωt) ]", font_size=26)
        ).arrange(DOWN, buff=0.2, aligned_edge=LEFT).to_edge(RIGHT).shift(UP * 2)
        
        omega_note = Text("ω = frequency (e.g., 1/10000)", font_size=24, color=YELLOW).next_to(
            rotation_formula, DOWN, buff=0.5
        )
        
        self.play(Write(rotation_formula))
        self.play(Write(omega_note))
        self.wait(2)
        
        # Show a vector rotating through different positions
        vector_start = np.array([1.5, 0, 0])
        
        # Position 0 (no rotation)
        vector_0 = Arrow(
            axes.c2p(0, 0),
            axes.c2p(1.5, 0),
            buff=0,
            color=GREEN,
            stroke_width=6
        )
        label_0 = Text("Position 0", font_size=24, color=GREEN).next_to(vector_0, RIGHT)
        
        self.play(Create(vector_0), Write(label_0))
        self.wait(1)
        
        # Position 1
        angle_1 = 1  # ω * t, assuming ω = 1 for simplicity
        vector_1_end = np.array([1.5 * np.cos(angle_1), 1.5 * np.sin(angle_1), 0])
        vector_1 = Arrow(
            axes.c2p(0, 0),
            axes.c2p(vector_1_end[0], vector_1_end[1]),
            buff=0,
            color=BLUE,
            stroke_width=6
        )
        label_1 = Text("Position 1", font_size=24, color=BLUE).next_to(vector_1, UP)
        
        self.play(
            Transform(vector_0, vector_1),
            Transform(label_0, label_1)
        )
        self.wait(1)
        
        # Position 2
        angle_2 = 2
        vector_2_end = np.array([1.5 * np.cos(angle_2), 1.5 * np.sin(angle_2), 0])
        vector_2 = Arrow(
            axes.c2p(0, 0),
            axes.c2p(vector_2_end[0], vector_2_end[1]),
            buff=0,
            color=YELLOW,
            stroke_width=6
        )
        label_2 = Text("Position 2", font_size=24, color=YELLOW).next_to(vector_2, LEFT)
        
        self.play(
            Transform(vector_0, vector_2),
            Transform(label_0, label_2)
        )
        self.wait(1)
        
        # Position 3
        angle_3 = 3
        vector_3_end = np.array([1.5 * np.cos(angle_3), 1.5 * np.sin(angle_3), 0])
        vector_3 = Arrow(
            axes.c2p(0, 0),
            axes.c2p(vector_3_end[0], vector_3_end[1]),
            buff=0,
            color=RED,
            stroke_width=6
        )
        label_3 = Text("Position 3", font_size=24, color=RED).next_to(vector_3, DOWN)
        
        self.play(
            Transform(vector_0, vector_3),
            Transform(label_0, label_3)
        )
        self.wait(2)
        
        # Show all positions at once
        self.play(FadeOut(vector_0), FadeOut(label_0))
        
        all_vectors = VGroup()
        all_labels = VGroup()
        for pos in range(8):
            angle = pos * 0.5  # Smaller increments for visual effect
            vec_end = np.array([1.5 * np.cos(angle), 1.5 * np.sin(angle), 0])
            vec = Arrow(
                axes.c2p(0, 0),
                axes.c2p(vec_end[0], vec_end[1]),
                buff=0,
                color=interpolate_color(GREEN, RED, pos / 7),
                stroke_width=4
            )
            all_vectors.add(vec)
        
        self.play(Create(all_vectors), run_time=2)
        self.wait(2)
        
        self.play(
            FadeOut(all_vectors),
            FadeOut(axes),
            FadeOut(axes_labels),
            FadeOut(rotation_formula),
            FadeOut(omega_note),
            FadeOut(title)
        )


class TheMagicScene(Scene):
    """Scene 3: The Magic - Why Rotation Gives Relative Position"""
    
    def construct(self):
        title = Text("The Magic: Relative Position Emerges!", font_size=42, color=TEAL).to_edge(UP)
        self.play(Write(title))
        self.wait(1)
        
        # Show the attention computation
        step1 = Text(
            "Attention = <R_t q, R_i k>",
            font_size=36
        ).shift(UP * 2)
        
        self.play(Write(step1))
        self.wait(1)
        
        # Expand the dot product
        step2 = Text(
            "= (R_t q)^T (R_i k)",
            font_size=36
        ).next_to(step1, DOWN, buff=0.5)
        
        self.play(Write(step2))
        self.wait(1)
        
        step3 = Text(
            "= q^T R_t^T R_i k",
            font_size=36
        ).next_to(step2, DOWN, buff=0.5)
        
        self.play(Write(step3))
        self.wait(1)
        
        # The key property box
        key_property = Rectangle(
            height=1.5,
            width=8,
            color=YELLOW,
            stroke_width=4
        ).next_to(step3, DOWN, buff=0.8)
        
        key_text = Text(
            "R_t^T R_i = R_(t-i)",
            font_size=42,
            color=YELLOW
        ).move_to(key_property)
        
        self.play(Create(key_property))
        self.play(Write(key_text))
        self.wait(2)
        
        # Result
        result = Text(
            "Attention = q^T R_(t-i) k",
            font_size=40,
            color=GREEN
        ).next_to(key_property, DOWN, buff=0.8)
        
        result_box = SurroundingRectangle(result, color=GREEN, buff=0.2)
        
        self.play(Write(result))
        self.play(Create(result_box))
        self.wait(1)
        
        # Highlight the key insight
        insight = Text(
            "Only depends on relative distance (t-i)!",
            font_size=32,
            color=GREEN
        ).next_to(result_box, DOWN, buff=0.5)
        
        self.play(Write(insight))
        self.wait(3)
        
        # Prove it
        self.play(
            FadeOut(VGroup(step1, step2, step3, key_property, key_text, result, result_box, insight))
        )
        
        proof_title = Text("Proof:", font_size=36, color=YELLOW).shift(UP * 3)
        self.play(Transform(title, proof_title))
        
        proof1 = VGroup(
            Text("R_t^T = [ cos(ωt)   sin(ωt) ]", font_size=28),
            Text("        [-sin(ωt)  cos(ωt) ]", font_size=28)
        ).arrange(DOWN, buff=0.1, aligned_edge=LEFT).shift(UP * 1.5)
        
        self.play(Write(proof1))
        self.wait(1)
        
        proof2 = VGroup(
            Text("R_i = [ cos(ωi)  -sin(ωi) ]", font_size=28),
            Text("      [ sin(ωi)   cos(ωi) ]", font_size=28)
        ).arrange(DOWN, buff=0.1, aligned_edge=LEFT).next_to(proof1, DOWN, buff=0.5)
        
        self.play(Write(proof2))
        self.wait(1)
        
        proof3 = VGroup(
            Text("R_t^T R_i = [ cos(ω(t-i))  -sin(ω(t-i)) ]", font_size=24),
            Text("            [ sin(ω(t-i))   cos(ω(t-i)) ]", font_size=24)
        ).arrange(DOWN, buff=0.1, aligned_edge=LEFT).next_to(proof2, DOWN, buff=0.5)
        
        self.play(Write(proof3))
        self.wait(1)
        
        proof4 = Text(
            "= R_(t-i)",
            font_size=36,
            color=GREEN
        ).next_to(proof3, DOWN, buff=0.5)
        
        self.play(Write(proof4))
        self.wait(3)
        
        self.play(FadeOut(VGroup(title, proof_title, proof1, proof2, proof3, proof4)))


class ConcreteExampleScene(Scene):
    """Scene 4: Concrete 2D Example with Numbers"""
    
    def construct(self):
        title = Text("Concrete Example: Numbers!", font_size=42, color=BLUE).to_edge(UP)
        self.play(Write(title))
        
        # Setup
        setup_text = Text("Setup:", font_size=32, color=YELLOW).shift(UP * 2.5)
        setup_details = VGroup(
            Text("ω = 1 (for simplicity)", font_size=28),
            Text("q_3 = [1, 0] (position 3)", font_size=28),
            Text("k_1 = [0, 1] (position 1)", font_size=28)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.3).next_to(setup_text, DOWN, buff=0.3)
        
        self.play(Write(setup_text))
        self.play(Write(setup_details), run_time=2)
        self.wait(2)
        
        # Step-by-step calculation
        self.play(FadeOut(setup_text), FadeOut(setup_details))
        
        step_title = Text("Step-by-step:", font_size=32, color=YELLOW).shift(UP * 3)
        self.play(Write(step_title))
        
        # Rotation matrices
        r3_calc = VGroup(
            Text("R_3 = [ cos(3)  -sin(3) ] ≈ [-0.99  -0.14]", font_size=24),
            Text("      [ sin(3)   cos(3) ]     [ 0.14  -0.99]", font_size=24)
        ).arrange(DOWN, buff=0.1, aligned_edge=LEFT).shift(UP * 2)
        
        self.play(Write(r3_calc))
        self.wait(1)
        
        r1_calc = VGroup(
            Text("R_1 = [ cos(1)  -sin(1) ] ≈ [ 0.54  -0.84]", font_size=24),
            Text("      [ sin(1)   cos(1) ]     [ 0.84   0.54]", font_size=24)
        ).arrange(DOWN, buff=0.1, aligned_edge=LEFT).next_to(r3_calc, DOWN, buff=0.5)
        
        self.play(Write(r1_calc))
        self.wait(1)
        
        # Rotated vectors
        rotated_q = Text(
            "R_3 q_3 = [-0.99, 0.14]^T",
            font_size=30
        ).next_to(r1_calc, DOWN, buff=0.5)
        
        self.play(Write(rotated_q))
        self.wait(1)
        
        rotated_k = Text(
            "R_1 k_1 = [-0.84, 0.54]^T",
            font_size=30
        ).next_to(rotated_q, DOWN, buff=0.3)
        
        self.play(Write(rotated_k))
        self.wait(1)
        
        # Dot product
        dot_product = Text(
            "<R_3 q_3, R_1 k_1> = (-0.99)(-0.84) + (0.14)(0.54) ≈ 0.91",
            font_size=26
        ).next_to(rotated_k, DOWN, buff=0.5)
        
        self.play(Write(dot_product))
        self.wait(2)
        
        # Verify with relative position
        verify = Text("Verify with relative position:", font_size=28, color=GREEN).next_to(
            dot_product, DOWN, buff=0.7
        )
        self.play(Write(verify))
        
        r2_calc = Text(
            "R_2 = R_(3-1) ⇒ q_3^T R_2 k_1 ≈ 0.91 ✓",
            font_size=28,
            color=GREEN
        ).next_to(verify, DOWN, buff=0.3)
        
        self.play(Write(r2_calc))
        self.wait(3)
        
        # Fade out all objects
        self.play(*[FadeOut(mob) for mob in self.mobjects])


class ChunkingScene(Scene):
    """Scene 5: Extending to Higher Dimensions with Chunking"""
    
    def construct(self):
        title = Text("Higher Dimensions: Chunking Strategy", font_size=42, color=BLUE).to_edge(UP)
        self.play(Write(title))
        
        # Show the problem
        problem = Text(
            "Real embeddings: 512, 1024, or larger dimensions",
            font_size=32,
            color=YELLOW
        ).shift(UP * 2)
        
        self.play(Write(problem))
        self.wait(2)
        
        # Show a high-D vector
        vector_visual = VGroup(
            *[Rectangle(height=0.5, width=0.5, color=BLUE, fill_opacity=0.5) 
              for _ in range(12)]
        ).arrange(RIGHT, buff=0.1).shift(UP * 0.5)
        
        vector_label = Text(
            "[x₁, x₂, x₃, x₄, x₅, x₆, ..., x₁₀₀₀]",
            font_size=28
        ).next_to(vector_visual, DOWN, buff=0.5)
        
        self.play(Create(vector_visual))
        self.play(Write(vector_label))
        self.wait(2)
        
        # Show chunking
        self.play(FadeOut(problem))
        
        chunk_text = Text("Solution: Split into pairs!", font_size=36, color=GREEN).shift(UP * 2)
        self.play(Write(chunk_text))
        
        # Animate chunking
        pairs = VGroup()
        pair_colors = [RED, GREEN, BLUE, YELLOW, TEAL, PURPLE]
        
        for i in range(6):
            pair = VGroup(vector_visual[i * 2], vector_visual[i * 2 + 1])
            pairs.add(pair)
            self.play(
                pair.animate.set_color(pair_colors[i]),
                run_time=0.3
            )
        
        self.wait(1)
        
        # Separate pairs
        separated_pairs = VGroup()
        for i, pair_color in enumerate(pair_colors):
            pair_group = VGroup(
                Rectangle(height=0.5, width=0.5, color=pair_color, fill_opacity=0.5),
                Rectangle(height=0.5, width=0.5, color=pair_color, fill_opacity=0.5)
            ).arrange(RIGHT, buff=0.05)
            separated_pairs.add(pair_group)
        
        separated_pairs.arrange(RIGHT, buff=0.4).shift(DOWN * 0.5)
        
        self.play(
            Transform(vector_visual, separated_pairs),
            FadeOut(vector_label)
        )
        self.wait(1)
        
        # Show different rotations
        rotation_labels = VGroup()
        for i in range(6):
            label = Text(
                f"R_t^(ω_{i})",
                font_size=24,
                color=pair_colors[i]
            ).next_to(separated_pairs[i], DOWN, buff=0.3)
            rotation_labels.add(label)
        
        self.play(Write(rotation_labels), run_time=2)
        self.wait(2)
        
        # Key insight
        insight = Text(
            "Each pair rotates at a different frequency!",
            font_size=32,
            color=YELLOW
        ).shift(DOWN * 2.5)
        
        self.play(Write(insight))
        self.wait(3)
        
        self.play(*[FadeOut(mob) for mob in self.mobjects])


class FrequencyScene(Scene):
    """Scene 6: Multiple Frequencies - The Clock Analogy"""
    
    def construct(self):
        title = Text("Multiple Frequencies: Like Clock Hands", font_size=42, color=TEAL).to_edge(UP)
        self.play(Write(title))
        
        # Show frequency formula
        freq_formula = Text(
            "ω_i = 1 / (10000^(2i/d))",
            font_size=40
        ).shift(UP * 2.5)
        
        self.play(Write(freq_formula))
        self.wait(2)
        
        # Create multiple rotating vectors at different speeds
        axes_group = VGroup()
        vector_group = VGroup()
        label_group = VGroup()
        
        frequencies = [1, 0.1, 0.01, 0.001]
        freq_labels = ["High ω", "Medium ω", "Low ω", "Very Low ω"]
        colors = [RED, YELLOW, GREEN, BLUE]
        
        for i in range(4):
            # Create small axes
            axes = Axes(
                x_range=[-1.5, 1.5, 1],
                y_range=[-1.5, 1.5, 1],
                x_length=2.5,
                y_length=2.5,
                tips=False,
                axis_config={"stroke_width": 1}
            )
            
            if i < 2:
                axes.shift(LEFT * 3 + UP * 0.5 + RIGHT * i * 3.5)
            else:
                axes.shift(LEFT * 3 + DOWN * 2 + RIGHT * (i - 2) * 3.5)
            
            axes_group.add(axes)
            
            # Vector
            vector = Arrow(
                axes.c2p(0, 0),
                axes.c2p(1, 0),
                buff=0,
                color=colors[i],
                stroke_width=4
            )
            vector_group.add(vector)
            
            # Label
            label = Text(freq_labels[i], font_size=20, color=colors[i]).next_to(axes, UP, buff=0.2)
            label_group.add(label)
        
        self.play(
            Create(axes_group),
            Create(vector_group),
            Write(label_group)
        )
        self.wait(1)
        
        # Animate rotations at different speeds
        def update_vectors(mob, dt, frequencies=frequencies, axes_group=axes_group):
            for i, (vector, freq) in enumerate(zip(mob, frequencies)):
                # Get current angle
                start = axes_group[i].c2p(0, 0)
                end = vector.get_end()
                current_angle = np.angle(complex(end[0] - start[0], end[1] - start[1]))
                
                # Update angle
                new_angle = current_angle + freq * dt * 2
                new_end = axes_group[i].c2p(np.cos(new_angle), np.sin(new_angle))
                
                # Update vector
                new_vector = Arrow(
                    start,
                    new_end,
                    buff=0,
                    color=vector.get_color(),
                    stroke_width=4
                )
                vector.become(new_vector)
        
        vector_group.add_updater(lambda m, dt: update_vectors(m, dt))
        
        # Let them rotate
        self.wait(10)
        
        vector_group.clear_updaters()
        
        # Explanation
        self.play(FadeOut(freq_formula))
        
        explanation = VGroup(
            Text("High frequency:", font_size=28, color=RED),
            Text("  • Fast rotation", font_size=24),
            Text("  • Distinguishes nearby positions", font_size=24),
            Text("Low frequency:", font_size=28, color=BLUE),
            Text("  • Slow rotation", font_size=24),
            Text("  • Captures long-range patterns", font_size=24)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.2).shift(UP * 2.5)
        
        self.play(Write(explanation), run_time=3)
        self.wait(3)
        
        self.play(*[FadeOut(mob) for mob in self.mobjects])


class AlgorithmScene(Scene):
    """Scene 7: Full Algorithm Walkthrough"""
    
    def construct(self):
        title = Text("The Complete RoPE Algorithm", font_size=42, color=BLUE).to_edge(UP)
        self.play(Write(title))
        self.wait(1)
        
        # Show algorithm as simple bullet points instead of code
        algo_title = Text("The Algorithm:", font_size=32, color=YELLOW).shift(UP * 2)
        
        steps = VGroup(
            Text("1. Split vector into pairs of dimensions", font_size=26),
            Text("2. For each pair (i):", font_size=26),
            Text("   • Calculate frequency: ω_i = 1/(10000^(2i/d))", font_size=24, color=YELLOW),
            Text("   • Calculate angle: θ = ω_i × position", font_size=24, color=YELLOW),
            Text("3. Apply 2D rotation to each pair:", font_size=26),
            Text("   • v1_new = v1×cos(θ) - v2×sin(θ)", font_size=24, color=GREEN),
            Text("   • v2_new = v1×sin(θ) + v2×cos(θ)", font_size=24, color=GREEN),
            Text("4. Concatenate all rotated pairs", font_size=26),
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.4).next_to(algo_title, DOWN, buff=0.6)
        
        self.play(Write(algo_title))
        self.wait(1)
        
        # Animate steps one by one
        for i, step in enumerate(steps):
            self.play(Write(step), run_time=0.8)
            if i in [2, 3]:  # Pause after key steps
                self.wait(1.5)
            else:
                self.wait(0.5)
        
        self.wait(2)
        
        # Highlight the key insight
        key_box = Rectangle(
            width=steps[5:7].width + 0.5,
            height=steps[5:7].height + 0.3,
            color=GREEN,
            stroke_width=3
        ).move_to(steps[5:7])
        
        insight = Text(
            "Core: Just standard 2D rotation!",
            font_size=28,
            color=GREEN
        ).to_edge(DOWN, buff=1)
        
        self.play(Create(key_box))
        self.play(Write(insight))
        self.wait(3)
        
        self.play(*[FadeOut(mob) for mob in self.mobjects])


class PropertiesScene(Scene):
    """Scene 8: Key Properties of RoPE"""
    
    def construct(self):
        title = Text("Key Properties of RoPE", font_size=42, color=TEAL).to_edge(UP)
        self.play(Write(title))
        
        properties = VGroup(
            VGroup(
                Text("✓ Relative Position Encoding", font_size=32, color=GREEN),
                Text("Attention depends only on (t-i)", font_size=24).shift(RIGHT * 0.5)
            ).arrange(DOWN, aligned_edge=LEFT, buff=0.2),
            
            VGroup(
                Text("✓ Translation Invariance", font_size=32, color=GREEN),
                Text("Shifting positions doesn't change attention", font_size=24).shift(RIGHT * 0.5)
            ).arrange(DOWN, aligned_edge=LEFT, buff=0.2),
            
            VGroup(
                Text("✓ Natural Distance Decay", font_size=32, color=GREEN),
                Text("Attention decreases for distant tokens", font_size=24).shift(RIGHT * 0.5)
            ).arrange(DOWN, aligned_edge=LEFT, buff=0.2),
            
            VGroup(
                Text("✓ Efficient", font_size=32, color=GREEN),
                Text("No learnable parameters, O(n) complexity", font_size=24).shift(RIGHT * 0.5)
            ).arrange(DOWN, aligned_edge=LEFT, buff=0.2),
            
            VGroup(
                Text("✓ Extrapolation", font_size=32, color=GREEN),
                Text("Handles longer sequences than training", font_size=24).shift(RIGHT * 0.5)
            ).arrange(DOWN, aligned_edge=LEFT, buff=0.2)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.6).shift(DOWN * 0.5)
        
        for prop in properties:
            self.play(Write(prop), run_time=1.5)
            self.wait(1)
        
        self.wait(3)
        self.play(*[FadeOut(mob) for mob in self.mobjects])


class SummaryScene(Scene):
    """Scene 9: Visual Summary"""
    
    def construct(self):
        title = Text("RoPE: The Big Picture", font_size=48, color=BLUE).to_edge(UP)
        self.play(Write(title))
        
        # Core insight
        core = VGroup(
            Text("Core Insight:", font_size=36, color=YELLOW),
            Text("R_t^T R_i = R_(t-i)", font_size=40, color=GREEN),
            Text("Rotation encodes relative position!", font_size=28)
        ).arrange(DOWN, buff=0.5).shift(UP * 1.5)
        
        self.play(Write(core), run_time=2)
        self.wait(2)
        
        # Three key components
        components = VGroup(
            VGroup(
                Text("1. Chunking", font_size=30, color=TEAL),
                Text("Split dimensions into pairs", font_size=22)
            ).arrange(DOWN, buff=0.2, aligned_edge=LEFT),
            
            VGroup(
                Text("2. Multiple Frequencies", font_size=30, color=TEAL),
                Text("Capture local & global patterns", font_size=22)
            ).arrange(DOWN, buff=0.2, aligned_edge=LEFT),
            
            VGroup(
                Text("3. Rotation Math", font_size=30, color=TEAL),
                Text("Ensures relative position", font_size=22)
            ).arrange(DOWN, buff=0.2, aligned_edge=LEFT)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.5).shift(DOWN * 1)
        
        self.play(Write(components), run_time=3)
        self.wait(3)
        
        # Final message
        self.play(FadeOut(core), FadeOut(components))
        
        final = VGroup(
            Text("Result:", font_size=36, color=YELLOW),
            Text("A simple, elegant solution", font_size=32),
            Text("for teaching Transformers", font_size=32),
            Text("about token positions!", font_size=32, color=GREEN)
        ).arrange(DOWN, buff=0.4)
        
        self.play(Write(final), run_time=2)
        self.wait(3)
        
        # End
        self.play(*[FadeOut(mob) for mob in self.mobjects])
        
        end_text = Text("RoPE: Rotary Position Embedding", font_size=48, color=BLUE)
        self.play(Write(end_text))
        self.wait(3)
        self.play(FadeOut(end_text))


# Additional scene for detailed 4D example (from your notes)
class FourDimensionalExample(Scene):
    """Detailed 4D mathematical example"""
    
    def construct(self):
        title = Text("4D Example: Step by Step", font_size=42, color=BLUE).to_edge(UP)
        self.play(Write(title))
        
        # Setup
        setup = VGroup(
            Text("q_3 = [1, 0, 1, 0] at position 3", font_size=30),
            Text("k_1 = [0, 1, 1, 0] at position 1", font_size=30),
            Text("d = 4", font_size=30)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.3).shift(UP * 2)
        
        self.play(Write(setup), run_time=2)
        self.wait(2)
        
        # Calculate frequencies
        self.play(FadeOut(setup))
        
        freq_calc = VGroup(
            Text("Step 1: Calculate Frequencies", font_size=30, color=YELLOW).to_edge(UP),
            Text("ω_0 = 1 / (10000^(0/4)) = 1", font_size=28),
            Text("ω_1 = 1 / (10000^(2/4)) = 1/100 = 0.01", font_size=28)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.4).shift(UP * 1.5)
        
        self.play(Write(freq_calc), run_time=2)
        self.wait(2)
        
        # Show pair rotations
        self.play(FadeOut(freq_calc))
        
        pair_title = Text("Step 2: Rotate Each Pair", font_size=30, color=YELLOW).to_edge(UP)
        self.play(Write(pair_title))
        
        pair0 = Text(
            "Pair 0 (fast): [1,0] → [cos(3), sin(3)]",
            font_size=26
        ).shift(UP * 1.5)
        
        pair1 = Text(
            "Pair 1 (slow): [1,0] → [cos(0.03), sin(0.03)]",
            font_size=26
        ).next_to(pair0, DOWN, buff=0.5)
        
        self.play(Write(pair0))
        self.wait(1)
        self.play(Write(pair1))
        self.wait(2)
        
        # Final attention score
        final = Text(
            "Score ≈ sin(2) + cos(0.02)",
            font_size=30,
            color=GREEN
        ).shift(DOWN * 1)
        
        final_note = Text(
            "Depends on relative position (3-1=2) at multiple scales!",
            font_size=24,
            color=GREEN
        ).next_to(final, DOWN, buff=0.5)
        
        self.play(Write(final))
        self.play(Write(final_note))
        self.wait(3)
        
        self.play(*[FadeOut(mob) for mob in self.mobjects])


# Main rendering configuration
if __name__ == "__main__":
    # To render all scenes:
    # manim -pql rope_video.py IntroScene TwoDRotationScene TheMagicScene ConcreteExampleScene ChunkingScene FrequencyScene AlgorithmScene PropertiesScene SummaryScene
    
    # Or render high quality:
    # manim -pqh rope_video.py IntroScene
    pass