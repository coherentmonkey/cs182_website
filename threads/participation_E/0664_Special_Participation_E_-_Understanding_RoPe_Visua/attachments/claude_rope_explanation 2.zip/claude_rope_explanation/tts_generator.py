"""
Text-to-Speech Integration for RoPE Video
Generates audio narration files from the scripts
"""

import os
from pathlib import Path

# Import the narration scripts
import sys
sys.path.append('/mnt/user-data/outputs')
from narration_generator import NARRATION_SCRIPTS


def generate_tts_elevenlabs(scene_name, output_dir="audio"):
    """
    Generate TTS using ElevenLabs API
    
    Install: pip install elevenlabs
    Get API key from: https://elevenlabs.io/
    """
    try:
        from elevenlabs import generate, save, set_api_key
        
        # Set your API key (get free key from elevenlabs.io)
        # set_api_key("your-api-key-here")
        
        os.makedirs(output_dir, exist_ok=True)
        
        scene = NARRATION_SCRIPTS[scene_name]
        
        print(f"\nGenerating audio for {scene_name}...")
        
        for i, segment in enumerate(scene['script']):
            text = segment['narration']
            time_code = segment['time']
            
            print(f"  Segment {i+1}/{len(scene['script'])}: [{time_code}]")
            
            # Generate audio
            audio = generate(
                text=text,
                voice="Adam",  # Options: Adam, Antoni, Arnold, Bella, Domi, Elli, Josh, Rachel, Sam
                model="eleven_monolingual_v1"
            )
            
            # Save to file
            filename = f"{output_dir}/{scene_name}_segment_{i+1:02d}.mp3"
            save(audio, filename)
            
            print(f"    ✓ Saved: {filename}")
        
        print(f"\n✓ Completed {scene_name}")
        
    except ImportError:
        print("Please install: pip install elevenlabs")
    except Exception as e:
        print(f"Error: {e}")
        print("\nMake sure to:")
        print("1. Install: pip install elevenlabs")
        print("2. Get API key from https://elevenlabs.io/")
        print("3. Set key in code: set_api_key('your-key')")


def generate_tts_gtts(scene_name, output_dir="audio"):
    """
    Generate TTS using Google Text-to-Speech (Free, offline)
    
    Install: pip install gtts
    """
    try:
        from gtts import gTTS
        
        os.makedirs(output_dir, exist_ok=True)
        
        scene = NARRATION_SCRIPTS[scene_name]
        
        print(f"\nGenerating audio for {scene_name}...")
        
        for i, segment in enumerate(scene['script']):
            text = segment['narration']
            time_code = segment['time']
            
            print(f"  Segment {i+1}/{len(scene['script'])}: [{time_code}]")
            
            # Generate audio
            tts = gTTS(text=text, lang='en', slow=False)
            
            # Save to file
            filename = f"{output_dir}/{scene_name}_segment_{i+1:02d}.mp3"
            tts.save(filename)
            
            print(f"    ✓ Saved: {filename}")
        
        print(f"\n✓ Completed {scene_name}")
        
    except ImportError:
        print("Please install: pip install gtts")
    except Exception as e:
        print(f"Error: {e}")


def generate_tts_pyttsx3(scene_name, output_dir="audio"):
    """
    Generate TTS using pyttsx3 (Offline, uses system voices)
    
    Install: pip install pyttsx3
    """
    try:
        import pyttsx3
        
        os.makedirs(output_dir, exist_ok=True)
        
        engine = pyttsx3.init()
        
        # Adjust voice properties
        engine.setProperty('rate', 150)  # Speed
        engine.setProperty('volume', 0.9)  # Volume 0-1
        
        # List available voices
        voices = engine.getProperty('voices')
        # engine.setProperty('voice', voices[0].id)  # Change voice
        
        scene = NARRATION_SCRIPTS[scene_name]
        
        print(f"\nGenerating audio for {scene_name}...")
        
        for i, segment in enumerate(scene['script']):
            text = segment['narration']
            time_code = segment['time']
            
            print(f"  Segment {i+1}/{len(scene['script'])}: [{time_code}]")
            
            filename = f"{output_dir}/{scene_name}_segment_{i+1:02d}.mp3"
            engine.save_to_file(text, filename)
        
        engine.runAndWait()
        print(f"\n✓ Completed {scene_name}")
        
    except ImportError:
        print("Please install: pip install pyttsx3")
    except Exception as e:
        print(f"Error: {e}")


def generate_all_scenes_tts(method='gtts'):
    """Generate TTS for all scenes"""
    methods = {
        'elevenlabs': generate_tts_elevenlabs,
        'gtts': generate_tts_gtts,
        'pyttsx3': generate_tts_pyttsx3
    }
    
    if method not in methods:
        print(f"Unknown method: {method}")
        print(f"Available: {list(methods.keys())}")
        return
    
    tts_func = methods[method]
    
    print(f"\n{'='*60}")
    print(f"Generating TTS using: {method}")
    print(f"{'='*60}")
    
    for scene_name in NARRATION_SCRIPTS.keys():
        tts_func(scene_name)
        print()
    
    print(f"\n{'='*60}")
    print("✓ All audio generated!")
    print(f"{'='*60}")
    print("\nNext steps:")
    print("1. Review audio files in 'audio/' directory")
    print("2. Sync with video using video editor")
    print("3. Or use Manim voiceover plugin (see narration_guide.md)")


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description='Generate TTS narration for RoPE video')
    parser.add_argument('--scene', type=str, help='Scene name (or "all")', default='all')
    parser.add_argument('--method', type=str, choices=['gtts', 'pyttsx3', 'elevenlabs'], 
                       default='gtts', help='TTS method to use')
    
    args = parser.parse_args()
    
    if args.scene == 'all':
        generate_all_scenes_tts(method=args.method)
    else:
        methods = {
            'elevenlabs': generate_tts_elevenlabs,
            'gtts': generate_tts_gtts,
            'pyttsx3': generate_tts_pyttsx3
        }
        methods[args.method](args.scene)