# Complete Narration Guide for RoPE Video

## What You Have

I've created a complete narration system with three components:

1. **narration_generator.py** - Timed scripts for all 10 scenes
2. **tts_generator.py** - Auto-generate audio from scripts
3. **This guide** - Multiple approaches for adding narration

## Quick Start (3 Methods)

### Method 1: Text-to-Speech (Easiest) ⭐ RECOMMENDED

Generate audio automatically from the scripts:

```bash
# Step 1: Generate the script file
python narration_generator.py

# Step 2: Generate audio (choose one method)

# Option A: Google TTS (free, decent quality)
pip install gtts
python tts_generator.py --method gtts --scene all

# Option B: ElevenLabs (best quality, requires API key)
pip install elevenlabs
python tts_generator.py --method elevenlabs --scene all

# Option C: System voices (offline, fast)
pip install pyttsx3
python tts_generator.py --method pyttsx3 --scene all
```

This creates audio files in `audio/` directory:
```
audio/
  IntroScene_segment_01.mp3
  IntroScene_segment_02.mp3
  ...
  TheMagicScene_segment_01.mp3
  ...
```

### Method 2: Manual Recording (Best Quality)

Record your own voice for professional results:

```bash
# Step 1: Export the script
python narration_generator.py
# This creates: rope_narration_script.txt

# Step 2: Record using any tool:
# - Audacity (free): https://www.audacityteam.org/
# - GarageBand (Mac)
# - QuickTime Player (Mac)
# - Windows Voice Recorder

# Step 3: Follow the timing in the script
# Each segment shows: [0:00-0:08]
# Record each segment separately or all at once
```

### Method 3: Manim Voiceover Plugin (Integrated)

Add narration directly into Manim animations:

```bash
# Install
pip install "manim-voiceover[azure,gtts]"

# See example below for code integration
```

---

## Detailed Instructions

### Method 1 Details: Text-to-Speech

#### Option A: Google TTS (gTTS) - FREE

**Pros:**
- Free and unlimited
- No API key needed
- Good quality
- Multiple languages

**Cons:**
- Robotic voice
- Online only
- Limited voice options

**Usage:**
```bash
pip install gtts

# Generate all scenes
python tts_generator.py --method gtts --scene all

# Generate single scene
python tts_generator.py --method gtts --scene IntroScene
```

#### Option B: ElevenLabs - BEST QUALITY

**Pros:**
- Very natural sounding
- Multiple voices
- Best quality

**Cons:**
- Requires API key
- Free tier: 10,000 characters/month
- Paid: $5/month for 30,000 chars

**Setup:**
```bash
pip install elevenlabs

# Get free API key from: https://elevenlabs.io/
# Edit tts_generator.py and add your key:
# set_api_key("your-key-here")

python tts_generator.py --method elevenlabs --scene all
```

**Available voices:** Adam, Antoni, Arnold, Bella, Domi, Elli, Josh, Rachel, Sam

#### Option C: pyttsx3 - OFFLINE

**Pros:**
- Completely offline
- Fast generation
- No costs

**Cons:**
- Uses system voices (variable quality)
- Less natural

**Usage:**
```bash
pip install pyttsx3

python tts_generator.py --method pyttsx3 --scene all
```

---

### Method 2 Details: Manual Recording

#### Recording Script

The generated `rope_narration_script.txt` contains all narration with timing:

```
[0:00-0:08]
Welcome! Today we're diving into RoPE - Rotary Position Embedding...

[0:08-0:15]
Let's start with the problem...
```

#### Recording Tools

**Audacity (Free, Cross-platform):**
```bash
# Install from: https://www.audacityteam.org/

# Tips:
1. Record in a quiet room
2. Use good mic (built-in is OK)
3. Record each segment separately
4. Export as MP3 or WAV
5. Normalize audio levels
```

**Mac - GarageBand:**
- Built-in, professional quality
- Easy to use
- Good for voice recording

**Windows - Voice Recorder:**
- Built-in
- Simple and quick
- Export as M4A

#### Recording Tips

1. **Read naturally** - Don't sound robotic
2. **Pace yourself** - Follow the timing in script
3. **Pause between segments** - Makes editing easier
4. **Record in chunks** - Do 2-3 segments at a time
5. **Leave room for errors** - Clip can be edited

---

### Method 3 Details: Manim Voiceover Plugin

This integrates narration directly into your Manim code.

#### Installation

```bash
pip install "manim-voiceover[azure,gtts]"
```

#### Example: Modified IntroScene with Voiceover

```python
from manim import *
from manim_voiceover import VoiceoverScene
from manim_voiceover.services.gtts import GTTSService

class IntroSceneWithVoice(VoiceoverScene):
    def construct(self):
        # Set TTS service
        self.set_speech_service(GTTSService())
        
        title = Text("RoPE: Rotary Position Embedding", font_size=52, color=BLUE)
        
        # Add voiceover
        with self.voiceover(text="Welcome! Today we're diving into RoPE.") as tracker:
            self.play(Write(title), run_time=tracker.duration)
        
        self.wait(1)
        
        # Next narration
        with self.voiceover(text="Let's start with the problem."):
            self.play(FadeOut(title))
```

**Advantages:**
- Audio synced automatically
- Timing matches animation
- All in one file

**Disadvantages:**
- Adds complexity
- Slower rendering
- Harder to edit narration

---

## Workflow Recommendations

### For Quick Preview (1 hour)
1. Use Google TTS: `python tts_generator.py --method gtts --scene all`
2. Manually sync audio with video in DaVinci Resolve
3. Export preview

### For Final Production (4-6 hours)
1. Export script: `python narration_generator.py`
2. Record your own voice using Audacity
3. Edit and clean audio
4. Sync with video in video editor
5. Add background music (optional)
6. Final export

### For Automated Pipeline (2-3 hours)
1. Install ElevenLabs: `pip install elevenlabs`
2. Get API key (free tier)
3. Generate: `python tts_generator.py --method elevenlabs --scene all`
4. Sync in video editor
5. Export

---

## Syncing Audio with Video

### Using DaVinci Resolve (Free)

1. **Import:**
   - Video: `media/videos/rope_video/480p15/IntroScene.mp4`
   - Audio: `audio/IntroScene_segment_01.mp3`

2. **Timeline:**
   - Drag video to timeline
   - Drag audio segments below
   - Align using timecodes

3. **Edit:**
   - Cut, trim, fade
   - Adjust timing
   - Add music

4. **Export:**
   - File > Quick Export
   - MP4, H.264
   - YouTube 1080p preset

### Using iMovie (Mac)

1. Create new project
2. Import video and audio
3. Arrange in timeline
4. Use the timing guides from script
5. Export

### Using FFmpeg (Command Line)

```bash
# Concatenate audio segments
ffmpeg -f concat -i audio_list.txt -c copy full_audio.mp3

# Merge with video
ffmpeg -i IntroScene.mp4 -i full_audio.mp3 -c:v copy -c:a aac output.mp4
```

---

## Timing Adjustments

If your narration doesn't match the animation timing:

### In the Python Code

Edit `wait()` durations in rope_video.py:

```python
# Before
self.wait(2)

# After (longer pause for narration)
self.wait(4)
```

### In Video Editor

- Speed up/slow down video: 90-110% is natural
- Trim pauses between animations
- Add black frames for extra time

---

## Voice Recording Best Practices

### Equipment
- **Minimum:** Built-in laptop mic
- **Better:** USB microphone ($30-50)
- **Best:** XLR mic with interface ($100+)

### Environment
- Quiet room
- Soft surfaces (carpet, curtains reduce echo)
- Close to mic (6-12 inches)

### Technique
1. Warm up voice (read script once)
2. Stand or sit up straight
3. Smile (sounds better!)
4. Speak clearly but naturally
5. Don't rush
6. Take breaks every 10-15 minutes

### Post-Processing in Audacity
1. **Noise Reduction:**
   - Effect > Noise Reduction
   - Record 1 sec of silence first
   - Use as noise profile

2. **Normalize:**
   - Effect > Normalize
   - Set to -3 dB

3. **Compress:**
   - Effect > Compressor
   - Threshold: -12 dB
   - Makes volume consistent

4. **EQ (optional):**
   - Effect > Equalization
   - Boost 100-200 Hz for warmth
   - Cut below 80 Hz (rumble)

---

## Complete Example Workflow

### Full Production Pipeline

```bash
# Day 1: Generate and Review
# -------------------------

# 1. Generate narration scripts
python narration_generator.py

# 2. Review script, make edits if needed
# Edit rope_narration_script.txt

# 3. Generate preview TTS
python tts_generator.py --method gtts --scene IntroScene

# 4. Test sync with one scene
# Use video editor to check timing


# Day 2: Record Audio
# -------------------

# 1. Set up recording space
# 2. Open Audacity
# 3. Record all scenes following script
# 4. Export each scene as separate files


# Day 3: Edit and Sync
# --------------------

# 1. Open DaVinci Resolve
# 2. Import all video scenes
# 3. Import all audio files
# 4. Arrange on timeline
# 5. Sync using timing codes
# 6. Add transitions
# 7. Add background music (optional)


# Day 4: Final Polish
# -------------------

# 1. Color correction
# 2. Audio mixing and levels
# 3. Add intro/outro cards
# 4. Final export
# 5. Upload to YouTube!
```

---

## Troubleshooting

### Audio is too fast/slow
- Adjust `wait()` in Python code
- Or speed up/slow down video 5-10%

### Audio quality is poor
- Record in quieter environment
- Use noise reduction in Audacity
- Get better microphone

### TTS sounds robotic
- Try ElevenLabs (best quality)
- Or record manually
- Or try different TTS voice

### Can't install packages
```bash
# Create virtual environment
python -m venv narration_env
source narration_env/bin/activate  # Mac/Linux
# or
narration_env\Scripts\activate  # Windows

# Then install
pip install gtts pyttsx3
```

---

## Time Estimates

| Task | Time Required |
|------|--------------|
| Generate scripts | 5 min |
| Generate TTS (all scenes) | 10 min |
| Manual recording | 2-3 hours |
| Audio editing | 1-2 hours |
| Video syncing | 2-3 hours |
| Final polish | 1 hour |
| **Total (TTS)** | **4-6 hours** |
| **Total (Manual)** | **8-10 hours** |

---

## Resources

### Free Tools
- **Audacity:** https://www.audacityteam.org/
- **DaVinci Resolve:** https://www.blackmagicdesign.com/products/davinciresolve
- **OBS Studio:** https://obsproject.com/

### TTS Services
- **Google TTS:** Free, decent
- **ElevenLabs:** $5/month, excellent
- **Azure TTS:** Pay per use, professional

### Learning
- **Audacity Tutorial:** YouTube "Audacity voice over tutorial"
- **DaVinci Resolve:** YouTube "DaVinci Resolve beginner tutorial"

---

## Next Steps

1. **Choose your method** (TTS recommended for first try)
2. **Generate audio** using tts_generator.py
3. **Render your videos** using Manim
4. **Sync in video editor**
5. **Share your creation!**

Good luck! 🎙️🎬
