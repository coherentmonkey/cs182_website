"""
Condensed RoPE Video - All Concepts in One Scene (NO LATEX VERSION)
Perfect for a 10-minute comprehensive overview
All math formulas replaced with Text - no LaTeX required!
"""

from manim import *
import numpy as np


class RoPECompleteOverview(Scene):
    """
    A single, comprehensive scene covering all RoPE concepts
    Duration: ~10-12 minutes
    
    NO LATEX REQUIRED - All formulas use Text instead of MathTex
    """
    
    def construct(self):
        # ===== INTRO =====
        self.intro()
        
        # ===== CORE CONCEPT =====
        self.show_rotation_concept()
        
        # ===== THE MAGIC =====
        self.show_relative_position_property()
        
        # ===== CHUNKING =====
        self.show_chunking()
        
        # ===== FREQUENCIES =====
        self.show_frequency_spectrum()
        
        # ===== SUMMARY =====
        self.show_summary()
    
    def intro(self):
        """Introduction - The Problem"""
        title = Text("RoPE: Rotary Position Embedding", font_size=52, color=BLUE)
        subtitle = Text("Position Encoding for Transformers", font_size=32, color=GRAY)
        subtitle.next_to(title, DOWN)
        
        self.play(Write(title), run_time=1.5)
        self.play(FadeIn(subtitle), run_time=0.8)
        self.wait(1.5)
        self.play(FadeOut(title), FadeOut(subtitle))
        
        # The problem
        problem = VGroup(
            Text("The Problem:", font_size=40, color=RED).to_edge(UP),
            Text("Standard attention has NO position information", font_size=32),
            Text("Attention = <q, k> / sqrt(d)", font_size=36, color=GRAY)
        ).arrange(DOWN, buff=0.6)
        
        self.play(Write(problem), run_time=2)
        self.wait(2)
        
        # The solution
        solution = Text("RoPE's Solution: ROTATE!", font_size=44, color=GREEN)
        self.play(
            Transform(problem, solution.move_to(ORIGIN)),
            run_time=1
        )
        self.wait(1.5)
        self.play(FadeOut(problem))
    
    def show_rotation_concept(self):
        """Show 2D rotation concept"""
        title = Text("Core Concept: Rotation", font_size=40, color=BLUE).to_edge(UP)
        self.play(Write(title))
        
        # Create axes
        axes = Axes(
            x_range=[-2, 2, 1],
            y_range=[-2, 2, 1],
            x_length=5,
            y_length=5,
            tips=False
        ).shift(LEFT * 3.5)
        
        self.play(Create(axes), run_time=0.8)
        
        # Show rotation formula as text
        formula = VGroup(
            Text("Rotation Matrix:", font_size=28, color=YELLOW),
            Text("R_t = [ cos(ωt)  -sin(ωt) ]", font_size=24),
            Text("      [ sin(ωt)   cos(ωt) ]", font_size=24)
        ).arrange(DOWN, buff=0.2, aligned_edge=LEFT).to_edge(RIGHT).shift(UP * 1.5)
        
        self.play(Write(formula))
        
        # Animate vector rotating through positions
        vector = Arrow(axes.c2p(0, 0), axes.c2p(1.5, 0), buff=0, color=GREEN, stroke_width=6)
        position_label = Text("Position: 0", font_size=24, color=GREEN).next_to(vector, UP)
        
        self.play(Create(vector), Write(position_label))
        
        # Rotate through several positions
        for pos in [1, 2, 3]:
            angle = pos
            new_end = axes.c2p(1.5 * np.cos(angle), 1.5 * np.sin(angle))
            new_vector = Arrow(axes.c2p(0, 0), new_end, buff=0, 
                             color=interpolate_color(GREEN, RED, pos/3), stroke_width=6)
            new_label = Text(f"Position: {pos}", font_size=24, 
                           color=interpolate_color(GREEN, RED, pos/3)).next_to(new_vector, UP)
            
            self.play(
                Transform(vector, new_vector),
                Transform(position_label, new_label),
                run_time=0.8
            )
            self.wait(0.5)
        
        self.wait(1)
        self.play(FadeOut(axes), FadeOut(vector), FadeOut(position_label), 
                 FadeOut(formula), FadeOut(title))
    
    def show_relative_position_property(self):
        """Show the key property: relative position encoding"""
        title = Text("The Magic: Relative Position", font_size=40, color=TEAL).to_edge(UP)
        self.play(Write(title))
        
        # Show the derivation quickly
        steps = VGroup(
            Text("<R_t q, R_i k>", font_size=32),
            Text("= q^T · R_t^T · R_i · k", font_size=32),
            Text("= q^T · R_(t-i) · k", font_size=32, color=GREEN)
        ).arrange(DOWN, buff=0.5)
        
        for step in steps:
            self.play(Write(step), run_time=0.8)
            self.wait(0.5)
        
        # Highlight the key insight
        box = SurroundingRectangle(steps[2], color=GREEN, buff=0.2, stroke_width=4)
        insight = Text("Only depends on (t-i)!", font_size=32, color=GREEN).next_to(box, DOWN, buff=0.5)
        
        self.play(Create(box))
        self.play(Write(insight))
        self.wait(2)
        
        self.play(FadeOut(VGroup(title, steps, box, insight)))
    
    def show_chunking(self):
        """Show how RoPE handles high dimensions"""
        title = Text("High Dimensions: Chunking", font_size=40, color=BLUE).to_edge(UP)
        self.play(Write(title))
        
        # Show a high-D vector
        vector = VGroup(
            *[Rectangle(height=0.5, width=0.4, color=BLUE, fill_opacity=0.5) 
              for _ in range(8)]
        ).arrange(RIGHT, buff=0.08)
        
        vector_label = Text("[x₁, x₂, ..., xₙ]", font_size=28).next_to(vector, DOWN, buff=0.5)
        
        self.play(Create(vector), Write(vector_label))
        self.wait(1)
        
        # Show chunking into pairs
        pairs = VGroup()
        colors = [RED, GREEN, BLUE, YELLOW]
        
        for i in range(4):
            pair = VGroup(
                Rectangle(height=0.5, width=0.4, color=colors[i], fill_opacity=0.5),
                Rectangle(height=0.5, width=0.4, color=colors[i], fill_opacity=0.5)
            ).arrange(RIGHT, buff=0.05)
            pairs.add(pair)
        
        pairs.arrange(RIGHT, buff=0.4).move_to(vector)
        
        self.play(Transform(vector, pairs), FadeOut(vector_label))
        self.wait(1)
        
        # Show different frequencies
        freq_labels = VGroup()
        for i, color in enumerate(colors):
            label = Text(f"ω_{i}", font_size=24, color=color).next_to(pairs[i], DOWN, buff=0.3)
            freq_labels.add(label)
        
        self.play(Write(freq_labels), run_time=1.5)
        
        key_point = Text(
            "Each pair rotates at a different frequency!",
            font_size=28,
            color=YELLOW
        ).to_edge(DOWN)
        
        self.play(Write(key_point))
        self.wait(2)
        
        self.play(FadeOut(VGroup(title, vector, freq_labels, key_point)))
    
    def show_frequency_spectrum(self):
        """Show the frequency spectrum and clock analogy"""
        title = Text("Multiple Frequencies", font_size=40, color=TEAL).to_edge(UP)
        self.play(Write(title))
        
        # Clock analogy
        subtitle = Text("Like a clock with multiple hands:", font_size=28).next_to(title, DOWN, buff=0.5)
        self.play(Write(subtitle))
        
        # Create small clocks with different speeds
        clocks = VGroup()
        labels = ["Fast (local)", "Medium", "Slow (global)"]
        colors = [RED, YELLOW, BLUE]
        speeds = [1, 0.3, 0.1]
        
        for i in range(3):
            # Clock circle
            circle = Circle(radius=0.8, color=colors[i], stroke_width=2)
            
            # Clock hand
            hand = Arrow(
                circle.get_center(),
                circle.get_center() + UP * 0.6,
                buff=0,
                color=colors[i],
                stroke_width=4
            )
            
            # Label
            label = Text(labels[i], font_size=20, color=colors[i]).next_to(circle, DOWN, buff=0.3)
            
            clock = VGroup(circle, hand, label)
            clocks.add(clock)
        
        clocks.arrange(RIGHT, buff=1.5).shift(DOWN * 0.5)
        
        self.play(Create(clocks), run_time=1.5)
        
        # Animate hands rotating at different speeds
        def update_clock_hands(clocks, dt):
            for i, (speed, color) in enumerate(zip(speeds, colors)):
                circle, hand, label = clocks[i]
                current_end = hand.get_end()
                center = circle.get_center()
                
                # Calculate current angle
                diff = current_end - center
                current_angle = np.angle(complex(diff[0], diff[1]))
                
                # New angle
                new_angle = current_angle + speed * dt * 2
                new_end = center + np.array([0.6 * np.cos(new_angle), 0.6 * np.sin(new_angle), 0])
                
                # Update hand
                new_hand = Arrow(center, new_end, buff=0, color=color, stroke_width=4)
                hand.become(new_hand)
        
        clocks.add_updater(update_clock_hands)
        self.wait(6)
        clocks.clear_updaters()
        
        # Explanation
        explanation = VGroup(
            Text("High frequency: captures local patterns", font_size=24, color=RED),
            Text("Low frequency: captures global structure", font_size=24, color=BLUE)
        ).arrange(DOWN, buff=0.3, aligned_edge=LEFT).to_edge(DOWN)
        
        self.play(Write(explanation), run_time=1.5)
        self.wait(2)
        
        self.play(FadeOut(VGroup(title, subtitle, clocks, explanation)))
    
    def show_summary(self):
        """Final summary"""
        title = Text("RoPE Summary", font_size=48, color=BLUE).to_edge(UP)
        self.play(Write(title))
        
        # Key points
        points = VGroup(
            VGroup(
                Text("1. Chunking", font_size=32, color=TEAL),
                Text("Split dimensions into pairs", font_size=24)
            ).arrange(DOWN, buff=0.2, aligned_edge=LEFT),
            
            VGroup(
                Text("2. Rotation", font_size=32, color=TEAL),
                Text("Rotate each pair by position", font_size=24)
            ).arrange(DOWN, buff=0.2, aligned_edge=LEFT),
            
            VGroup(
                Text("3. Multiple Frequencies", font_size=32, color=TEAL),
                Text("Different scales for different pairs", font_size=24)
            ).arrange(DOWN, buff=0.2, aligned_edge=LEFT)
        ).arrange(DOWN, buff=0.6, aligned_edge=LEFT).shift(DOWN * 0.5)
        
        for point in points:
            self.play(Write(point), run_time=1)
            self.wait(0.5)
        
        self.wait(1)
        
        # Final message
        self.play(FadeOut(points))
        
        final = VGroup(
            Text("R_t^T · R_i = R_(t-i)", font_size=42, color=GREEN),
            Text("Elegant, efficient, extrapolatable!", font_size=36, color=YELLOW)
        ).arrange(DOWN, buff=0.8)
        
        self.play(Write(final), run_time=1.5)
        self.wait(3)
        
        # End
        self.play(FadeOut(VGroup(title, final)))
        
        end_text = Text("RoPE: Rotary Position Embedding", font_size=48, color=BLUE)
        self.play(Write(end_text))
        self.wait(2)
        self.play(FadeOut(end_text))


# Alternative: Even shorter version (5 minutes)
class RoPEQuickOverview(Scene):
    """Ultra-condensed 5-minute version - NO LATEX"""
    
    def construct(self):
        # Title
        title = VGroup(
            Text("RoPE in 5 Minutes", font_size=52, color=BLUE),
            Text("Rotary Position Embedding", font_size=32, color=GRAY)
        ).arrange(DOWN, buff=0.3)
        
        self.play(Write(title))
        self.wait(1.5)
        self.play(FadeOut(title))
        
        # Problem
        problem = VGroup(
            Text("Problem: Attention needs position info", font_size=32, color=RED),
            Text("<q, k> has no position!", font_size=28, color=GRAY)
        ).arrange(DOWN, buff=0.5)
        
        self.play(Write(problem))
        self.wait(1.5)
        
        # Solution - Use FadeOut/FadeIn instead of Transform
        solution = VGroup(
            Text("Solution: Rotate vectors by position!", font_size=32, color=GREEN),
            Text("<R_t q, R_i k>", font_size=32)
        ).arrange(DOWN, buff=0.5)
        
        self.play(FadeOut(problem), FadeIn(solution))
        self.wait(1.5)
        
        # Key property
        key = VGroup(
            Text("R_t^T · R_i = R_(t-i)", font_size=40, color=YELLOW),
            Text("→ Relative position encoding!", font_size=28, color=YELLOW)
        ).arrange(DOWN, buff=0.5)
        
        self.play(FadeOut(solution), FadeIn(key))
        self.wait(2)
        
        # High dimensions
        high_d = VGroup(
            Text("High dimensions:", font_size=32, color=TEAL),
            Text("Split into pairs, rotate each at different frequency", font_size=24)
        ).arrange(DOWN, buff=0.5)
        
        self.play(FadeOut(key), FadeIn(high_d))
        self.wait(2)
        
        # Benefits
        benefits = VGroup(
            Text("✓ Relative position", font_size=28, color=GREEN),
            Text("✓ No learned parameters", font_size=28, color=GREEN),
            Text("✓ Extrapolates to longer sequences", font_size=28, color=GREEN),
            Text("✓ Efficient O(n) complexity", font_size=28, color=GREEN)
        ).arrange(DOWN, buff=0.3, aligned_edge=LEFT)
        
        self.play(FadeOut(high_d), FadeIn(benefits))
        self.wait(3)
        
        # End
        self.play(FadeOut(benefits))
        end = Text("RoPE: Simple, Elegant, Effective", font_size=42, color=BLUE)
        self.play(Write(end))
        self.wait(2)


if __name__ == "__main__":
    # Render with:
    # manim -pql rope_condensed.py RoPECompleteOverview  (10-12 min version)
    # manim -pql rope_condensed.py RoPEQuickOverview     (5 min version)
    pass