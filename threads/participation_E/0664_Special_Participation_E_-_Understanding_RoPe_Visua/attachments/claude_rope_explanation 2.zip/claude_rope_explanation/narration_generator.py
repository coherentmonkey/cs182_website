"""
Narration Script Generator for RoPE Video
Generates time-coded narration scripts for each scene in rope_video.py
"""

# Complete narration scripts with timing for each scene

NARRATION_SCRIPTS = {
    "IntroScene": {
        "duration": "2-3 minutes",
        "script": [
            {
                "time": "0:00-0:08",
                "narration": "Welcome! Today we're diving into RoPE - Rotary Position Embedding - one of the most elegant solutions in modern transformer architecture."
            },
            {
                "time": "0:08-0:15",
                "narration": "Let's start with the problem. Here we have a sequence of tokens in a transformer."
            },
            {
                "time": "0:15-0:25",
                "narration": "Standard attention computes how much each token should attend to every other token using a simple dot product. But there's a critical issue."
            },
            {
                "time": "0:25-0:35",
                "narration": "This attention score has absolutely no position information! It can't tell the difference between a word at position 5 and the same word at position 105."
            },
            {
                "time": "0:35-0:45",
                "narration": "What we really want is for attention to depend on relative positions. When a token at position 5 attends to position 3, that should feel the same as position 105 attending to position 103."
            },
            {
                "time": "0:45-0:55",
                "narration": "Both relationships have a relative distance of 2, so they should be treated similarly. This property is called relative position encoding."
            },
            {
                "time": "0:55-1:05",
                "narration": "So how does RoPE solve this? The answer is beautifully simple: rotation! Instead of adding position information, RoPE rotates the embedding vectors based on their position."
            },
            {
                "time": "1:05-1:15",
                "narration": "Let's see how this works."
            }
        ]
    },
    
    "TwoDRotationScene": {
        "duration": "2-3 minutes",
        "script": [
            {
                "time": "0:00-0:10",
                "narration": "To understand RoPE, we'll start simple - with just 2 dimensions. Here's our coordinate system."
            },
            {
                "time": "0:10-0:20",
                "narration": "The key idea is to use a rotation matrix. At position t, we rotate vectors by an angle that depends on position times a frequency omega."
            },
            {
                "time": "0:20-0:30",
                "narration": "This is just the standard 2D rotation matrix from linear algebra - cosine and sine of the rotation angle."
            },
            {
                "time": "0:30-0:40",
                "narration": "Watch what happens to our vector as we move through different positions. At position 0, there's no rotation."
            },
            {
                "time": "0:40-0:50",
                "narration": "At position 1, the vector rotates by angle omega. Position 2? Rotate by 2 omega."
            },
            {
                "time": "0:50-1:00",
                "narration": "Position 3 means rotating by 3 omega. You can see the pattern - each position gets its own unique rotation."
            },
            {
                "time": "1:00-1:15",
                "narration": "Now here's the beautiful visualization: if we look at many positions at once, we see this spiral pattern. Each position has a distinct orientation in the space."
            },
            {
                "time": "1:15-1:25",
                "narration": "This is elegant, but you might be wondering: how does rotation give us relative position? That's where the magic happens."
            }
        ]
    },
    
    "TheMagicScene": {
        "duration": "3-4 minutes",
        "script": [
            {
                "time": "0:00-0:08",
                "narration": "This is the heart of RoPE - the mathematical property that makes everything work."
            },
            {
                "time": "0:08-0:18",
                "narration": "Remember, we want to compute attention between a query at position t and a key at position i. With RoPE, we first rotate both vectors."
            },
            {
                "time": "0:18-0:28",
                "narration": "The attention score becomes the dot product of the rotated query R_t q and the rotated key R_i k."
            },
            {
                "time": "0:28-0:38",
                "narration": "Now let's use some linear algebra. We can rewrite this dot product as q transpose, times R_t transpose, times R_i, times k."
            },
            {
                "time": "0:38-0:48",
                "narration": "Here's the key insight: rotation matrices have a special property. R_t transpose times R_i equals R of t minus i."
            },
            {
                "time": "0:48-0:58",
                "narration": "This means the attention score only depends on the relative distance t minus i, not on t and i separately!"
            },
            {
                "time": "0:58-1:08",
                "narration": "Let's prove why this works. The transpose of a rotation matrix at position t is the rotation at negative t."
            },
            {
                "time": "1:08-1:25",
                "narration": "When we multiply R_t transpose by R_i, using the angle addition formula from trigonometry, cosine of t times cosine of i plus sine of t times sine of i becomes cosine of t minus i."
            },
            {
                "time": "1:25-1:35",
                "narration": "Similarly for the sine terms. The result is exactly the rotation matrix for angle t minus i."
            },
            {
                "time": "1:35-1:50",
                "narration": "This is profound: by rotating vectors based on absolute position, the attention mechanism automatically learns about relative positions. It's mathematical elegance at its finest."
            }
        ]
    },
    
    "ConcreteExampleScene": {
        "duration": "2-3 minutes",
        "script": [
            {
                "time": "0:00-0:10",
                "narration": "Let's make this concrete with actual numbers. We'll use omega equals 1 for simplicity."
            },
            {
                "time": "0:10-0:20",
                "narration": "Our query is at position 3 - we'll use the vector [1, 0]. Our key is at position 1 - we'll use [0, 1]."
            },
            {
                "time": "0:20-0:35",
                "narration": "First, we build the rotation matrices. R_3 means rotating by 3 radians - that's about 172 degrees. Plugging into our cosine and sine, we get approximately negative 0.99 and 0.14."
            },
            {
                "time": "0:35-0:45",
                "narration": "Similarly, R_1 rotates by 1 radian - about 57 degrees - giving us 0.54 and 0.84."
            },
            {
                "time": "0:45-0:55",
                "narration": "Now we rotate our vectors. The query [1, 0] becomes [-0.99, 0.14]. The key [0, 1] becomes [-0.84, 0.54]."
            },
            {
                "time": "0:55-1:08",
                "narration": "Taking the dot product: negative 0.99 times negative 0.84 plus 0.14 times 0.54 gives us approximately 0.91."
            },
            {
                "time": "1:08-1:20",
                "narration": "Now let's verify the relative position property. The relative distance is 3 minus 1 equals 2. If we compute R_2 directly and use our formula, we get... 0.91!"
            },
            {
                "time": "1:20-1:30",
                "narration": "The same answer! This confirms that the attention score truly depends only on the relative distance."
            }
        ]
    },
    
    "ChunkingScene": {
        "duration": "2-3 minutes",
        "script": [
            {
                "time": "0:00-0:10",
                "narration": "So far we've looked at 2D vectors. But real transformer embeddings are huge - 512, 1024, even larger dimensions."
            },
            {
                "time": "0:10-0:20",
                "narration": "RoPE handles this with a clever strategy called chunking. Here's a high-dimensional vector with hundreds of dimensions."
            },
            {
                "time": "0:20-0:30",
                "narration": "Instead of rotating the entire vector at once, we split it into pairs of dimensions."
            },
            {
                "time": "0:30-0:45",
                "narration": "Each pair gets its own independent 2D rotation. But here's the crucial part: each pair rotates at a different frequency!"
            },
            {
                "time": "0:45-0:55",
                "narration": "The first pair uses frequency omega_0, the second uses omega_1, and so on. These frequencies are carefully chosen."
            },
            {
                "time": "0:55-1:10",
                "narration": "Why different frequencies? Think about it: we want to capture both local patterns - like adjacent words - and global patterns - like distant dependencies across a sentence."
            },
            {
                "time": "1:10-1:25",
                "narration": "High frequencies rotate quickly, making them sensitive to small position changes. They're perfect for local structure. Low frequencies rotate slowly, maintaining information over long distances."
            },
            {
                "time": "1:25-1:35",
                "narration": "Together, this multi-frequency approach lets RoPE distinguish positions from 1 all the way to 10,000 and beyond!"
            }
        ]
    },
    
    "FrequencyScene": {
        "duration": "3-4 minutes",
        "script": [
            {
                "time": "0:00-0:10",
                "narration": "Let's visualize these multiple frequencies with a clock analogy."
            },
            {
                "time": "0:10-0:20",
                "narration": "Imagine a clock with multiple hands, each moving at different speeds."
            },
            {
                "time": "0:20-0:35",
                "narration": "The fast hand represents high frequency - it completes rotations quickly. This is like a second hand, making a full circle in moments."
            },
            {
                "time": "0:35-0:50",
                "narration": "Watch how quickly it spins! High frequencies can distinguish between nearby positions - position 1 versus position 2 - because the rotation angle changes rapidly."
            },
            {
                "time": "0:50-1:05",
                "narration": "But there's a tradeoff: after rotating many times, the pattern repeats. High frequencies can't tell apart positions that are far apart."
            },
            {
                "time": "1:05-1:20",
                "narration": "Now the slow hand represents low frequency - like an hour hand, rotating very gradually. It can barely distinguish nearby positions."
            },
            {
                "time": "1:20-1:35",
                "narration": "But here's its strength: it maintains unique patterns over vast distances. Even at position 1000, it hasn't completed many rotations, so each position stays distinct."
            },
            {
                "time": "1:35-1:50",
                "narration": "Together, multiple frequencies at different scales give RoPE the best of both worlds: precise local structure and reliable long-range information."
            },
            {
                "time": "1:50-2:00",
                "narration": "The specific formula uses a base of 10,000, creating a geometric progression of frequencies from fastest to slowest."
            }
        ]
    },
    
    "AlgorithmScene": {
        "duration": "2-3 minutes",
        "script": [
            {
                "time": "0:00-0:10",
                "narration": "Now let's see how this all comes together in actual code."
            },
            {
                "time": "0:10-0:25",
                "narration": "The apply_rope function takes three inputs: a vector, its position in the sequence, and the total dimensionality."
            },
            {
                "time": "0:25-0:40",
                "narration": "We process dimensions in pairs using a simple for loop. For each pair, we first calculate its unique frequency using our formula: 1 over 10,000 to the power of j over d."
            },
            {
                "time": "0:40-0:55",
                "narration": "This creates that geometric progression we discussed - frequencies decrease exponentially as we move through dimension pairs."
            },
            {
                "time": "0:55-1:10",
                "narration": "Next, we grab the two values in this pair, v1 and v2. The rotation angle theta is simply frequency times position."
            },
            {
                "time": "1:10-1:25",
                "narration": "Finally, we apply the 2D rotation formula: the new first value is v1 times cosine minus v2 times sine. The new second value is v1 times sine plus v2 times cosine."
            },
            {
                "time": "1:25-1:40",
                "narration": "That's it! Just two lines of actual rotation math per pair. The beauty is in the simplicity - no learned parameters, no complex neural networks, just pure geometry."
            },
            {
                "time": "1:40-1:50",
                "narration": "In practice, implementations precompute the cosine and sine values for efficiency, but the core idea remains this straightforward."
            }
        ]
    },
    
    "PropertiesScene": {
        "duration": "2-3 minutes",
        "script": [
            {
                "time": "0:00-0:08",
                "narration": "Let's summarize the key properties that make RoPE so powerful."
            },
            {
                "time": "0:08-0:18",
                "narration": "First and foremost: relative position encoding. The attention score depends only on t minus i, the distance between tokens, not their absolute positions."
            },
            {
                "time": "0:18-0:30",
                "narration": "Second: translation invariance. If we shift both the query and key by the same amount, the attention pattern stays identical. This is crucial for generalization."
            },
            {
                "time": "0:30-0:45",
                "narration": "Third: natural distance decay. Attention naturally decreases for far-away tokens because large rotation angles mean less alignment between vectors."
            },
            {
                "time": "0:45-1:00",
                "narration": "Fourth: extreme efficiency. RoPE has zero learnable parameters - no extra weights to train. The computation is linear in sequence length, just some trigonometry per token."
            },
            {
                "time": "1:00-1:15",
                "narration": "And it can be entirely precomputed! Before training even starts, we can calculate all rotation matrices and reuse them."
            },
            {
                "time": "1:15-1:30",
                "narration": "Finally, perhaps most impressively: extrapolation. RoPE can handle sequences longer than anything seen during training. The rotation pattern simply continues naturally."
            },
            {
                "time": "1:30-1:45",
                "narration": "If you train on sequences of length 512, RoPE works fine at length 1024, 2048, or even longer. This is a huge practical advantage."
            }
        ]
    },
    
    "SummaryScene": {
        "duration": "2-3 minutes",
        "script": [
            {
                "time": "0:00-0:10",
                "narration": "Let's bring it all together. What is RoPE really doing?"
            },
            {
                "time": "0:10-0:25",
                "narration": "The core mathematical insight is elegant: rotation matrices have this special property where R_t transpose times R_i equals R of t minus i."
            },
            {
                "time": "0:25-0:35",
                "narration": "This single property makes relative position encoding fall out naturally from absolute rotations."
            },
            {
                "time": "0:35-0:50",
                "narration": "The implementation has three key components. First: chunking - split high-dimensional vectors into pairs of dimensions."
            },
            {
                "time": "0:50-1:05",
                "narration": "Second: multiple frequencies - each pair rotates at its own frequency, creating a multi-scale representation from local to global."
            },
            {
                "time": "1:05-1:20",
                "narration": "Third: the rotation math itself - just the standard 2D rotation matrix from linear algebra, applied independently to each pair."
            },
            {
                "time": "1:20-1:35",
                "narration": "The result is a method that's elegant, efficient, and extrapolatable. No learned parameters, perfect relative position encoding, and it scales beautifully."
            },
            {
                "time": "1:35-1:50",
                "narration": "RoPE has become the position encoding of choice in modern large language models, from GPT to LLaMA, precisely because of these properties."
            },
            {
                "time": "1:50-2:05",
                "narration": "Sometimes the best solutions in machine learning aren't complex neural architectures - they're clever applications of fundamental mathematics."
            },
            {
                "time": "2:05-2:15",
                "narration": "And that's RoPE: Rotary Position Embedding. Simple in concept, powerful in practice."
            }
        ]
    },
    
    "FourDimensionalExample": {
        "duration": "3-4 minutes",
        "script": [
            {
                "time": "0:00-0:10",
                "narration": "For our final deep dive, let's work through a complete 4-dimensional example with actual numbers."
            },
            {
                "time": "0:10-0:25",
                "narration": "We have a query at position 3: the vector [1, 0, 1, 0]. And a key at position 1: [0, 1, 1, 0]. Dimensionality d equals 4."
            },
            {
                "time": "0:25-0:40",
                "narration": "Step one: calculate the frequencies for our two pairs. Pair 0, dimensions 0 and 1, gets omega_0 which equals 1. Pair 1, dimensions 2 and 3, gets omega_1 equals 0.01."
            },
            {
                "time": "0:40-0:55",
                "narration": "Notice the huge difference: pair 0 rotates 100 times faster than pair 1. This is that multi-scale encoding we discussed."
            },
            {
                "time": "0:55-1:15",
                "narration": "Step two: build the rotation matrices. For position 3, pair 0 rotates by 1 times 3 equals 3 radians. That's cosine 3, sine 3. Pair 1 rotates by 0.01 times 3, just 0.03 radians - barely any rotation at all!"
            },
            {
                "time": "1:15-1:35",
                "narration": "Similarly for position 1: pair 0 rotates by 1 radian, pair 1 by 0.01 radians."
            },
            {
                "time": "1:35-1:55",
                "narration": "Step three: apply rotations. The query's first pair [1, 0] becomes [cosine 3, sine 3]. Its second pair [1, 0] becomes [cosine 0.03, sine 0.03]."
            },
            {
                "time": "1:55-2:15",
                "narration": "For the key, pair [0, 1] becomes [negative sine 1, cosine 1]. Pair [1, 0] becomes [cosine 0.01, sine 0.01]."
            },
            {
                "time": "2:15-2:35",
                "narration": "Step four: compute the attention score by taking the dot product. Using the angle subtraction formulas from trigonometry, this simplifies beautifully."
            },
            {
                "time": "2:35-2:55",
                "narration": "The first pair contributes sine of 3 minus 1, which is sine of 2. The second pair contributes cosine of 0.03 minus 0.01, which is cosine of 0.02."
            },
            {
                "time": "2:55-3:15",
                "narration": "See what happened? Both contributions depend on the relative position: 3 minus 1 equals 2. The fast-rotating pair encodes it at high frequency. The slow-rotating pair encodes it at low frequency."
            },
            {
                "time": "3:15-3:30",
                "narration": "This is how RoPE captures position information at multiple scales simultaneously, making it robust and powerful."
            }
        ]
    }
}


def print_full_script(scene_name=None):
    """Print narration script for a scene or all scenes"""
    if scene_name:
        if scene_name in NARRATION_SCRIPTS:
            scene = NARRATION_SCRIPTS[scene_name]
            print(f"\n{'='*80}")
            print(f"SCENE: {scene_name}")
            print(f"DURATION: {scene['duration']}")
            print(f"{'='*80}\n")
            
            for segment in scene['script']:
                print(f"[{segment['time']}]")
                print(f"{segment['narration']}\n")
        else:
            print(f"Scene '{scene_name}' not found!")
    else:
        # Print all scenes
        for scene_name in NARRATION_SCRIPTS:
            print_full_script(scene_name)


def export_script_to_file(filename="rope_narration_script.txt"):
    """Export complete narration script to a text file"""
    with open(filename, 'w', encoding='utf-8') as f:
        f.write("COMPLETE NARRATION SCRIPT FOR RoPE VIDEO\n")
        f.write("="*80 + "\n\n")
        
        total_duration = 0
        for scene_name, scene_data in NARRATION_SCRIPTS.items():
            f.write(f"\n{'='*80}\n")
            f.write(f"SCENE: {scene_name}\n")
            f.write(f"DURATION: {scene_data['duration']}\n")
            f.write(f"{'='*80}\n\n")
            
            for segment in scene_data['script']:
                f.write(f"[{segment['time']}]\n")
                f.write(f"{segment['narration']}\n\n")
        
        f.write("\n" + "="*80 + "\n")
        f.write("TOTAL VIDEO DURATION: Approximately 25-30 minutes\n")
        f.write("="*80 + "\n")
    
    print(f"✓ Script exported to {filename}")


def get_scene_timing_summary():
    """Print timing summary for all scenes"""
    print("\nSCENE TIMING SUMMARY")
    print("="*60)
    for scene_name, scene_data in NARRATION_SCRIPTS.items():
        num_segments = len(scene_data['script'])
        print(f"{scene_name:25s} {scene_data['duration']:15s} ({num_segments} segments)")
    print("="*60)
    print(f"Total estimated duration: 25-30 minutes")


if __name__ == "__main__":
    # Export full script
    export_script_to_file("/mnt/user-data/outputs/rope_narration_script.txt")
    
    # Print timing summary
    get_scene_timing_summary()
    
    # Example: print script for one scene
    print("\n\nEXAMPLE: IntroScene Script")
    print_full_script("IntroScene")
