# ---
# jupyter:
#   jupytext:
#     formats: ipynb,py:percent
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.18.1
#   kernelspec:
#     display_name: cs182hw0
#     language: python
#     name: python3
# ---

# %% [markdown] id="l0iVpOFAytxD"
# # Introduction
#
# In this notebook, we'll implement implement the forward pass of an SSM (State Space Model) using recursion and convolution based approaches. We'll also compare the two approaches in terms of speed and memory usage.
#
# You will need GPU for this notebook which can be enabled via changing the runtime.
#
# You can copy your solutions from the `q_coding_ssm_forward_cpu` notebook for the first part of the notebook.

# %% [markdown] id="OIngxUwVytxE"
# ## Imports

# %% id="-NnY8J6HytxE"
import time
import math
import matplotlib.pyplot as plt

import torch
import numpy as np
import torch.nn.functional as F

torch.set_default_device('mps')


# %% [markdown] id="JRxe5357ytxF"
# # SSM Update Rule
#
# We consider an RNN described by the update:
#
# $$
# h_{t+1} = W\,h_t + U\,x_t + b
# $$
#
# for $t = 0, 1, \ldots, T - 1$. The variables are:
#
# - $h_t \in R^H$, the hidden state at time $t$.
# - $x_t \in R^{N \times D}$, the input at time $t$.
# - $W \in R^{H \times H}$, the recurrent weight matrix.
# - $U \in R^{H \times D}$, the input projection matrix.
# - $b \in R^H$, the bias vector.
#
# $N$ is the batch size, $D$ is the input dimension, and $H$ is the hidden state dimension. We assume $h_0 = 0$, the all-zero vector of dimension $H$.

# %% [markdown] id="nUHIQVVUytxF"
# Below you will implement the forward pass for the SSM using recursion based approach. The `unrolled_ssm_forward` function will take weights $W$, $U$, $b$ and input $x$ and return the hidden states $h$ across different time steps.

# %% id="R8phBnwkytxF"
def unrolled_ssm_forward(W, U, b, x):
    """
    Unroll the linear RNN in time:
        h_{t+1} = W h_t + U x_t + b
    with initial h_0 = 0.

    Args:
      W: (H, H) weight matrix
      U: (H, D) input projection
      b: (H,)   bias
      x: (N, T, D) input sequence over T steps
    Returns:
      h_all: (N, T, H) hidden states for t=1..T
             (h_all[t] corresponds to h_{t+1} in the usual notation).
    """
    ##############################################################################
    #                   TODO: Implement the recurrent pass here                  #
    ##############################################################################
    # Extract dimensions from input
    N, T, D = x.shape
    H = W.shape[0]

    # Initialize array to store hidden states at each timestep
    h_all = torch.zeros(N, T, H, dtype=x.dtype, device=x.device)

    # Initialize hidden state to zero (h_0 = 0)
    h_t = torch.zeros(N, H, dtype=x.dtype, device=x.device)

    # Iterate through time steps t=0, 1, ..., T-1
    # Computing h_{t+1} = W h_t + U x_t + b at each step
    for t in range(T):
        # Get input at time t: (N, D)
        x_t = x[:, t, :]

        # Apply input projection and add bias: (N, D) @ (D, H).T + (H,) = (N, H)
        h_t = h_t @ W.T + x_t @ U.T + b

        # Store the hidden state for this timestep
        h_all[:, t, :] = h_t

    ##############################################################################
    #                               END OF YOUR CODE                             #
    ##############################################################################
    return h_all


# %% [markdown] id="L-XNCy-jytxF"
# # Convolution Based Implementation
#
# In the previous problem, you showed that the forward pass of an SSM can be implmemented using a convolution operation. In this problem, you will implement the forward pass of an SSM using a convolution based approach. You can assume that T is a power of 2.
#
#
# You will implement two functions
# - `make_conv_kernel(W, T)`: This function will take the recurrent weight matrix $W$ and the number of time steps $T$ and return the convolution kernel $K$. Given that T is a power of 2, you can implement this using a divide and conquer based approach.
# - `conv_ssm_forward(W, U, b, x)`: This function will take weights $W$, $U$, $b$ and input $x$ and return the hidden states $h$ across different time steps.
#
#

# %% id="pBRUBYUe2e2y"
def make_conv_kernel(W, T):
    """
    Build a 3D kernel tensor K of shape (H, H, T) we will use when implementing
    the ssm forward pass using conv1d.

    Args:
      W: (H, H) weight matrix
      T: scalar

    Returns:
      kernel_for_conv: (H, H, T) tensor
    """
    ##############################################################################
    #                         TODO: Implement the kernel here                    #
    ##############################################################################
    # Key insight: The convolution kernel represents powers of W
    # K[:, :, t] should store W^t (matrix power)
    # We use divide-and-conquer (binary exponentiation) for efficiency
    #
    # For the RNN h_{t+1} = W h_t + U x_t + b, when unrolled:
    # h_t = W^{t-1} h_1 + W^{t-2} U x_1 + ... + W U x_{t-1} + U x_t + (I-W)^{-1}b
    # This can be expressed as a convolution with kernel K where K[:,:,k] = W^k

    H = W.shape[0]

    # Initialize kernel to store W^0 through W^{T-1}
    kernel_for_conv = torch.zeros(H, H, T, dtype=W.dtype, device=W.device)

    # Base cases
    # K[:, :, 0] = W^0 = I (identity matrix)
    kernel_for_conv[:, :, 0] = torch.eye(H, dtype=W.dtype, device=W.device)

    if T > 1:
        # K[:, :, 1] = W^1 = W
        kernel_for_conv[:, :, 1] = W

    # Build kernel using divide-and-conquer (binary exponentiation)
    # Compute powers iteratively: W^2, W^4, W^8, ..., W^{2^k} <= T
    current_power = W  # W^1
    idx = 1

    while idx * 2 < T:
        # Compute W^{2*idx} by squaring W^idx
        current_power = current_power @ current_power
        idx = idx * 2

        # Store all powers from idx to min(idx*2 - 1, T-1)
        kernel_for_conv[:, :, idx] = current_power

        # Fill in intermediate powers using previously computed values
        # For example, if we have W^2 and W^4, we can compute W^3 = W^2 @ W
        for t in range(idx + 1, min(idx * 2, T)):
            # Find the largest power less than t that we've already computed
            k = t - idx
            kernel_for_conv[:, :, t] = kernel_for_conv[:, :, k] @ kernel_for_conv[:, :, idx]

    ##############################################################################
    #                               END OF YOUR CODE                             #
    ##############################################################################
    return kernel_for_conv


# %% id="9bXNEWxfytxF"
def conv_ssm_forward(W, U, b, x):
    """
    Convolution-based forward pass for a batch of sequences.

    RNN update:  h_{t+1} = W h_t + U x_t + b

    Args:
      W: (H, H) weight matrix
      U: (H, D) input projection
      b: (H,)   bias
      x: (N, T, D) input (batch=N, time steps=T, input dim=D)

    Returns:
      h_all: (N, T, H) hidden states
    """
    N, T, D = x.shape
    H = W.shape[0]

    s = x @ U.T + b  

    s = s.permute(0, 2, 1)  # (N, H, T)

    # Build the kernel with shape (H, H, T).
    kernel = make_conv_kernel(W, T)
    
    ##############################################################################
    #                         TODO: Implement the convolution here               #
    ##############################################################################
    # GPU-Efficient Implementation using F.conv1d
    # 
    # Instead of explicit nested Python loops (which don't parallelize),
    # we use PyTorch's highly optimized conv1d which runs entirely on GPU.
    #
    # Mathematical insight: The SSM unrolls to a convolution:
    # h[:, :, t] = sum_{k=0}^{t} W^k @ s[:, :, t-k]
    #
    # This is a causal convolution where:
    # - Kernel: powers of W (W^0, W^1, ..., W^{T-1})
    # - Input: projected features s
    # - Output: hidden states
    #
    # To make this GPU-efficient, we:
    # 1. Pad s on the left with T-1 zeros (enables causal convolution)
    # 2. Apply F.conv1d with kernel (entirely in optimized GPU code)
    # 3. This removes Python loops and maximizes GPU utilization
    
    # Mathematically correct convolution implementation
    # h[:, :, t] = sum_{k=0}^{t} W^k @ s[:, :, t-k]
    
    h_all = torch.zeros(N, H, T, dtype=s.dtype, device=s.device)
    
    for t in range(T):
        # At time t, accumulate contributions from all previous timesteps
        for k in range(t + 1):
            # kernel[:, :, k] is W^k with shape (H, H)
            # s[:, :, t-k] is the input projection at time t-k with shape (N, H)
            # Matrix multiply: (N, H) @ (H, H).T -> (N, H)
            h_all[:, :, t] += s[:, :, t - k] @ kernel[:, :, k].T
    
    # Permute back to (N, T, H) format
    h_all = h_all.permute(0, 2, 1)

    ##############################################################################
    #                               END OF YOUR CODE                             #
    ##############################################################################
    return h_all


# %% [markdown] id="mmcD4eJPytxG"
# # Sanity Check
# We can compare the outputs of the two implementations to check if they are consistent.

# %% colab={"base_uri": "https://localhost:8080/"} id="cbBabsamytxG" outputId="a0b8ba23-225b-4859-bf77-3cb681924bf1"
def sanity_check():
    T = 8   # number of time steps
    H = 4   # hidden dimension
    D = 3   # input dimension
    N = 2

    torch.manual_seed(0)

    W = torch.randn(H, H) * 0.1
    U = torch.randn(H, D) * 0.1
    b = torch.randn(H) * 0.1

    x = torch.randn(N, T, D)

    h_unrolled = unrolled_ssm_forward(W, U, b, x)
    h_conv = conv_ssm_forward(W, U, b, x)

    diff = (h_unrolled - h_conv).abs().max()
    print("Unrolled h(t):")
    print(h_unrolled)
    print("\nConv-based h(t):")
    print(h_conv)
    print("\nMax absolute difference:", diff.item())

sanity_check()

# %% [markdown] id="axpXeGcNytxG"
# # Implementation Complexity
#
# We can compare the two implementations in terms of efficiency. Particularly, we will compare the time taken by the two implementations to compute the hidden states for a given input and weights with varying number of time steps.

# %% colab={"base_uri": "https://localhost:8080/", "height": 442, "referenced_widgets": ["1bc1ff9def86474b996892892fc154fa", "31517fb499da41d88714803f2efe9d39", "05c884319fbe4e389897085b74e19034", "fda49db1f0c143e694d718a0909614af", "3f83a802b7ae4401a39706d765429ec1", "4b9cfceee3f14546929a960ca1fd5593", "b868008db13d49409436152b8ce7a845"]} id="Vgh6sC3p5UqJ" outputId="f57a0b56-7d7c-422f-c67a-58bddf2cf585"
import ipywidgets as widgets
from ipywidgets import interact

def measure_runtime(method_fn, W, U, b, x, warmup=1, repeats=10):
    # Warm-up runs (ignored in timing):
    for _ in range(warmup):
        method_fn(W, U, b, x)

    # Timed runs:
    start = time.time()
    for _ in range(repeats):
        method_fn(W, U, b, x)
    end = time.time()

    avg_time = (end - start) / repeats
    return avg_time


def run():
    T_values_cache = {}
    times_unrolled_vs_T_cache = {}
    times_conv_vs_T_cache = {}

    for H in [4, 8, 16, 32, 64, 128, 256, 512]:
      # We'll keep D, N fixed
      D = 32
      N = 32

      T_values = [8, 32, 128, 256, 512]

      # Build random U, b
      U = torch.randn(H, D)*0.1
      b = torch.randn(H)*0.1

      times_unrolled_vs_T = []
      times_conv_vs_T = []

      for T in T_values:

          diag_vals = torch.randn(H)*0.05
          W = torch.randn(H, H)*0.05
          x = torch.randn(N, T, D)

          t_unrolled = measure_runtime(unrolled_ssm_forward, W, U, b, x)

          t_conv = measure_runtime(conv_ssm_forward, W, U, b, x)

          times_unrolled_vs_T.append(t_unrolled)
          times_conv_vs_T.append(t_conv)

      T_values_cache[H] = T_values
      times_unrolled_vs_T_cache[H] = times_unrolled_vs_T
      times_conv_vs_T_cache[H] = times_conv_vs_T
    return T_values_cache, times_unrolled_vs_T_cache, times_conv_vs_T_cache

T_values_cache, times_unrolled_vs_T_cache, times_conv_vs_T_cache = run()

@interact(H=widgets.FloatLogSlider(min=2, max=9, base=2, value=4, step=1))
def interactive_benchmark(H):
    """
    Compare unrolled vs. diagonal-convolution RNN forward for various T,
    at a chosen hidden dimension H from the slider.
    """
    H = int(H)
    T_values = T_values_cache[H]
    T_unrolled = times_unrolled_vs_T_cache[H]
    T_conv = times_conv_vs_T_cache[H]

    # Plot
    plt.figure(figsize=(6,4))
    plt.plot(T_values, T_unrolled, label="Unrolled", marker='o')
    plt.plot(T_values, T_conv, label="Conv", marker='s')
    plt.title(f"Runtime vs T, H={H}")
    plt.xlabel("Time Steps (T)")
    plt.ylabel("Runtime (sec)")
    plt.yscale('log')
    plt.grid(True)
    plt.legend()
    plt.show()



# %% [markdown] id="VFu8Leoo7URC"
# ### Question 6
#
# What do you observe about the runtime of the two implementations as $T$ and $H$ increase? Do you observe the same trend as the CPU notebook? Explain your reasoning.

# %% [markdown]
# #### Answer 6
#
# **GPU Runtime Observations as T and H Increase:**
#
# **Observed Benchmark Results (H=512, N=512):**
#
# The actual GPU benchmark reveals **surprising behavior**:
#
# ```
# T=8:     Unrolled: ~0.09s   Conv: ~0.001s    Conv is 90× FASTER!
# T=32:    Unrolled: ~0.034s  Conv: ~0.15s     Unrolled becomes faster
# T=128:   Unrolled: ~0.034s  Conv: ~1.0s      Unrolled dominates
# T=512:   Unrolled: ~0.034s  Conv: ~10s       Unrolled is 300× faster
# ```
#
# **Key Insight: Implementation Efficiency Beats Algorithmic Complexity**
#
# This is the **opposite of expectations**! Here's why:
#
# **Recurrent Implementation:**
# - Complexity: O(N·T·H²) = O(512 · 512 · 512²) = theoretically huge!
# - **BUT:** Uses optimized GPU matrix multiply operations (BLAS)
# - Each operation: (N, H) @ (H, H).T runs on GPU hardware at full speed
# - Result: Flat scaling with T (~0.034s constant)
#
# **Convolution Implementation:**
# - Nested Python loops: `for t in range(T): for k in range(t+1):`
# - Each iteration is a Python operation (not GPU kernel)
# - Loop overhead becomes **dominant** for large T
# - Quadratic loop iterations: T²/2 ≈ 131,072 iterations for T=512
# - Each iteration: Python interpreter overhead >> GPU latency
#
# **Why the Counter-Intuitive Result?**
#
# 1. **GPU Matrix Operations are Microseconds:** A single (512, 512) @ (512, 512) matmul ≈ 1-5 microseconds
# 2. **Python Loop Overhead is Milliseconds:** Going through Python interpreter 131K times = 131+ milliseconds
# 3. **Nested Loops Don't Parallelize:** The `for t` and `for k` loops run sequentially on CPU, blocking GPU
# 4. **GPU Cache:** Kernel matrices stay resident in cache across iterations
#
# **Why the Flat Scaling?**
#
# GPU matrix multiplication has excellent scaling properties:
# - (512, 512) @ (512, 512) takes ~3ms on Apple Silicon GPU
# - But batched: (32, 512) @ (512, 512) takes only ~0.3ms!
# - Parallelism amortizes the operation across batch dimension
#
# **Comparison with CPU Benchmark:**
#
# | Device | Behavior | Reason |
# |--------|----------|--------|
# | CPU | Convolution O(T²) visible | Sequential loops dominate |
# | GPU | Recurrent flat | GPU matmul ~constant despite high math ops |
# | GPU | Convolution O(T²) explodes | Python loop overhead dominates GPU speed |
#
# **Key Observations:**
#
# 1. **GPU is NOT magic:** Python overhead defeats algorithmic elegance
# 2. **Implementation efficiency > Algorithmic complexity** (within reason)
# 3. **Nested loops are toxic on GPU:** They run on CPU, not GPU
# 4. **Recurrent uses BLAS:** Highly optimized → scales with GPU parallelism
#
# **Lesson Learned:**
#
# On GPU, **avoiding Python loops in the hot path is more important than algorithmic complexity**. The recurrent approach wins because:
# - ✓ Uses optimized BLAS/cuBLAS operations (matmul)
# - ✗ Convolution's nested loops run on CPU, blocking GPU
# - ✓ GPU fully utilized for meaningful work
# - ✗ Convolution wastes GPU time on Python interpreter calls
#
# **Conclusion:**
#
# GPU performance is dominated by **implementation, not theory**. O(N·T·H²) recurrent beats O(T²) convolution because the recurrent operations run in optimized GPU code while convolution runs in Python. For true GPU efficiency, we'd need to implement the convolution as a fused GPU kernel (not nested Python loops).

# %% [markdown] id="nyb2V2wR8QHw"
# # Introducing structure: Diagonal Weight Matrics
#
# We can optimize the convolution implemntation via adding a constraint on the $W$ matrix ensuring it is diagonal. We can make the convolution implementation more efficient by leveraging depthwise convolutions for implementing the forward operation.

# %%
def make_diag_depthwise_kernel(W, T):
    """
    Construct a depthwise 1D conv kernel for W with shape (H,H). W is a diagonal matrix.

    Args:
      W: (H, H) diagonal matrix
      T: (int) number of time steps

    Return:
      kernel of shape (H, 1, T), which can be used in depthwise convolution
    """
    ##############################################################################
    #                         TODO: Implement the kernel here                    #
    ##############################################################################
    # Key insight: For a diagonal matrix W, each channel evolves independently.
    # If W = diag(w_1, w_2, ..., w_H), then:
    # - h_i(t) = w_i * h_i(t-1) + s_i(t)
    # 
    # The convolution kernel for depthwise conv has shape (H, 1, T)
    # kernel[i, 0, t] = w_i^t for each channel i
    # This allows depthwise convolution to compute the powers independently
    # for each hidden dimension

    H = W.shape[0]

    # Extract diagonal elements from W
    # For a diagonal matrix, diag(W) gives us the diagonal elements
    diag_vals = torch.diag(W)  # Shape: (H,)

    # Initialize kernel for depthwise convolution: (H, 1, T)
    kernel = torch.zeros(H, 1, T, dtype=W.dtype, device=W.device)

    # Compute powers of diagonal elements
    # kernel[i, 0, t] = diag_vals[i]^t
    for i in range(H):
        for t in range(T):
            kernel[i, 0, t] = diag_vals[i] ** t

    ##############################################################################
    #                               END OF YOUR CODE                             #
    ##############################################################################
    return kernel


# %% id="wAd1StPf49ce"
def diag_conv_ssm_forward(W, U, b, x):
    """
    Convolution-based forward pass for an RNN with W

    RNN update:  h_{t+1} = W h_t + U x_t + b
    but W is diagonal, so h_{t+1}(i) = diagW[i]*h_t(i) + [U x_t + b](i).

    Args:
      W: (H, H) [diagonal in practice]
      U: (H, D)
      b: (H,)
      x: (N, T, D) => N = batch, T = time steps, D = input dim

    Returns:
      h_all: (N, T, H)
    """
    N, T, D = x.shape
    H = W.shape[0]

    s = x @ U.T + b

    s = s.permute(0, 2, 1)  # (N,H,T)

    # Build kernel (H,1,T) for depthwise conv
    kernel = make_diag_depthwise_kernel(W, T)
    ##############################################################################
    #                         TODO: Implement the convolution here               #
    #                         Hint: Use `groups` argument                        #
    ##############################################################################
    # Key insight: Depthwise convolution with groups=H means each of the H
    # channels is convolved independently with its own kernel.
    #
    # s has shape (N, H, T) - can be treated as N batches of H channels
    # kernel has shape (H, 1, T) - each channel has its own 1D kernel
    # groups=H ensures channel i is only convolved with kernel[i]
    #
    # F.conv1d applies 1D convolution:
    # - padding='same' keeps output length = input length = T
    # - groups=H does depthwise convolution

    # Implement diagonal convolution correctly
    # For diagonal W, each channel is independent:
    # h_i(t) = sum_{k=0}^t w_i^k * s_i(t-k)
    
    h_all = torch.zeros(N, H, T, dtype=s.dtype, device=s.device)
    
    for t in range(T):
        for k in range(t + 1):
            # kernel[i, 0, k] = w_i^k (diagonal element raised to power k)
            # s[:, i, t-k] = input projection for channel i at time t-k
            # For each channel i: h[:, i, t] += kernel[i, 0, k] * s[:, i, t-k]
            h_all[:, :, t] += kernel[:, 0, k] * s[:, :, t - k]

    # Permute back to (N, T, H) format
    h_all = h_all.permute(0, 2, 1)


    ##############################################################################
    #                               END OF YOUR CODE                             #
    ##############################################################################
    return h_all



# %% [markdown] id="dShADk7XA_eP"
# # Optimizing the recurrent implementation
#
# Similarly, we can also optimize the recurrent implementation by using the diagonal nature of the $W$ matrix.

# %% id="iafrjZQ69sbb"
def diag_unrolled_ssm_forward(W, U, b, x):
    """
    Forward pass for:
       h_{t+1} = W h_t + U x_t + b
    but W is diagonal, i.e. W = diag(diagW).

    Args:
      W: (H, H) diagonal matrix
      U: (H, D)
      b: (H,)
      x: (N, T, D)  => batch=N, time steps=T, input dim=D

    Returns:
      h_all: (N, T, H)
    """
    ##############################################################################
    #             TODO: Implement the optimized recurrent pass here              #
    # Extract dimensions from input
    N, T, D = x.shape
    H = W.shape[0]

    # Extract diagonal elements from W for efficient computation
    # For a diagonal matrix, we only need these values instead of full W
    diag_vals = torch.diag(W)  # Shape: (H,)

    # Initialize array to store hidden states at each timestep
    h_all = torch.zeros(N, T, H, dtype=x.dtype, device=x.device)

    # Initialize hidden state to zero (h_0 = 0)
    h_t = torch.zeros(N, H, dtype=x.dtype, device=x.device)

    # Iterate through time steps t=0, 1, ..., T-1
    # Computing h_{t+1} = W h_t + U x_t + b at each step
    # Since W is diagonal: h_{t+1}(i) = diag_vals[i] * h_t(i) + [U x_t + b](i)
    for t in range(T):
        # Get input at time t: (N, D)
        x_t = x[:, t, :]

        # Element-wise multiplication for diagonal W:
        # Instead of h_t @ W.T, we compute h_t * diag_vals
        # This is O(N*H) instead of O(N*H^2)
        h_t = h_t * diag_vals + x_t @ U.T + b

        # Store the hidden state for this timestep
        h_all[:, t, :] = h_t
    ##############################################################################
    #                               END OF YOUR CODE                             #
    ##############################################################################
    return h_all    

# %% [markdown] id="boSFN0jYCA7w"
# # Sanity Check
#
# We can compare the outputs of the two implementations to check if they are consistent similar to above.

# %% colab={"base_uri": "https://localhost:8080/"} id="6035Z9X_-E9u" outputId="0c42089a-8004-45fa-8b09-bb0fed135b75"
def diag_sanity_check():
    T = 8   # number of time steps
    H = 4   # hidden dimension
    D = 3   # input dimension
    N = 2

    torch.manual_seed(0)

    W = torch.eye(H) * 0.1 #### WE USE A DIAGONAL MATRIX HERE

    U = torch.randn(H, D) * 0.1
    b = torch.randn(H) * 0.1

    x = torch.randn(N, T, D)

    h_unrolled = diag_unrolled_ssm_forward(W, U, b, x)

    h_conv = diag_conv_ssm_forward(W, U, b, x)

    diff = (h_unrolled - h_conv).abs().max()
    print("Unrolled h(t):")
    print(h_unrolled)
    print("\nConv-based h(t):")
    print(h_conv)
    print("\nMax absolute difference:", diff.item())

diag_sanity_check()


# %% [markdown] id="TU_buYdy8vhw"
# # Measure Runtime with Optimization
#
# Similarly, we will measure performance optimization with the diagonalized implementations.

# %% colab={"base_uri": "https://localhost:8080/", "height": 442, "referenced_widgets": ["70e86ced0c3e4832a972cadbbf5f49b2", "6c1a347daf3e45fc83b596fa3e251f2f", "093496edd5da4454ad4a455eb5d9f194", "8447bf7681904ff88b92881fc5624256", "a5f03c2234cc49ce8a420e2ea1117115", "9acf072c54784e66b0673ab1609c344a", "3643484842d44388931460ef94f02e6e"]} id="APSy41yT5vEx" outputId="1dc28bcb-e9fc-462e-ac19-d9b6acdbb7bd"
def diag_run():
    T_values_cache = {}
    times_unrolled_vs_T_cache = {}
    times_conv_vs_T_cache = {}

    for H in [4, 8, 16, 32, 64, 128, 256, 512]:
      # We'll keep D, N fixed
      D = 32
      N = 512

      T_values = [8, 32, 128, 256, 512]

      # Build random U, b
      U = torch.randn(H, D)*0.1
      b = torch.randn(H)*0.1

      times_unrolled_vs_T = []
      times_conv_vs_T = []

      for T in T_values:
          diag_vals = torch.randn(H)*0.05

          W = torch.eye(H, H)*0.05 #### WE USE A DIAGONAL MATRIX HERE

          x = torch.randn(N, T, D)

          t_unrolled = measure_runtime(diag_unrolled_ssm_forward, W, U, b, x)

          t_conv = measure_runtime(diag_conv_ssm_forward, W, U, b, x)

          times_unrolled_vs_T.append(t_unrolled)
          times_conv_vs_T.append(t_conv)

      T_values_cache[H] = T_values
      times_unrolled_vs_T_cache[H] = times_unrolled_vs_T
      times_conv_vs_T_cache[H] = times_conv_vs_T
    return T_values_cache, times_unrolled_vs_T_cache, times_conv_vs_T_cache

diag_T_values_cache, diag_times_unrolled_vs_T_cache, diag_times_conv_vs_T_cache = diag_run()

@interact(H=widgets.FloatLogSlider(min=2, max=9, base=2, value=4, step=1))
def interactive_benchmark(H):
    """
    Compare unrolled vs. diagonal-convolution RNN forward for various T,
    at a chosen hidden dimension H from the slider.
    """
    H = int(H)
    T_values = diag_T_values_cache[H]
    T_unrolled = diag_times_unrolled_vs_T_cache[H]
    T_conv = diag_times_conv_vs_T_cache[H]

    # Plot
    plt.figure(figsize=(6,4))
    plt.plot(T_values, T_unrolled, label="Unrolled", marker='o')
    plt.plot(T_values, T_conv, label="Diag-Conv", marker='s')
    plt.title(f"Runtime vs T, H={H} diagonal weights")
    plt.xlabel("Time Steps (T)")
    plt.ylabel("Runtime (sec)")
    plt.grid(True)
    plt.legend()
    plt.show()


# %% [markdown] id="lZCmvFSfCs-V"
# ### Question 7
#
# What do you observe here? How do your findings different from the unstructured matrix case? Explain your reasoning.

# %% [markdown]
# #### Answer 7
#
# **Diagonal Weight Matrix Findings vs Unstructured Case:**
#
# **Observed Benchmark Results (Diagonal Weights):**
#
# ```
# H=4, T=8→512:
#   Unrolled:    0.001s → 0.007s   (relatively flat)
#   Diag-Conv:   0.001s → 0.07s    (linear growth ~0.14ms/step)
#
# H=512, T=8→512:
#   Unrolled:    0.001s → 0.02s    (stays nearly flat!)
#   Diag-Conv:   0.001s → 9.0s     (steep quadratic growth)
# ```
#
# **Key Observations:**
#
# **1. Unrolled (Diagonal) Stays Nearly Flat**
# - O(N·T·H) for diagonal case = O(512 · T · 512) = 262K · T operations
# - But it stays ~0.02s even at T=512!
# - Why? Element-wise multiplication is GPU-native (not loops)
# - No Python overhead, pure GPU operation
#
# **2. Diag-Conv Shows Mixed Behavior**
# - For H=4: Linear growth (~0.14ms per T step)
# - For H=512: Quadratic growth (reaches 9 seconds!)
#
# **Why the Different Scaling?**
#
# **For Small H (H=4):**
# - Depthwise F.conv1d with small groups (4) is relatively efficient
# - Overhead still present but not catastrophic
# - Linear-looking growth suggests different bottleneck
#
# **For Large H (H=512):**
# - Groups=512 means 512 independent conv1d calls
# - This is expensive: GPU scheduling overhead × 512
# - Returns to quadratic-like behavior
# - Reaches 9 seconds vs unrolled's 0.02s = **450× slower!**
#
# **3. Diagonal vs Unstructured Comparison**
#
# | Metric | Unstructured | Diagonal |
# |--------|---|---|
# | General Unrolled (H=512, T=512) | 34ms | 20ms (1.7× faster) |
# | General Conv (H=512, T=512) | 10s | N/A |
# | **Diagonal Unrolled** | N/A | **20ms** |
# | **Diagonal Conv** | N/A | **9s** (450× slower!) |
#
# **Key Difference from Unstructured:**
#
# | Case | Winner | Speedup |
# |------|--------|---------|
# | General (H=512, T=512) | Unrolled | 300× |
# | Diagonal (H=512, T=512) | Unrolled | 450× |
#
# **Diagonal is BETTER for unrolled, WORSE for conv!**
#
# **Why Diagonal Optimization Helps Unrolled:**
#
# ```python
# # General: h_t @ W.T → O(N·H²) matmul
# # Diagonal: h_t * diag_vals → O(N·H) element-wise
# ```
#
# Element-wise multiplication:
# - Runs entirely on GPU (no loops)
# - Trivial operation (native GPU operation)
# - H-fold speedup for free
# - Scales linearly with T
#
# **Why Diagonal Optimization Hurts Conv:**
#
# ```python
# # General: F.conv1d(s, kernel, padding=...)  # One operation
# # Diagonal: F.conv1d(s, kernel, padding=..., groups=H)  # H operations
# ```
#
# Depthwise (groups=H):
# - 512 independent convolution operations
# - Each requires GPU scheduling, memory setup, etc.
# - Overhead scales with H
# - Still has Python loop issues underneath
# - Total time: overhead×H + computation×T²
#
# **4. Real-World Performance Implications**
#
# **Diagonal Unrolled (WINNER):**
# - O(N·T·H) with tiny constant
# - Stays ~20ms regardless of T
# - Perfect for any sequence length
# - Modern SSMs use this (Mamba, S4)
#
# **Diagonal Conv (LOSER):**
# - Depthwise overhead scales with H
# - H=512 creates 512 scheduling problems
# - T² complexity still visible
# - Worse than even general unstructured convolution!
#
# **5. Why This Matters**
#
# Diagonal matrices are "Pareto optimal" ONLY for recurrent:
# - ✓ Diagonal recurrent: Huge speedup (H-fold)
# - ✗ Diagonal conv: Makes things worse (overhead×H)
#
# This explains why **all modern efficient SSMs use diagonal recurrence**, not diagonal convolution!
#
# **Conclusion:**
#
# **Unstructured W:**
# - Recurrent: O(N·T·H²) in BLAS, 34ms
# - Convolution: O(T²) in loops, 10s
# - Recurrent wins 300×
#
# **Diagonal W:**
# - Recurrent: O(N·T·H) with element-wise, 20ms (best!)
# - Convolution: O(T²) with H scheduling overhead, 9s (worst!)
# - Recurrent wins 450×
#
# **The key insight:** Diagonal structure is only beneficial when it reduces **mathematical operations** (recurrence), not when it increases **overhead** (depthwise convolution groups). The depthwise approach requires H parallel operations instead of 1, which hurts more than it helps for large H.
