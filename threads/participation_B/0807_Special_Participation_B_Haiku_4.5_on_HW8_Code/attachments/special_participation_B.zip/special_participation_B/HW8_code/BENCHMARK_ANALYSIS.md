# GPU SSM Benchmark Analysis - Findings vs Theory

## Executive Summary

The GPU benchmarks reveal a **critical insight**: Algorithmic complexity matters far less than implementation efficiency on GPUs. Python loops are the bottleneck, not mathematics.

---

## Observed Results (H=512, N=512)

### Raw Measurements

```
T=8:
  Unrolled: ~0.09s
  Conv:     ~0.001s  (90× faster!)

T=32:
  Unrolled: ~0.034s
  Conv:     ~0.15s   (Unrolled wins)

T=128:
  Unrolled: ~0.034s
  Conv:     ~1.0s    (Unrolled: 29× faster)

T=512:
  Unrolled: ~0.034s
  Conv:     ~10s     (Unrolled: 300× faster!)
```

### Sanity Check Output

Before fix: `Max difference: 2.98e-08` (correct)
After F.conv1d attempt: `Max difference: 0.345` (broken)
Current nested loops: `Max difference: ~2e-8` (correct)

---

## Why the Counter-Intuitive Results?

### The Unrolled Approach (O(N·T·H²))

```python
for t in range(T):
    h_t = h_t @ W.T + x_t @ U.T + b
    h_all[t] = h_t
```

**Analysis:**
- Math: O(N·T·H²) = O(512 · 512 · 512²) = 68 billion ops theoretically
- **Reality:** Each operation runs in GPU hardware
- One (512, 512) @ (512, 512) matmul: ~3 milliseconds on GPU
- Per timestep: ~0.04ms (batched operations parallelize!)
- Total for T=512: 512 × 0.04ms ≈ 20ms... but it's ~34ms constant!

**Why constant?** GPU batching and caching:
- (32, 512) @ (512, 512) batched: ~0.3ms (not 10.24ms)
- Kernel matrices stay in L2 cache
- Memory bandwidth dominates, not compute

### The Convolution Approach (O(T²) Python loops)

```python
for t in range(T):                  # Loop 1: T iterations
    for k in range(t + 1):          # Loop 2: average T/2 iterations
        h_all[:, :, t] += s[:, :, t - k] @ kernel[:, :, k].T
```

**Analysis:**
- Loop iterations: T²/2 = 512²/2 = 131,072 iterations
- Each iteration: One matmul + some Python overhead
- **Problem:** Each loop runs on **CPU (Python interpreter)**
- Python loop overhead: ~1 microsecond per iteration
- Loop overhead alone: 131ms (without even doing matmul!)
- Actual observation: ~10 seconds = 10,000ms

**Why so slow?**
1. Python for loop: CPU operation, not GPU
2. Each iteration goes through Python interpreter
3. GPU can't parallelize nested Python loops
4. GPU blocks waiting for CPU to send next operation
5. Data transfers between GPU and Python add latency

---

## The Fundamental Insight

### Theory vs Practice

| Metric | Recurrent | Convolution |
|--------|-----------|-------------|
| Algorithmic Complexity | O(N·T·H²) | O(T²) Python loops |
| Actual GPU Operations | O(N·T·H²) in hardware | O(T²) in Python |
| Execution Location | GPU (BLAS) | CPU (Python) |
| Parallelization | Full (batched) | None (sequential loops) |
| **Performance Winner** | ✓ Recurrent | ✗ Convolution |

### Why Unrolled Wins Despite Higher Complexity

1. **GPU Matmul is Incredibly Fast:**
   - (512, 512) @ (512, 512): ~3ms
   - Batched (32, 512) @ (512, 512): ~0.3ms
   - Hardware designed for this exact operation

2. **Python Loop Overhead Destroys Convolution:**
   - 131,072 loop iterations × 1µs overhead = 131ms minimum
   - Each iteration needs to transfer data to/from GPU
   - Roundtrip latency adds up

3. **Batching Amortizes Cost:**
   - One GPU kernel call for 512 samples
   - Sequential T iterations use same hot cache
   - GPU's internal parallelism handles O(H²) matmul efficiently

4. **GPU Cache Locality:**
   - W, U, b stay in L2 cache
   - Kernel matrices stay resident
   - No memory bandwidth limitation

---

## What Would Make Convolution Fast?

To make convolution competitive, we'd need:

1. **Option 1: Fused GPU Kernel**
   ```cpp
   __global__ void convolution_kernel(float *h, float *s, float *K, int T) {
       // All loops in GPU code, not Python
       // Each thread handles one timepoint
       // Perfect parallelization
   }
   ```
   - Eliminates Python loop overhead
   - Parallelizes across T dimension
   - Would likely be 10-100× faster

2. **Option 2: Batched Operations**
   - Use `torch.bmm()` or `torch.einsum()` instead of loops
   - Let PyTorch/cuDNN optimize the operation
   - Avoid explicit Python loops

3. **Option 3: Async GPU Kernels**
   - Stream operations to GPU
   - Let GPU parallelize while CPU sends next ops
   - Still limited by CPU-GPU bottleneck

---

## CPU vs GPU Comparison

### CPU Results (from earlier)

```
H=256, T=512:
  Recurrent:    50ms    (linear in T)
  Convolution:  20s     (quadratic in T!) 
```

### GPU Results

```
H=512, T=512:
  Recurrent:    34ms    (roughly constant!)
  Convolution:  10s     (quadratic in T!)
```

**Key Difference:**
- CPU: Recurrent scales linearly (fast), convolution O(T²) (slow)
- GPU: Recurrent scales amazingly (batching), convolution O(T²) in Python (even slower)

---

## Practical Lessons

### 1. Avoid Python Loops in Hot Paths on GPU
```python
# ❌ BAD (what we have now)
for t in range(T):
    for k in range(t+1):
        result += matmul(a, b)  # GPU operation

# ✓ GOOD (uses GPU optimizations)
result = torch.einsum('nht,tht->nht', s, kernel)
# or: result = batched_matmul(...)
```

### 2. Algorithmic Complexity ≠ Practical Performance
- O(N·T·H²) can beat O(T²) if the former runs in hardware
- O(T²) in Python > O(T) in GPU... sometimes

### 3. Implementation Details Matter Most
- Where code runs (GPU vs CPU)
- Whether it's vectorized
- Data transfer overhead
- Caching behavior

### 4. GPU Batching is Powerful
- Single (32, 512) @ (512, 512): faster than 32 × (1, 512) @ (512, 512)
- Amortizes overhead
- Hardware utilization improves

---

## Why Current Implementation is Correct

The nested loop convolution implementation:
1. **Is mathematically correct** (verified by sanity check)
2. **Is GPU-compatible** (uses PyTorch operations)
3. **Is suboptimal** (due to Python loop overhead)
4. **Is necessary** (for the assignment as specified)

To optimize would require rewriting as a GPU kernel or using PyTorch's einsum.

---

## Benchmark Graph Interpretation

The plot shows:
```
Runtime vs T, H=512

Unrolled (blue line):   Stays mostly flat
  - GPU batching amortizes cost
  - Matmul speed dominates
  - Shows true GPU efficiency

Convolution (orange):   Rises steeply
  - Python loop overhead visible
  - Quadratic growth clear
  - Shows Python bottleneck
```

The steep orange line is **not** showing the true O(T²) complexity - it's showing the impact of 131K Python loop iterations!

---

## Conclusion

### Key Findings

1. **Implementation efficiency > algorithmic complexity** on modern GPUs
2. **Python loops are performance killers** on GPU workloads
3. **GPU batching is incredibly powerful** for amortizing overhead
4. **The convolution approach is mathematically correct** but practically suboptimal due to Python loops

### Takeaway

Don't judge GPU algorithms by big-O notation alone. A theoretically superior O(T²) algorithm running in Python can be 300× slower than an O(N·T·H²) algorithm running in optimized GPU code.

For true GPU optimization, algorithms need to be either:
1. Implemented in GPU kernels (CUDA/Metal/HIP)
2. Expressed as vectorized PyTorch operations (einsum, bmm, etc.)
3. Otherwise executed at GPU speed through framework optimization

Direct Python loops on GPU = CPU bottleneck = Bad.
