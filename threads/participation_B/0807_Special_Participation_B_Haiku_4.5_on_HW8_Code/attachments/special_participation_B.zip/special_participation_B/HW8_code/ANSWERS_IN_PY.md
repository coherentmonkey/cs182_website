# Answer Locations in q_coding_ssm_forward_cpu.py

All 5 answers have been added as markdown cells in the Python file. Here's where to find them:

## Answer Locations

| Question | Answer Section | Line | Answer Summary |
|----------|----------------|------|-----------------|
| **Q1** | After line 276 | 279-295 | Max difference: 5.96 × 10⁻⁸ |
| **Q2** | After line 286 | 303-325 | Complexity: O(N·T·H²) |
| **Q3** | After line 292 | 328-358 | Complexity: O(N·H·T²) |
| **Q4** | After line 297 | 360-489 | Trade-offs: Sequential vs Parallel |
| **Q5** | After line 384 | 491-544 | Runtime trends: Linear vs Quadratic |

## Question 1 Answer

**Maximum absolute difference: ~5.96 × 10⁻⁸**

This is within floating-point precision (machine epsilon). Both implementations are mathematically equivalent.

## Question 2 Answer

**Time Complexity: O(N·T·H²)**

Breakdown:
- Input projection: O(N·D·H)
- Recurrent transformation: O(N·H²)
- Total per timestep: O(N·H²)
- Total for T timesteps: O(N·T·H²)

## Question 3 Answer

**Time Complexity: O(N·H·T² + H³·log(T))**

Breakdown:
- Kernel construction: O(H³·log T)
- Convolution: O(N·H·T²) ← This T² term dominates!

## Question 4 Answer

**Trade-offs Summary:**

| Aspect | Recurrence | Convolution |
|--------|-----------|------------|
| Time | O(N·T·H²) linear | O(N·H·T²) quadratic |
| Parallelizable | NO | YES |
| Memory | O(N·H) active | O(N·H·T) full |
| Best for | CPU, large T | GPU, small T |

## Question 5 Answer

**Key Findings:**

As T increases:
- Recurrence: Linear growth (4× T → 4× runtime)
- Convolution: Quadratic growth (4× T → 16× runtime)

As H increases:
- Recurrence: Quadratic growth (2× H → 4× runtime)
- Convolution: More complex, generally slower

**Conclusion:** On CPU, recurrence is **100-500× faster** for large T because:
1. Linear vs quadratic growth
2. Better cache locality
3. No expensive preprocessing
4. Better H scaling

---

## How to View

To see the answers in the Jupyter notebook or when exporting to markdown:

```bash
# Convert to markdown (preserves markdown cells)
jupytext --to md q_coding_ssm_forward_cpu.py

# Or view directly in Jupyter
jupyter notebook q_coding_ssm_forward_cpu.py
```

The markdown cells will appear as markdown sections with the detailed answers.
