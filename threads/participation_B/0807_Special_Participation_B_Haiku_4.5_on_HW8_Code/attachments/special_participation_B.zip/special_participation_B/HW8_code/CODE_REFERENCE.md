# Code Reference - All Six Solutions

## Problem 1: Recurrent SSM Forward Pass

```python
def unrolled_ssm_forward(W, U, b, x):
    """
    Unroll the linear RNN in time:
        h_{t+1} = W h_t + U x_t + b
    with initial h_0 = 0.
    """
    N, T, D = x.shape
    H = W.shape[0]

    h_all = torch.zeros(N, T, H, dtype=x.dtype, device=x.device)
    h_t = torch.zeros(N, H, dtype=x.dtype, device=x.device)

    for t in range(T):
        x_t = x[:, t, :]
        h_t = h_t @ W.T + x_t @ U.T + b
        h_all[:, t, :] = h_t

    return h_all
```

**Time Complexity:** O(N·T·H²)  
**Memory:** O(N·T·H)  
**Device:** CPU-friendly (sequential)

---

## Problem 2: Convolution Kernel Construction

```python
def make_conv_kernel(W, T):
    """
    Build a 3D kernel tensor K of shape (H, H, T) where K[:,:,k] = W^k
    Using binary exponentiation for efficiency.
    """
    H = W.shape[0]
    kernel_for_conv = torch.zeros(H, H, T, dtype=W.dtype, device=W.device)

    # Base cases
    kernel_for_conv[:, :, 0] = torch.eye(H, dtype=W.dtype, device=W.device)
    if T > 1:
        kernel_for_conv[:, :, 1] = W

    # Binary exponentiation: compute W^2, W^4, W^8, ...
    current_power = W
    idx = 1

    while idx * 2 < T:
        current_power = current_power @ current_power
        idx = idx * 2
        kernel_for_conv[:, :, idx] = current_power

        # Fill intermediate powers: W^3 = W^1 @ W^2, etc.
        for t in range(idx + 1, min(idx * 2, T)):
            k = t - idx
            kernel_for_conv[:, :, t] = kernel_for_conv[:, :, k] @ kernel_for_conv[:, :, idx]

    return kernel_for_conv
```

**Time Complexity:** O(H³·log T)  
**Memory:** O(H²·T)  
**Key Insight:** Store all powers efficiently using squaring + composition

---

## Problem 3: Convolution SSM Forward

```python
def conv_ssm_forward(W, U, b, x):
    """
    Convolution-based forward pass for SSM.
    Uses the kernel to compute h_t = sum_k W^k @ s_{t-k}
    """
    N, T, D = x.shape
    H = W.shape[0]

    s = x @ U.T + b
    s = s.permute(0, 2, 1)  # (N, H, T)

    kernel = make_conv_kernel(W, T)

    h_all = torch.zeros(N, H, T, dtype=s.dtype, device=s.device)

    for t in range(T):
        for k in range(t + 1):
            h_all[:, :, t] += s[:, :, t - k] @ kernel[:, :, k].T

    h_all = h_all.permute(0, 2, 1)
    return h_all
```

**Time Complexity:** O(N·H·T²)  
**Memory:** O(N·H·T + H²·T)  
**Key Insight:** All timesteps can compute in parallel on GPU

---

## Problem 4: Diagonal Depthwise Kernel

```python
def make_diag_depthwise_kernel(W, T):
    """
    For diagonal W, create kernel of shape (H, 1, T).
    kernel[i, 0, t] = w_i^t (powers of diagonal elements)
    """
    H = W.shape[0]
    diag_vals = torch.diag(W)  # Extract diagonal

    kernel = torch.zeros(H, 1, T, dtype=W.dtype, device=W.device)

    for i in range(H):
        for t in range(T):
            kernel[i, 0, t] = diag_vals[i] ** t

    return kernel
```

**Time Complexity:** O(H·T)  
**Memory:** O(H·T)  
**Key Insight:** Each dimension is independent for diagonal W

---

## Problem 5: Diagonal Depthwise Convolution Forward

```python
def diag_conv_ssm_forward(W, U, b, x):
    """
    Optimized convolution for diagonal W using depthwise conv1d.
    groups=H ensures each channel uses only its own kernel.
    """
    N, T, D = x.shape
    H = W.shape[0]

    s = x @ U.T + b
    s = s.permute(0, 2, 1)  # (N, H, T)

    kernel = make_diag_depthwise_kernel(W, T)

    # Depthwise convolution: groups=H means channel i only uses kernel[i]
    h_all = F.conv1d(s, kernel, padding=T - 1, groups=H)

    # Trim to correct length
    h_all = h_all[:, :, :T]

    h_all = h_all.permute(0, 2, 1)
    return h_all
```

**Time Complexity:** O(N·H·T²)  
**Memory:** O(N·H·T + H·T)  
**GPU Advantage:** Depthwise convolution highly optimized, smaller kernel

---

## Problem 6: Diagonal Recurrent Forward

```python
def diag_unrolled_ssm_forward(W, U, b, x):
    """
    Optimized recurrent for diagonal W.
    Uses element-wise multiplication instead of matrix multiply.
    H-fold speedup compared to general recurrence!
    """
    N, T, D = x.shape
    H = W.shape[0]

    diag_vals = torch.diag(W)  # Extract diagonal once

    h_all = torch.zeros(N, T, H, dtype=x.dtype, device=x.device)
    h_t = torch.zeros(N, H, dtype=x.dtype, device=x.device)

    for t in range(T):
        x_t = x[:, t, :]
        # Element-wise multiply instead of h_t @ W.T
        h_t = h_t * diag_vals + x_t @ U.T + b
        h_all[:, t, :] = h_t

    return h_all
```

**Time Complexity:** O(N·T·H)  
**Memory:** O(N·T·H)  
**Key Insight:** Element-wise multiply is O(H) vs matrix multiply O(H²)

---

## Side-by-Side Complexity Comparison

```
┌─────────────────────┬───────────────┬──────────────┬──────────┐
│ Method              │ Time          │ Space        │ GPU?     │
├─────────────────────┼───────────────┼──────────────┼──────────┤
│ Recurrent           │ O(N·T·H²)     │ O(N·T·H)     │ ✗        │
│ Convolution         │ O(N·H·T²)     │ O(N·H·T+HT)  │ ✓        │
│ Diagonal Recurrent  │ O(N·T·H)      │ O(N·T·H)     │ ✗        │
│ Diagonal Convolution│ O(N·H·T²)     │ O(N·H·T+HT)  │ ✓✓       │
└─────────────────────┴───────────────┴──────────────┴──────────┘
```

---

## Sanity Check Pattern (Built Into Code)

```python
def sanity_check():
    T, H, D, N = 8, 4, 3, 2
    torch.manual_seed(0)

    W = torch.randn(H, H) * 0.1
    U = torch.randn(H, D) * 0.1
    b = torch.randn(H) * 0.1
    x = torch.randn(N, T, D)

    h_unrolled = unrolled_ssm_forward(W, U, b, x)
    h_conv = conv_ssm_forward(W, U, b, x)

    diff = (h_unrolled - h_conv).abs().max()
    assert diff.item() < 1e-5, f"Mismatch: {diff.item()}"
    print(f"✓ Implementations match (diff={diff.item():.2e})")
```

---

## Key Tensor Shape Transformations

### General Recurrent/Convolution
```
Input:  x: (N, T, D)
        ↓ (project to hidden space)
        s: (N, T, H)
        ↓ (permute for conv1d)
        s: (N, H, T)
        ↓ (convolve with kernel: (H, H, T))
        h_all: (N, H, T)
        ↓ (permute back)
Output: h_all: (N, T, H)
```

### Diagonal Convolution
```
Input:  x: (N, T, D)
        ↓ (project to hidden space)
        s: (N, T, H)
        ↓ (permute for conv1d)
        s: (N, H, T)
        ↓ (depthwise conv with kernel: (H, 1, T), groups=H)
        h_all: (N, H, T+T-1)
        ↓ (trim to length T)
        h_all: (N, H, T)
        ↓ (permute back)
Output: h_all: (N, T, H)
```

---

## Common Pitfalls & Solutions

| Problem | Cause | Solution |
|---------|-------|----------|
| Shape mismatch in matrix multiply | Wrong transpose | Check dimensions: (N,H) @ (H,H).T |
| Convolution output wrong length | Incorrect padding | Use `padding=T-1` for causal conv |
| Depthwise convolution broken | `groups` parameter missing | Add `groups=H` to F.conv1d |
| Device mismatch | Tensors on different devices | Use `device=x.device` when creating |
| Memory explosion | Kernel too large for large H | Use diagonal optimization |
| Slow GPU computation | Using recurrent instead of conv | Switch to convolution-based approach |

---

## Performance Tips

1. **CPU, large T:** Use diagonal recurrent (fastest, simplest)
2. **CPU, small T:** Use recurrent (lower overhead)
3. **GPU, small T:** Use diagonal recurrent (low latency)
4. **GPU, large T:** Use diagonal convolution (parallelizable)
5. **Memory constrained:** Always use diagonal if possible

---

## Testing Checklist

- [ ] Outputs are close: max diff < 1e-6
- [ ] Shapes correct: (N, T, H) output
- [ ] All on same device: CUDA if needed
- [ ] Diagonal versions match general versions
- [ ] Performance scales as expected
- [ ] No NaNs or Infs in output

---

## Implementation Notes

### Device Management
```python
# Ensure tensors stay on GPU
kernel = torch.zeros(..., device=W.device)
h_all = torch.zeros(..., device=x.device)
```

### Numerical Stability
- Keep W eigenvalues small (< 1) to avoid blow-up
- Use float32 or float64 (depends on precision needs)
- Test with different random seeds

### Batch Processing
- All implementations handle batch dimension N correctly
- Broadcasting works automatically for bias addition

---

## Questions These Solutions Answer

1. **How do you unroll an RNN?** → Problem 1
2. **How do you compute matrix powers efficiently?** → Problem 2
3. **How do you parallelize RNN computation?** → Problem 3
4. **How do you leverage matrix structure (diagonal)?** → Problems 4-6
5. **When is quadratic complexity acceptable?** → Problem 5 (on GPU)
6. **How do you optimize for specific hardware?** → All problems (CPU vs GPU trade-offs)

---

## Further Reading

These solutions implement concepts from:
- Linear recurrent neural networks (S4, Mamba)
- State space models in deep learning
- GPU optimization for sequence models
- Hardware-aware algorithm design
- Matrix exponentiation and binary decomposition

The diagonal SSM case is especially relevant for modern efficient transformers and state-space models like Mamba, where diagonal recurrences enable subquadratic complexity.
