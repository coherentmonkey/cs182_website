# GPU SSM Implementation - Thought Process & Insights

## Overview

This document explains the reasoning behind each implementation and the key insights that make them work.

---

## The Central Problem

We need to compute:
```
h_{t+1} = W h_t + U x_t + b  for t = 0, 1, ..., T-1
with h_0 = 0
```

**Three key questions:**
1. How to compute this efficiently on CPU? (Recurrence)
2. How to compute this in parallel on GPU? (Convolution)
3. How to leverage matrix structure? (Diagonal optimization)

---

## Solution 1: The Direct Approach (Recurrent)

### Insight
The definition literally tells us what to do: apply the update rule step by step.

### Mathematical Reasoning
```
Start: h_0 = 0

Step 1: h_1 = W·0 + U x_0 + b = U x_0 + b
Step 2: h_2 = W h_1 + U x_1 + b = W(U x_0 + b) + U x_1 + b
        = W U x_0 + U x_1 + (W + 1)b
Step 3: h_3 = W h_2 + U x_2 + b
        = W² U x_0 + W U x_1 + U x_2 + (W² + W + 1)b
...
```

### Why It Works
- Each step depends only on the previous step
- No need to store all intermediate values (only current h_t)
- Perfect for sequential processing
- Good cache locality (iterative access)

### When to Use
- ✓ CPU with long sequences (T large)
- ✓ When memory is tight (O(H) active memory)
- ✓ When latency matters (start getting results immediately)
- ✗ GPU with large batches (inherent sequential bottleneck)

### Implementation Complexity
- Time: O(N·T·H²) - straightforward
- Space: O(N·T·H) for output + O(N·H) for state

---

## Solution 2: The Kernel (Convolution Powers)

### Key Insight: Unrolling Pattern

When we expand the recurrence, we get:
```
h_0 = 0
h_1 = U x_0 + b
h_2 = W(U x_0 + b) + U x_1 + b
    = W U x_0 + U x_1 + W b + b
h_3 = W(W U x_0 + U x_1 + W b + b) + U x_2 + b
    = W² U x_0 + W U x_1 + U x_2 + W² b + W b + b
...
h_t = W^{t-1} U x_0 + W^{t-2} U x_1 + ... + U x_{t-1} + (W^{t-1} + ... + W + I)b
```

### The Convolution Observation
This can be rewritten as:
```
h_t = sum_{k=0}^{t} W^k @ s_{t-k}

where s_τ = U x_τ + b
```

This is exactly a **convolution**! The "filter" is the powers of W.

### Why This Is Clever
- Converts sequential computation into a sum over all previous inputs
- Enables parallel computation: compute h_0, h_1, ..., h_T simultaneously
- Each h_t is independent - no data dependencies between timesteps

### The Challenge: Computing Powers Efficiently

**Naive approach:** Compute W, W², W³, ... by repeated multiplication
- Cost: O(T) matrix multiplications = O(H³·T)
- Too slow!

**Smart approach:** Binary exponentiation (the kernel construction)
```
Notice: W^{2k} = (W^k)^2

So we compute:
W^1 = W
W^2 = W^1 × W^1
W^4 = W^2 × W^2
W^8 = W^4 × W^4
...

Then fill in gaps:
W^3 = W^1 × W^2
W^5 = W^1 × W^4
W^6 = W^2 × W^4
W^7 = W^3 × W^4
```

### Algorithm Logic
```python
# Compute dominant powers: 1, 2, 4, 8, 16, ...
current = W  # W^1
for k in range(log T):
    current = current @ current  # W^{2^k}

# Fill in missing powers between doublings
# If we have W^2 and W^4, we can make W^3 = W^1 @ W^2
```

### Why It Works
- **Logarithmic depth:** Only O(log T) levels of computation
- **Composition principle:** W^a @ W^b = W^{a+b}
- **Efficient storage:** Don't need to store intermediate values beyond each level

### Complexity Analysis
```
Compute: W^2, W^4, W^8, ... (log T multiplications)
Cost: O(H³ · log T)

Fill gaps: For powers between 2^k and 2^{k+1}
Cost: O(T) multiplications, each O(H³)
But amortized: each power computed once

Total: O(H³ · log T)
```

---

## Solution 3: The Convolution (SSM Forward)

### The Intuition

Now that we have K[:,:,k] = W^k, we can compute the hidden states using:

```
h_t = sum_{k=0}^{t} W^k @ s_{t-k}
    = sum_{k=0}^{t} K[:,:,k] @ s[:,:,t-k]
```

### Why GPU Loves This
- **Massive parallelism:** Compute all h_0, h_1, ..., h_T simultaneously
- **Thousands of threads:** GPU has 1000s of parallel processors
- **No data dependencies:** Each h_t only depends on s (input projections), not other h_τ
- **Amortized cost:** T² operations spread across 10,000 threads ≈ T/10 per thread

### The Trade-off
```
CPU: O(T) sequential operations (good!) but O(T²) total (bad!)
GPU: O(T²) operations but parallelizable (good!) with 1000 processors (amazing!)
```

### When to Use
- ✓ GPU with any T (small T: low cost, large T: parallelizable)
- ✓ Batch processing (amortizes setup cost)
- ✗ CPU with large T (quadratic is deadly without parallelism)

---

## Solution 4: Diagonal Kernel (The Insight)

### The Key Realization

**For diagonal W:**
```
W = [w_1   0    0  ]
    [0    w_2   0  ]
    [0     0   w_3 ]
```

Each dimension evolves **independently**:
```
h_1(i) = w_i · h_0(i) + s_1(i) = s_1(i)  (since h_0 = 0)
h_2(i) = w_i · h_1(i) + s_2(i) = w_i · s_1(i) + s_2(i)
h_3(i) = w_i · h_2(i) + s_3(i) = w_i²·s_1(i) + w_i·s_2(i) + s_3(i)
...
h_t(i) = w_i^{t-1}·s_1(i) + w_i^{t-2}·s_2(i) + ... + s_t(i)
       = sum_{k=0}^{t} w_i^k · s_{t-k}(i)
```

### Why This Matters

**General case kernel:**
```
K[:,:,k] = W^k  (shape H×H, stores all interactions)
```

**Diagonal case kernel:**
```
K[i,0,k] = w_i^k  (shape H×1, only self-interactions)
```

### The Benefits
1. **Space:** O(H·T) instead of O(H²·T)
   - For H=256: 256× less memory!

2. **Time to build:** O(H·T) instead of O(H³·log T)
   - For H=256: millions of times faster!

3. **GPU friendly:** Depthwise convolution instead of general convolution
   - Depthwise is highly optimized on all GPUs

---

## Solution 5: Diagonal Depthwise Convolution

### What Is Depthwise Convolution?

Regular convolution:
```
input:  (batch, H_in, Length)
kernel: (H_out, H_in, kernel_size)
Each output channel mixes all input channels
```

Depthwise convolution:
```
input:  (batch, H, Length)
kernel: (H, 1, kernel_size)
Each output channel i only mixes input channel i
→ No channel interaction (parallel independent convolutions)
```

### Why This Matters

For diagonal W, we don't **want** channel interaction! Each dimension should evolve independently.

**Depthwise is perfect:**
- Each channel uses only its own kernel
- Highly optimized on all modern GPUs
- Embarrassingly parallel
- No shared memory bottlenecks

### Implementation Trick

```python
h_all = F.conv1d(s, kernel, padding=T-1, groups=H)
```

The `groups=H` parameter is magical:
- With `groups=1`: general convolution (all channels mixed)
- With `groups=H`: depthwise convolution (each channel separate)
- This is how the GPU knows to parallelize independently!

### GPU Scheduling Insight

```
groups=1 (general):
  ┌─────────────────────────────┐
  │ Compute output ch 1         │  (depends on all input channels)
  │ Compute output ch 2         │  (depends on all input channels)
  │ Compute output ch 3         │  (depends on all input channels)
  └─────────────────────────────┘
  ← Sequential order due to dependencies

groups=H (depthwise):
  ┌─────────────┬─────────────┬─────────────┐
  │ Channel 1   │ Channel 2   │ Channel 3   │  (all independent!)
  │ processing  │ processing  │ processing  │  ← Can run simultaneously!
  └─────────────┴─────────────┴─────────────┘
  ← Massive parallelism!
```

---

## Solution 6: Diagonal Recurrent (The Optimization)

### The Mathematical Trick

For diagonal W:
```
Matrix multiply: h @ W.T

When W is diagonal:
(h @ W.T)[i] = sum_j h[j] · W[i,j]
             = sum_j h[j] · δ(i,j) · w_i
             = h[i] · w_i

So: h @ W.T = h * diag(W)  (element-wise multiply!)
```

### Why This Is Amazing

**General matrix multiply:** O(N·H²)
```
for each element: sum over H products
```

**Diagonal element-wise multiply:** O(N·H)
```
just N·H multiplications total
```

**Speedup:** Factor of H!
- For H=256: 256× faster
- For H=512: 512× faster

### When This Dominates

For diagonal RNNs on CPU:
```
Diagonal Recurrent: O(N·T·H)  ← LINEAR in H!
General Recurrent:  O(N·T·H²) ← QUADRATIC in H!
Diagonal Convolution: O(N·H·T²) ← Better than O(N·H·T) only parallelized
```

**On a modern 64-core CPU:**
- Diagonal recurrent: can max out ~50 cores with good scaling
- Diagonal convolution: T² still kills it even with parallelism

---

## The Architecture Decision Tree

```
Do you have a GPU?
├─ YES
│  └─ Is H large (>128)?
│     ├─ YES: Use Diagonal Convolution
│     │       └─ Massive parallelism, optimized kernel
│     └─ NO: Use Diagonal Recurrent
│            └─ Lower latency, simpler code
│
└─ NO (CPU only)
   └─ Is T large (>1000)?
      ├─ YES: Use Diagonal Recurrent (ONLY option)
      │       └─ Linear in T, essential for CPU
      └─ NO: Still use Diagonal Recurrent
             └─ Best performance unless H < D
```

---

## The Correctness Guarantee

All implementations compute the same function:

```
Recurrent:     h_t = W h_{t-1} + U x_t + b
Convolution:   h_t = sum_k W^k @ U x_{t-k} + correction_term
Diagonal:      (same as above, exploiting W = diag(w))
```

They differ only in:
1. Computational order (affects rounding)
2. Parallelization strategy (affects performance)
3. Memory layout (affects cache efficiency)

**Expected numerical differences:** < 1e-6 for float32
- Rounding errors accumulate differently
- Both are "correct" to machine precision

---

## Key Mathematical Insights

### 1. Convolution as Unrolled Recurrence
The RNN unrolling naturally becomes a convolution when you think of it as:
- Weights: powers of the recurrence matrix
- Inputs: projections of the time sequence
- Output: convolution of weights and projected inputs

### 2. Diagonal Structure Breaks The Chain
```
General W: h_i(t) depends on all h_j(t-1)
Diagonal W: h_i(t) depends ONLY on h_i(t-1)
→ Each dimension is independent
→ Can compute independently
→ Parallelism!
```

### 3. Binary Exponentiation for Matrix Powers
```
To compute W^7:
Path 1: W @ W @ W @ W @ W @ W @ W  (6 multiplications)
Path 2: W^1 @ W^2 @ W^4            (2 + 1 = 3 multiplications)
        = (W @ W²) @ W⁴ = (W @ W²) @ W⁴ = ...
```
Log complexity instead of linear!

### 4. The GPU Parallelism Paradox
```
More operations can be faster when:
- They're parallelizable
- Hardware has massive parallelism
- Memory bandwidth isn't bottleneck

CPU: O(T) better than O(T²) always
GPU: O(T²) ÷ 1000 threads ≈ O(T/1000) per thread
```

---

## Engineering Insights

### Device Management
```python
# All tensors must stay on same device
torch.set_default_device('cuda')  # Set default
device = x.device  # or pass explicitly
```

### Memory Layout
```python
# Shape matters for performance
(N, H, T) for conv1d (channels × length)
vs
(N, T, H) for storage

Permute at boundaries only!
```

### Padding Trick
```python
# Causal padding: future doesn't affect past
padding = T - 1  # Ensures we have history
h_all = h_all[:, :, :T]  # Keep only valid part
```

### Groups Parameter
```python
# Magic number that enables depthwise
groups=H  # Each channel independent
groups=1  # General convolution (channels mix)
```

---

## Performance Expectations

### CPU (Single-threaded)
```
H=64, T=128:
  Recurrent: ~1ms (linear, efficient)
  Convolution: ~100ms (quadratic, killer)
  Diag Recurrent: ~0.1ms (linear, amazing)

H=256, T=512:
  Recurrent: ~50ms
  Convolution: ~20 seconds (quadratic explosion!)
  Diag Recurrent: ~3ms
```

### GPU (RTX 3090 equivalent)
```
H=64, T=512:
  Recurrent: ~20ms (sequential bottleneck)
  Convolution: ~5ms (parallelizable!)
  Diag Convolution: ~3ms (depthwise optimized)

H=256, T=512:
  Recurrent: ~100ms (still sequential)
  Convolution: ~30ms (O(T²) spread across 1000 cores)
  Diag Convolution: ~8ms (best of both worlds)
```

---

## The Real-World Application

These techniques power modern efficient architectures:

**Mamba:** Uses diagonal SSM recurrences with specialized CUDA kernels
- ✓ Linear complexity in T (like recurrence)
- ✓ GPU parallelization (like convolution)
- ✓ Better than Transformers on long sequences

**Key insight:** Diagonal structure + clever implementation = Pareto frontier!

---

## Lessons Learned

1. **Algorithm ≠ Complexity**
   - Same math, different computational order → different performance

2. **Hardware is destiny**
   - CPU: love sequential, hate quadratic
   - GPU: love parallel, can tolerate quadratic if enough parallelism

3. **Structure is power**
   - Diagonal matrices: H-fold speedup for free
   - Linear algebra insight → Engineering advantage

4. **Precision matters in practice**
   - Floating-point errors compound differently depending on order
   - All correct to machine epsilon though

5. **The best algorithm is context-dependent**
   - No one-size-fits-all solution
   - Must consider hardware, data size, and constraints

---

## Summary

| What | Why | How |
|------|-----|-----|
| **Recurrent** | Direct implementation | Loop over time, apply rule |
| **Convolution** | Parallelizable | Unroll RNN, compute powers, sum |
| **Diag Recurrent** | Exploit structure | Element-wise instead of matrix mult |
| **Diag Convolution** | GPU optimized | Depthwise conv with independent channels |

All compute the same thing, just differently. Choose based on hardware!
