import torch

# Test the kernel building
def make_conv_kernel(W, T):
    H = W.shape[0]
    kernel_for_conv = torch.zeros(H, H, T, dtype=W.dtype, device=W.device)
    
    # Base cases
    kernel_for_conv[:, :, 0] = torch.eye(H, dtype=W.dtype, device=W.device)
    
    if T > 1:
        kernel_for_conv[:, :, 1] = W
    
    # Build kernel using divide-and-conquer
    current_power = W
    idx = 1
    
    while idx * 2 < T:
        current_power = current_power @ current_power
        idx = idx * 2
        kernel_for_conv[:, :, idx] = current_power
        
        for t in range(idx + 1, min(idx * 2, T)):
            k = t - idx
            kernel_for_conv[:, :, t] = kernel_for_conv[:, :, k] @ kernel_for_conv[:, :, idx]
    
    return kernel_for_conv

# Test with small T
torch.manual_seed(0)
W = torch.randn(4, 4) * 0.1
print("Testing kernel building for T=8")
kernel = make_conv_kernel(W, 8)
print("Kernel shape:", kernel.shape)

# Verify the powers
print("\nVerifying powers of W:")
for i in range(min(3, 8)):
    if i == 0:
        expected = torch.eye(4)
    else:
        expected = torch.matrix_power(W, i)
    actual = kernel[:, :, i]
    diff = (expected - actual).abs().max()
    print(f"W^{i} error: {diff.item():.2e}")
