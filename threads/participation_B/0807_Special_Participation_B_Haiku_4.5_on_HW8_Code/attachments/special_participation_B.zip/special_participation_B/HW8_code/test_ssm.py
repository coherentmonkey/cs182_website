import torch
import torch.nn.functional as F

# Copy the implementations here for testing
def unrolled_ssm_forward(W, U, b, x):
    """
    Unroll the linear RNN in time:
        h_{t+1} = W h_t + U x_t + b
    with initial h_0 = 0.

    Args:
      W: (H, H) weight matrix
      U: (H, D) input projection
      b: (H,)   bias
      x: (N, T, D) input sequence over T steps
    Returns:
      h_all: (N, T, H) hidden states for t=1..T
             (h_all[t] corresponds to h_{t+1} in the usual notation).
    """
    # Extract dimensions from input
    N, T, D = x.shape
    H = W.shape[0]

    # Initialize array to store hidden states at each timestep
    h_all = torch.zeros(N, T, H, dtype=x.dtype, device=x.device)

    # Initialize hidden state to zero (h_0 = 0)
    h_t = torch.zeros(N, H, dtype=x.dtype, device=x.device)

    # Iterate through time steps t=0, 1, ..., T-1
    # Computing h_{t+1} = W h_t + U x_t + b at each step
    for t in range(T):
        # Get input at time t: (N, D)
        x_t = x[:, t, :]

        # Apply input projection and add bias: (N, D) @ (D, H).T + (H,) = (N, H)
        h_t = h_t @ W.T + x_t @ U.T + b

        # Store the hidden state for this timestep
        h_all[:, t, :] = h_t

    return h_all


def make_conv_kernel(W, T):
    """
    Build a 3D kernel tensor K of shape (H, H, T) we will use when implementing
    the ssm forward pass using conv1d.

    Args:
      W: (H, H) weight matrix
      T: scalar

    Returns:
      kernel_for_conv: (H, H, T) tensor
    """
    # Key insight: The convolution kernel represents powers of W
    # K[:, :, t] should store W^t (matrix power)
    # We use divide-and-conquer (binary exponentiation) for efficiency
    #
    # For the RNN h_{t+1} = W h_t + U x_t + b, when unrolled:
    # h_t = W^{t-1} h_1 + W^{t-2} U x_1 + ... + W U x_{t-1} + U x_t + (I-W)^{-1}b
    # This can be expressed as a convolution with kernel K where K[:,:,k] = W^k

    H = W.shape[0]

    # Initialize kernel to store W^0 through W^{T-1}
    kernel_for_conv = torch.zeros(H, H, T, dtype=W.dtype, device=W.device)

    # Base cases
    # K[:, :, 0] = W^0 = I (identity matrix)
    kernel_for_conv[:, :, 0] = torch.eye(H, dtype=W.dtype, device=W.device)

    if T > 1:
        # K[:, :, 1] = W^1 = W
        kernel_for_conv[:, :, 1] = W

    # Build kernel using divide-and-conquer (binary exponentiation)
    # Compute powers iteratively: W^2, W^4, W^8, ..., W^{2^k} <= T
    current_power = W  # W^1
    idx = 1

    while idx * 2 < T:
        # Compute W^{2*idx} by squaring W^idx
        current_power = current_power @ current_power
        idx = idx * 2

        # Store all powers from idx to min(idx*2 - 1, T-1)
        kernel_for_conv[:, :, idx] = current_power

        # Fill in intermediate powers using previously computed values
        # For example, if we have W^2 and W^4, we can compute W^3 = W^2 @ W
        for t in range(idx + 1, min(idx * 2, T)):
            # Find the largest power less than t that we've already computed
            k = t - idx
            kernel_for_conv[:, :, t] = kernel_for_conv[:, :, k] @ kernel_for_conv[:, :, idx]

    return kernel_for_conv


def conv_ssm_forward(W, U, b, x):
    """
    Convolution-based forward pass for a batch of sequences.

    RNN update:  h_{t+1} = W h_t + U x_t + b

    Args:
      W: (H, H) weight matrix
      U: (H, D) input projection
      b: (H,)   bias
      x: (N, T, D) input (batch=N, time steps=T, input dim=D)

    Returns:
      h_all: (N, T, H) hidden states
    """
    N, T, D = x.shape
    H = W.shape[0]

    # First, project inputs and add bias: (N, T, D) @ (D, H).T + (H,) = (N, T, H)
    s = x @ U.T + b  

    # Permute to (N, H, T) for conv1d input format
    # conv1d expects (batch, channels, length)
    s = s.permute(0, 2, 1) 

    # Build the kernel with shape (H, H, T).
    kernel = make_conv_kernel(W, T)

    # Perform convolution by sliding the kernel over the input
    # For each time step t, compute: h_t = sum_{k=0}^{t} kernel[:,:,k] @ s[:,t-k,:]
    h_all = torch.zeros(N, H, T, dtype=s.dtype, device=s.device)

    for t in range(T):
        # At time t, we sum contributions from all previous timesteps
        # h[:, :, t] = sum_{k=0}^{t} W^k @ U x_{t-k}
        for k in range(t + 1):
            # kernel[:, :, k] is W^k with shape (H, H)
            # s[:, :, t-k] is the input projection at time t-k with shape (N, H)
            # We need to compute (N, H) @ (H, H).T to get (N, H)
            h_all[:, :, t] += s[:, :, t - k] @ kernel[:, :, k].T

    # Permute back to (N, T, H) format
    h_all = h_all.permute(0, 2, 1)

    return h_all


# Test the implementations
def sanity_check():
    T = 8   # number of time steps
    H = 4   # hidden dimension
    D = 3   # input dimension
    N = 2

    torch.manual_seed(0)

    W = torch.randn(H, H) * 0.1
    U = torch.randn(H, D) * 0.1
    b = torch.randn(H) * 0.1

    x = torch.randn(N, T, D)

    h_unrolled = unrolled_ssm_forward(W, U, b, x)
    h_conv = conv_ssm_forward(W, U, b, x)

    diff = (h_unrolled - h_conv).abs().max()
    print("Unrolled h(t):")
    print(h_unrolled)
    print("\nConv-based h(t):")
    print(h_conv)
    print("\nMax absolute difference:", diff.item())

sanity_check()
