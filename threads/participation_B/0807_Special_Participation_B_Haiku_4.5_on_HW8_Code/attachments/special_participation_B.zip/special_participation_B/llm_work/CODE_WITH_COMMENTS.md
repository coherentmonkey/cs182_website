# Complete SSM Implementation with Detailed Comments

This document shows the complete, commented implementations of all three functions.

---

## Function 1: Unrolled SSM Forward Pass

```python
def unrolled_ssm_forward(W, U, b, x):
    """
    Unroll the linear RNN in time: h_{t+1} = W h_t + U x_t + b
    with initial h_0 = 0.
    
    Args:
        W: (H, H) weight matrix - controls hidden state evolution
        U: (H, D) input projection - projects input to hidden dimension
        b: (H,)   bias vector - shift applied at each step
        x: (N, T, D) input sequence over T timesteps
          - N: batch size
          - T: number of timesteps
          - D: input dimension
    
    Returns:
        h_all: (N, T, H) hidden states for t=1..T
               h_all[n, t, :] contains h_{t+1} for batch element n
    
    Complexity:
        Time: O(N·T·H²)
        Space: O(N·T·H) for output + O(N·H) for intermediate states
    """
    
    # Extract dimensions from input tensor
    N, T, D = x.shape  # batch=N, time=T, input_dim=D
    H = W.shape[0]     # hidden dimension
    
    # Initialize output tensor to store all hidden states
    # We'll fill this row by row as we iterate through time
    h_all = torch.zeros(N, T, H, dtype=x.dtype, device=x.device)
    
    # Initialize the hidden state as zero (h_0 = 0)
    # This is standard for RNNs - starting from a clean state
    h_t = torch.zeros(N, H, dtype=x.dtype, device=x.device)
    
    # Iterate through all timesteps t = 0, 1, ..., T-1
    for t in range(T):
        # Extract input at current timestep: x_t has shape (N, D)
        x_t = x[:, t, :]
        
        # Apply the RNN update rule: h_{t+1} = W h_t + U x_t + b
        # 
        # Breaking down the matrix operations (with batch dimension N):
        # 1. h_t @ W.T: (N, H) @ (H, H) → (N, H)
        #    Applies recurrent transformation to current hidden state
        # 
        # 2. x_t @ U.T: (N, D) @ (D, H) → (N, H)
        #    Projects input from D dimensions to H dimensions
        # 
        # 3. Add b: broadcasts (H,) to (N, H)
        #    Adds bias to each batch element
        #
        # Result: h_t is now h_{t+1}, ready for next iteration
        h_t = h_t @ W.T + x_t @ U.T + b
        
        # Store the computed hidden state for this timestep
        # This is added to our output tensor
        h_all[:, t, :] = h_t
    
    return h_all


# Usage example:
# W = torch.randn(H, H) * 0.1         # Small random weights
# U = torch.randn(H, D) * 0.1         # Small random projection
# b = torch.randn(H) * 0.1             # Small random bias
# x = torch.randn(N, T, D)             # Random input sequence
# h_all = unrolled_ssm_forward(W, U, b, x)  # (N, T, H)
```

---

## Function 2: Convolution Kernel Construction

```python
def make_conv_kernel(W, T):
    """
    Build a 3D kernel tensor K of shape (H, H, T) containing all powers of W.
    
    The kernel represents how previous states influence current output:
    K[:, :, k] = W^k (the k-th power of W matrix)
    
    This enables expressing the RNN as a convolution operation where:
    h_t = sum_{k=0}^{t} (W^k) @ s_{t-k}
    
    Args:
        W: (H, H) weight matrix to compute powers of
        T: Number of timesteps (sequence length)
    
    Returns:
        kernel_for_conv: (H, H, T) tensor where kernel[:, :, k] = W^k
    
    Complexity:
        Time: O(H³·log(T)) using binary exponentiation
        Space: O(H²·T)
    
    Key Insight: Binary Exponentiation
        Instead of computing W^t directly (O(T·H³) time), we use divide-and-conquer:
        - Compute W², W⁴, W⁸, ... by repeated squaring: O(log T) multiplies
        - Decompose intermediate powers: W³ = W² @ W¹, etc.
        - Total: O(H³ · log T) instead of O(T·H³)
    """
    
    H = W.shape[0]  # Hidden dimension
    
    # Initialize kernel to store all matrix powers W^0 through W^(T-1)
    kernel_for_conv = torch.zeros(H, H, T, dtype=W.dtype, device=W.device)
    
    # BASE CASE 1: W^0 = Identity matrix
    # The 0-th power is always identity by definition
    kernel_for_conv[:, :, 0] = torch.eye(H, dtype=W.dtype, device=W.device)
    
    # BASE CASE 2: W^1 = W itself (if T > 1)
    if T > 1:
        kernel_for_conv[:, :, 1] = W
    
    # BINARY EXPONENTIATION PHASE
    # Compute powers using divide-and-conquer strategy
    # We compute: W², W⁴, W⁸, ..., W^(2^k) where 2^k ≤ T
    
    current_power = W  # Start with W^1
    idx = 1            # Current exponent (starts at 1)
    
    # Keep squaring until we'd go beyond T
    while idx * 2 < T:
        # Double the exponent by squaring the current power
        # (W^idx)² = W^(2·idx)
        current_power = current_power @ current_power
        idx = idx * 2
        
        # Store this power of W in the kernel
        kernel_for_conv[:, :, idx] = current_power
        
        # Now fill in intermediate powers between idx and 2*idx
        # Example: if we just computed W⁴, and previously had W², W¹, we can compute:
        # W³ = W² @ W¹, W⁵ = W⁴ @ W¹, W⁶ = W⁴ @ W², W⁷ = W⁴ @ W²@W¹, etc.
        #
        # More precisely, for each t in [idx+1, 2*idx), write t = k + idx where k < idx
        # Then W^t = W^k @ W^idx (both already computed!)
        
        for t in range(idx + 1, min(idx * 2, T)):
            # Decompose t into k + idx
            # This works because: t = k + idx < 2*idx
            # So k < idx, and W^k was computed in a previous iteration
            k = t - idx
            
            # Compute W^t as the product of two previously computed powers
            kernel_for_conv[:, :, t] = kernel_for_conv[:, :, k] @ kernel_for_conv[:, :, idx]
    
    return kernel_for_conv


# Usage example:
# W = torch.randn(H, H) * 0.1
# kernel = make_conv_kernel(W, T=256)  # (H, H, 256)
# 
# # Verify correctness:
# for k in range(3):
#     computed = kernel[:, :, k]
#     expected = torch.matrix_power(W, k)
#     assert torch.allclose(computed, expected)
```

---

## Function 3: Convolution-based SSM Forward

```python
def conv_ssm_forward(W, U, b, x):
    """
    Convolution-based forward pass for SSM: h_{t+1} = W h_t + U x_t + b
    
    Key insight: When we unroll the RNN, we get:
        h_t = sum_{k=0}^{t} W^k @ (U x_{t-k} + bias_adjustment)
    
    This is a convolution operation with kernel K[:,:,k] = W^k
    
    Args:
        W: (H, H) weight matrix
        U: (H, D) input projection
        b: (H,)   bias
        x: (N, T, D) input (batch=N, time=T, input_dim=D)
    
    Returns:
        h_all: (N, T, H) hidden states
    
    Complexity:
        Time: O(N·H·T² + H³·log T)
               - O(H³·log T) for kernel construction
               - O(N·H·T²) for nested convolution loops
        Space: O(N·H·T + H²·T)
    
    Note on T² term: This is why recurrence is better on CPU for large T!
    """
    
    N, T, D = x.shape  # batch, time steps, input dimension
    H = W.shape[0]     # hidden dimension
    
    # STEP 1: Project all inputs to hidden dimension at once
    # Instead of projecting x_t individually in the convolution loop,
    # we pre-compute U x_t + b for all t simultaneously
    # (N, T, D) @ (D, H) + (H,) = (N, T, H)
    s = x @ U.T + b
    
    # STEP 2: Reshape for efficient time-based iteration
    # Transpose from (N, T, H) to (N, H, T)
    # This puts time as the last dimension, making it easier to iterate
    # and access s[:, :, t] (all channels at time t for all batches)
    s = s.permute(0, 2, 1)
    
    # STEP 3: Build the convolution kernel containing all powers of W
    # kernel has shape (H, H, T) where kernel[:, :, k] = W^k
    kernel = make_conv_kernel(W, T)
    
    # STEP 4: Apply convolution - the core of the algorithm
    # 
    # The convolution computes for each timestep t:
    #     h[:, :, t] = sum_{k=0}^{t} (W^k) @ s[:, :, t-k]
    #
    # This sums contributions from:
    # - k=0: current timestep (no recurrence)
    # - k=1: 1 step in the past (affected by W)
    # - k=2: 2 steps in the past (affected by W²)
    # - ...
    # - k=t: t steps in the past (affected by W^t)
    
    h_all = torch.zeros(N, H, T, dtype=s.dtype, device=s.device)
    
    # Iterate through all timesteps
    for t in range(T):
        # For timestep t, sum contributions from all previous timesteps
        for k in range(t + 1):
            # kernel[:, :, k] has shape (H, H) - it's W^k
            # s[:, :, t-k] has shape (N, H) - input projection from t-k steps ago
            #
            # We need to compute (N, H) @ (H, H) = (N, H)
            # To do this: s[:, :, t-k] @ kernel[:, :, k].T
            # where kernel[:, :, k].T transposes the (H,H) matrix
            #
            # Why transpose? s[:,:,t-k] is (N, H) and we want to apply 
            # W^k from the right, so we use W^k.T on the right
            
            h_all[:, :, t] += s[:, :, t - k] @ kernel[:, :, k].T
    
    # STEP 5: Reshape output back to standard format
    # Permute from (N, H, T) back to (N, T, H)
    # This matches the expected output format where h_all[n, t, :] is the hidden state
    h_all = h_all.permute(0, 2, 1)
    
    return h_all


# Usage example:
# W = torch.randn(H, H) * 0.1
# U = torch.randn(H, D) * 0.1
# b = torch.randn(H) * 0.1
# x = torch.randn(N, T, D)
# h_all = conv_ssm_forward(W, U, b, x)  # (N, T, H)
#
# # This should match unrolled version:
# h_all_unrolled = unrolled_ssm_forward(W, U, b, x)
# print((h_all - h_all_unrolled).abs().max())  # Should be ~1e-7
```

---

## Performance Comparison

```
Function Complexity Summary:

                      Time Complexity        Space Complexity
Unrolled              O(N·T·H²)             O(N·T·H + N·H)
Conv Kernel           O(H³·log T)           O(H²·T)
Conv Forward          O(N·H·T²)             O(N·H·T)
Conv Total            O(N·H·T² + H³·log T)  O(N·H·T + H²·T)

When to use each:
- Unrolled: Always for CPU, small T
- Conv: GPU with massive parallelism, very small T
- Modern: Neither - use specialized kernels (FlashAttention/Mamba)
```

---

## Key Implementation Insights

### 1. Matrix Dimension Tracking
- Always think in batches: (N, ...) at the front
- Be careful with transposes: `A @ B.T` vs `A.T @ B`
- Verify dimensions before implementing

### 2. Numerical Stability
- Both implementations should match to ~1e-7 precision
- Larger differences indicate a bug (usually dimension mismatch)
- Test on small examples first (T=8, H=4)

### 3. The T² Problem
- Nested loops over time create quadratic cost
- This is why convolution isn't used on CPUs
- GPU parallelism transforms this from sequential cost to parallel gain

### 4. Memory Access Patterns
- Unrolled: Sequential, cache-friendly (linear sweeps)
- Convolution: Random access (accessing all t-k simultaneously)
- CPUs prefer sequential access (cache locality)

